import 'package:chaldea/app/battle/functions/function_executor.dart';
import 'package:chaldea/app/battle/models/battle.dart';
import 'package:chaldea/models/gamedata/gamedata.dart';

import '../utils/battle_utils.dart';

class MoveState {
  MoveState._();

  static Future<void> moveState(
    BattleData battleData,
    DataVals dataVals,
    BattleServantData receiver,
    BattleServantData? targetedAlly,
    BattleServantData? targetedEnemy,
  ) async {
    final functionRate = dataVals.Rate ?? 1000;
    if (functionRate < battleData.options.threshold) {
      return;
    }

    final dependFunction = await getDependFunc(battleData.battleLogger, dataVals);
    final dependVal = dataVals.DependFuncVals!;
    final affectTraits = dependFunction.traitVals;

    for (final absorbTarget in await FunctionExecutor.acquireFunctionTarget(
      battleData,
      dependFunction.funcTargetType,
      receiver,
      funcId: dependFunction.funcId,
      targetedAlly: receiver,
      targetedEnemy: battleData.targetedEnemy,
    )) {
      for (final buff in absorbTarget.getBuffsWithTraits(affectTraits)) {
        receiver.addBuff(buff.copy());
      }
    }
    battleData.setFuncResult(receiver.uniqueId, true);

    final NiceFunction niceFunction = NiceFunction(
      funcId: dependFunction.funcId,
      funcType: dependFunction.funcType,
      funcTargetType: dependFunction.funcTargetType,
      funcTargetTeam: dependFunction.funcTargetTeam,
      funcPopupText: dependFunction.funcPopupText,
      funcPopupIcon: dependFunction.funcPopupIcon,
      functvals: dependFunction.functvals,
      funcquestTvals: dependFunction.funcquestTvals,
      funcGroup: dependFunction.funcGroup,
      vals: dependFunction.vals,
      buffs: dependFunction.buffs,
      svals: [dependVal],
    );

    // we provisioned only one dataVal
    await FunctionExecutor.executeFunctions(
      battleData,
      [niceFunction],
      1,
      activator: receiver,
      targetedAlly: targetedAlly,
      targetedEnemy: targetedEnemy,
    );
  }
}
