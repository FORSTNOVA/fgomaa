import 'dart:math';

import 'package:font_awesome_flutter/font_awesome_flutter.dart';

import 'package:chaldea/app/app.dart';
import 'package:chaldea/app/modules/quest/quest_list.dart';
import 'package:chaldea/generated/l10n.dart';
import 'package:chaldea/models/gamedata/mst_data.dart';
import 'package:chaldea/models/models.dart';
import 'package:chaldea/utils/utils.dart';
import 'package:chaldea/widgets/widgets.dart';

import '../gacha/gacha_draw.dart';
import '../mission/mission_receive.dart';
import '../present_box/present_box.dart';
import '../runtime.dart';
import '../shop/coin_room.dart';
import '../shop/ex_room_shop.dart';
import '../shop/shop.dart';

/// Presents listed per reminder block; anything beyond this is summarised.
const int _kMaxPresentRows = 10;

/// Days before expiry at which a present starts being listed.
const int _kPresentWarningDays = 30;

class FakerReminders extends StatelessWidget {
  final FakerRuntime runtime;
  final MasterDataManager mstData;
  FakerReminders({super.key, required this.runtime}) : mstData = runtime.mstData;

  @override
  Widget build(BuildContext context) {
    if (!mstData.isLoggedIn) return const SizedBox.shrink();

    final now = DateTime.now().timestamp;
    List<Widget> children = [
      ...getGachas(context, now),
      ...getExRoomShop(context, now),
      ...getShops(context, now),
      ...getMissions(context, now),
      ...getPresents(context, now),
      ...getQuests(context, now),
      ...getOthers(context, now),
    ];

    if (children.isEmpty) return const SizedBox.shrink();
    return TileGroup(header: S.current.hint, children: children);
  }

  Iterable<Widget> getGachas(BuildContext context, int now) sync* {
    const conflictGachaGroups = [
      [2, 3],
      [4, 5],
    ];
    for (final gacha in runtime.gameData.timerData.gachas.values) {
      if (gacha.freeDrawFlag == 0 || gacha.openedAt > now || gacha.closedAt <= now) continue;
      if (!gacha.releaseConditions.every(runtime.condCheck.isOpenForGacha)) {
        continue;
      }
      if (mstData.userGacha[gacha.id] == null &&
          conflictGachaGroups.any((group) {
            return group.contains(gacha.id) &&
                group.any((gachaId) => gachaId != gacha.id && mstData.userGacha[gachaId] != null);
          })) {
        continue;
      }
      int resetHourUTC;
      switch (gacha.gachaType) {
        case GachaType.freeGacha:
          resetHourUTC = runtime.region.fpFreeGachaResetUTC;
        case GachaType.payGacha:
          resetHourUTC = runtime.region.storyFreeGachaResetUTC;
        default:
          assert(() {
            throw UnsupportedError('Unsupported GachaType: ${gacha.type}');
          }());
          continue;
      }
      int? nextFreeDrawAt;
      final userGacha = mstData.userGacha[gacha.id];
      nextFreeDrawAt = DateTimeX.findNextHourAt(userGacha?.freeDrawAt ?? gacha.openedAt, resetHourUTC);
      bool hasFreeDraw = nextFreeDrawAt < now;
      if (!hasFreeDraw) continue;

      yield ListTile(
        dense: true,
        title: Text('[${gacha.id}] ${gacha.lName}'),
        subtitle: Text(
          'Free ${userGacha?.freeDrawAt.sec2date().toCustomString(year: false)}'
          ' → ${nextFreeDrawAt.sec2date().toCustomString(year: false)}',
        ),
        onTap: () {
          if (runtime.runningTask.value) return;
          runtime.agent.user.gacha.gachaId = gacha.id;
          router.pushPage(GachaDrawPage(runtime: runtime));
        },
        trailing: TextButton(
          onPressed: hasFreeDraw
              ? () {
                  if (runtime.runningTask.value) return;
                  SimpleConfirmDialog(
                    title: Text('Free Draw'),
                    content: Text('[${gacha.id}] ${gacha.lName}'),
                    onTapOk: () async {
                      final result = await runtime.runTask(() async {
                        runtime.agent.user.gacha.gachaId = gacha.id;
                        return runtime.gacha.gachaDraw(hundredDraw: false);
                      });
                      if (result != null) {
                        runtime.showLocalDialog(
                          Builder(
                            builder: (context) {
                              return SimpleConfirmDialog(
                                scrollable: true,
                                showCancel: false,
                                title: Text('${S.current.gacha} - ${gacha.lName}'),
                                content: Wrap(
                                  children: result.gachaInfos.map((card) {
                                    Widget child = card.toGift().iconBuilder(
                                      context: context,
                                      width: 48,
                                      text: card.userSvtId == 0 ? 'sold' : null,
                                      showOne: false,
                                    );
                                    if (card.userSvtId == 0) {
                                      child = Stack(
                                        children: [
                                          child,
                                          Positioned.fill(
                                            child: IgnorePointer(
                                              child: Container(
                                                color: Colors.grey.withAlpha(153),
                                                margin: EdgeInsets.all(2),
                                              ),
                                            ),
                                          ),
                                        ],
                                      );
                                    }
                                    return child;
                                  }).toList(),
                                ),
                              );
                            },
                          ),
                        );
                      }
                    },
                  ).showDialog(context);
                }
              : null,
          child: Text(S.current.summon),
        ),
      );
    }
  }

  List<Widget> getExRoomShop(BuildContext context, int now) {
    final todayKey = ShopDailyInfo.getTodayKey(runtime.region);
    final shops = mstData.mstShopDaily.where((e) => e.dayKey == todayKey).toList();
    shops.sortByList((e) => [-e.lineupGroup, e.shopId]);
    List<Widget> children = [];
    for (final shopDaily in shops) {
      final useItemId = shopDaily.useItemIds.firstOrNull ?? 0, useItemOwnNum = mstData.getItemOrSvtNum(useItemId);
      final targetItemId = ConstData.shopDailyTargets[shopDaily.shopId] ?? 0,
          targetItemOwnNum = mstData.getItemOrSvtNum(targetItemId);
      if (targetItemOwnNum > useItemOwnNum + 200) continue;
      final buyNum = mstData.userShopDaily[shopDaily.shopId]?.validate(shopDaily.dayKey)?.num ?? 0;
      if (buyNum >= shopDaily.dailyLimitNum) continue;
      final suggestBuy = targetItemOwnNum < useItemOwnNum;
      children.add(
        Row(
          mainAxisSize: .min,
          children: [
            Opacity(
              opacity: 0.5,
              child: Item.iconBuilder(
                context: context,
                item: null,
                itemId: useItemId,
                text: useItemOwnNum.format(),
                width: 28,
              ),
            ),
            Opacity(
              opacity: suggestBuy ? 1 : 0.75,
              child: Item.iconBuilder(
                context: context,
                item: null,
                itemId: targetItemId,
                text: [(shopDaily.dailyLimitNum - buyNum).format(), targetItemOwnNum.format()].join('\n'),
                width: 32,
                option: suggestBuy
                    ? ImageWithTextOption(
                        shadowColor: Colors.white,
                        shadowSize: 1,
                        textStyle: TextStyle(color: Colors.red, fontWeight: .bold),
                      )
                    : null,
              ),
            ),
          ],
        ),
      );
    }
    if (children.isEmpty) return [];
    return [
      ListTile(
        dense: true,
        // leading: ,
        title: Wrap(spacing: 6, runSpacing: 2, children: children),
        trailing: Icon(DirectionalIcons.keyboard_arrow_forward(context)),
        onTap: () {
          router.pushPage(ExRoomShopPage(runtime: runtime));
        },
      ),
    ];
  }

  List<Widget> getShops(BuildContext context, int now) {
    List<Widget> children = [];
    List<NiceShop> _shownShops = [];
    for (final shop in runtime.gameData.timerData.shops.values) {
      if (shop.openedAt > now || now >= shop.closedAt) continue;
      final userShop = mstData.userShop[shop.id];
      if (userShop != null && userShop.num >= shop.limitNum) continue;
      final targetIds = shop.getItemAndCardIds().where((targetId) {
        if (runtime.agent.user.shopTargetIds.contains(targetId)) return true;
        final item = runtime.gameData.teapots[targetId] ?? db.gameData.items[targetId];
        if (item != null) {
          if (item.type == ItemType.friendshipUpItem || item.type == ItemType.stormpod) return true;
          if (shop.shopType == ShopType.mana && item.type == ItemType.commandCardPrmUp) return true;
          if (shop.shopType == ShopType.mana && const [5000, 5001, 5002, 5003].contains(item.id)) return true;
        }
        final entity = db.gameData.entities[targetId];
        if (entity != null) {
          if (entity.flags.contains(SvtFlag.svtEquipManaExchange)) return true;
          if (shop.shopType == ShopType.mana && entity.type == SvtType.statusUp && entity.rarity >= 4) return true;
        }
        return false;
      }).toSet();
      if (targetIds.isEmpty) continue;
      _shownShops.add(shop);
      children.add(
        ListTile(
          dense: true,
          leading: GameCardMixin.anyCardItemBuilder(context: context, id: targetIds.first, width: 32),
          title: Text(shop.lName),
          subtitle: Text.rich(
            TextSpan(
              children: [
                CenterWidgetSpan(
                  child: Item.iconBuilder(
                    context: context,
                    item: shop.cost?.item,
                    width: 16,
                    text: shop.setNum > 1 ? '×${shop.setNum}' : null,
                  ),
                ),
                TextSpan(text: ' ${shop.cost?.amount}'),
                if (shop.limitNum > 1) TextSpan(text: '×${shop.limitNum}'),
                TextSpan(text: ',  ${shop.closedAt.sec2date().toCustomString(year: false, second: false)}'),
              ],
            ),
          ),
          trailing: Text('${userShop?.num ?? 0}/${shop.limitNum}'),
          onTap: () {
            router.pushPage(UserShopsPage(runtime: runtime, title: S.current.shop, shops: _shownShops));
          },
        ),
      );
    }
    return children;
  }

  Iterable<Widget> getMissions(BuildContext context, int now) sync* {
    const int _kMissionWarningDay = 2;
    for (final mm in runtime.gameData.timerData.masterMissions.values) {
      if (const [MissionType.none, MissionType.daily].contains(mm.type)) continue;
      if (mm.missions.isEmpty) continue;
      if (mm.closedAt < now || mm.startedAt > now || mm.id == MasterMission.kExtraMasterMissionId) continue;
      // mm.endedAt - now > _kMissionWarningDay * kSecsPerDay
      int closestEndedAt = mm.endedAt;
      Map<MissionProgressType, int> progresses = {};
      for (final mission in mm.missions) {
        final progress = runtime.condCheck.getEventMissionProgress(mission.id);
        progresses.addNum(progress, 1);
        if (progress != .achieve && isTimeOpen(mission.startedAt, mission.endedAt, now)) {
          closestEndedAt = min(mission.endedAt, closestEndedAt);
        }
      }
      bool needWarning =
          progresses.keys.any((e) => e != MissionProgressType.achieve) &&
          closestEndedAt - now < _kMissionWarningDay * kSecsPerDay;
      if (needWarning) {
        String subtitle = [
          closestEndedAt.sec2date().toCustomString(year: false, second: false),
          for (final type in progresses.keys.toList()..sort2((e) => e.value)) '${type.name} ${progresses[type]}',
        ].join(', ');

        yield ListTile(
          dense: true,
          leading: const FaIcon(FontAwesomeIcons.listCheck, size: 18),
          title: Text('[${Transl.enums(mm.type, (e) => e.missionType).l}] ${mm.getDispName(withId: false)}'),
          subtitle: Text(
            subtitle,
            style: closestEndedAt - now < kSecsPerDay ? TextStyle(color: Theme.of(context).colorScheme.error) : null,
          ),
          trailing: Icon(DirectionalIcons.keyboard_arrow_forward(context)),
          onTap: () {
            router.pushPage(UserEventMissionReceivePage(runtime: runtime, initId: mm.id));
          },
        );
      }
    }
  }

  /// Presents expiring within [_kPresentWarningDays] days, capped at
  /// [_kMaxPresentRows] rows.
  ///
  /// A present box can hold hundreds of entries, and the row only has to tell
  /// the player to go clear it, so the earliest ones are listed and the rest are
  /// summarised in one trailing row.
  Iterable<Widget> getPresents(BuildContext context, int now) sync* {
    final expiring = <({UserPresentBoxEntity present, int expireAt})>[];
    for (final present in mstData.userPresentBox) {
      final expireAt = present.getExpireAt(runtime.gameData.timerData.items[present.objectId]);
      if (expireAt < now + _kPresentWarningDays * kSecsPerDay) {
        expiring.add((present: present, expireAt: expireAt));
      }
    }
    expiring.sort((a, b) => a.expireAt.compareTo(b.expireAt));

    for (final (:present, :expireAt) in expiring.take(_kMaxPresentRows)) {
      final gift = present.toGift();
      yield ListTile(
        dense: true,
        leading: Icon(Icons.card_giftcard),
        title: Text.rich(
          TextSpan(
            children: [
              CenterWidgetSpan(child: gift.iconBuilder(context: context, width: 24)),
              TextSpan(text: ' ${gift.shownName} ×${gift.num}'),
            ],
          ),
        ),
        subtitle: Text(expireAt.sec2date().toCustomString()),
        trailing: Icon(DirectionalIcons.keyboard_arrow_forward(context)),
        onTap: () => router.pushPage(UserPresentBoxManagePage(runtime: runtime)),
      );
    }

    if (expiring.length > _kMaxPresentRows) {
      yield ListTile(
        dense: true,
        leading: Icon(Icons.more_horiz),
        title: Text('${expiring.length - _kMaxPresentRows} more presents expiring'),
        subtitle: Text('${expiring.length} presents expire within $_kPresentWarningDays days'),
        trailing: Icon(DirectionalIcons.keyboard_arrow_forward(context)),
        onTap: () => router.pushPage(UserPresentBoxManagePage(runtime: runtime)),
      );
    }
  }

  Iterable<Widget> getQuests(BuildContext context, int now) sync* {
    int? _getClosestClosedAt(Iterable<int> questIds, {required bool skipOutdated, int? eventEndedAt}) {
      List<int> closedAtTimes = <int>[?eventEndedAt];
      for (final questId in questIds) {
        final quest = runtime.gameData.timerData.allQuests[questId];
        if (quest == null) continue;
        if (skipOutdated && quest.closedAt < now) continue;
        closedAtTimes.add(quest.closedAt);
      }
      if (closedAtTimes.isEmpty) return null;
      return Maths.min(closedAtTimes);
    }

    Set<int> _shownQuestIds = {};
    Map<int, Servant> svtQuests = {
      for (final svt in db.gameData.servantsNoDup.values)
        for (final questId in svt.relateQuestIds) questId: svt,
    };
    const _kXInterlude = [91601804, 94054830, 94041930];
    bool _isQuestNeedClear(int questId, {bool checkSvt = true}) {
      if (mstData.isQuestClear(questId)) return false;
      if (_kXInterlude.contains(questId) && _kXInterlude.any(mstData.isQuestClear)) {
        return false;
      }

      final _quest = runtime.gameData.timerData.allQuests[questId];
      final jpQuest = db.gameData.quests[questId];
      final fbQuest = _quest ?? jpQuest;
      final war = runtime.gameData.timerData.wars[fbQuest?.warId] ?? fbQuest?.war;

      if (fbQuest != null) {
        if (fbQuest.type == QuestType.main &&
            war != null &&
            war.lastQuestId != 0 &&
            mstData.isQuestClear(war.lastQuestId)) {
          return false;
        }
        if (fbQuest.flags.contains(QuestFlag.branch) || fbQuest.flags.contains(QuestFlag.branchScenario)) {
          return false;
        }
        if (fbQuest.flags.contains(QuestFlag.raid)) return false;
      }

      final svt = svtQuests[questId];
      if (checkSvt && svt != null) {
        if (mstData.userSvtCollection[svt.id]?.isGet != true) return false;
        if (runtime.region != .jp) {
          final releasedAt =
              _quest?.openedAt ?? db.gameData.mappingData.questRelease[questId]?.ofRegion(runtime.region);
          if (releasedAt != null && releasedAt > now) return false;
        }
      }

      if (_quest != null) {
        if (questId == 94146202) {
          print(_quest.closedAt - (now - kSecsPerDay));
        }
        // Quest already outdated for 1day+
        if (_quest.closedAt < now - kSecsPerDay) return false;
      }
      return true;
    }

    // interlude campaign
    Set<int> _shownInterludes = {};
    for (final event in runtime.gameData.timerData.events.values) {
      if (event.startedAt > now || event.endedAt <= now) continue;
      for (final release in event.questReleaseOverwrites) {
        if (release.startedAt > now || release.endedAt <= now) continue;
        final userQuest = mstData.userQuest[release.questId];
        if (userQuest != null && userQuest.clearNum > 0) continue;
        final quest = db.gameData.quests[release.questId];
        if (quest == null) continue;

        final interludeSvt =
            db.gameData.servantsById[quest.releaseConditions
                .firstWhereOrNull((release) => const [CondType.svtGet, CondType.svtFriendship].contains(release.type))
                ?.targetId];
        // 谜之女主角X: 遭難者Ｘの帰還
        if (_kXInterlude.contains(quest.id) && _kXInterlude.any(mstData.isQuestClear)) {
          continue;
        }
        if (_shownInterludes.contains(quest.id)) continue;
        if (interludeSvt != null && mstData.userSvtCollection[interludeSvt.id]?.isGet == true) continue;
        _shownInterludes.add(quest.id);
        _shownQuestIds.add(quest.id);
        yield ListTile(
          dense: true,
          leading: interludeSvt?.iconBuilder(context: context),
          title: Text('[${S.current.interlude}] ${quest.lName.l}', maxLines: 1, overflow: TextOverflow.ellipsis),
          subtitle: Text(
            [
              if (interludeSvt != null && runtime.condCheck.isServantGet(interludeSvt.id)) kStarChar2,
              '${release.endedAt.sec2date().toCustomString(year: false, second: false)}:',
              'phase ${userQuest?.questPhase ?? "-"}',
              'clear ${userQuest?.clearNum ?? "-"}',
            ].join(' '),
          ),
          trailing: IconButton(
            onPressed: () {
              copyToClipboard(quest.id.toString(), toast: true);
            },
            icon: Icon(Icons.copy),
          ),
          onTap: quest.routeTo,
        );
      }
    }

    // event quests
    for (final event in runtime.gameData.timerData.events.values) {
      if (event.startedAt > now || event.endedAt <= now) continue;
      final hasMap = event.warIds.any((e) => db.gameData.wars[e]?.maps.isNotEmpty == true);
      if (hasMap && event.endedAt > now + 7 * kSecsPerDay) continue;
      Set<int> questIds = {...?db.gameData.others.eventQuestGroups[event.id]};
      for (final warId in event.warIds) {
        final war = db.gameData.wars[warId];
        if (war == null) continue;
        for (final quest in war.quests) {
          questIds.add(quest.id);
        }
        for (final selection in war.questSelections) {
          questIds.add(selection.quest.id);
        }
      }
      questIds.retainWhere(_isQuestNeedClear);
      if (questIds.isEmpty) continue;

      _shownQuestIds.addAll(questIds);
      final nextClosedAt =
          _getClosestClosedAt(questIds, skipOutdated: true, eventEndedAt: event.endedAt) ?? event.endedAt;
      yield ListTile(
        dense: true,
        leading: Icon(Icons.flag),
        title: Text(event.lShortName.l, overflow: TextOverflow.ellipsis),
        subtitle: Text(
          '${questIds.length} uncleared quests, ${nextClosedAt.sec2date().toCustomString(year: false, second: false)}',
        ),
        trailing: IconButton(
          onPressed: () => event.routeTo(region: runtime.region),
          icon: Icon(DirectionalIcons.keyboard_arrow_forward(context)),
        ),
        onTap: () {
          router.pushPage(QuestListPage.ids(ids: questIds.toList(), mstData: mstData, onSelected: _onSelectQuest));
        },
      );
    }

    // quest campaign
    for (final event in runtime.gameData.timerData.events.values) {
      if (event.startedAt > now || event.endedAt <= now) continue;
      for (final campaign in event.campaigns) {
        if (!const [
          CombineAdjustTarget.questAp,
          CombineAdjustTarget.questApFirstTime,
          CombineAdjustTarget.questItemFirstTime,
        ].contains(campaign.target)) {
          continue;
        }
        final questIds = [
          for (final campaignQuest in event.campaignQuests)
            if (!campaignQuest.isExcepted && campaignQuest.questId != 0) campaignQuest.questId,
        ];
        final uncleared = questIds.where((questId) {
          if (!_isQuestNeedClear(questId)) return false;
          final jpQuest = db.gameData.quests[questId];
          if (jpQuest != null) {
            if (jpQuest.warId == WarId.daily) return false;
          }
          return true;
        }).toList();
        if (event.id == 71619) {
          uncleared.removeWhere((e) => const [94002702, 94002701, 94005501, 94008401, 913300101, 93040451].contains(e));
        }
        if (event.name.contains('期間限定 ストーム・ポッド消費なし！') || event.name.contains('限时 不消耗风暴罐！')) {
          if (campaign.target == .questAp && campaign.value == 1000) {
            uncleared.retainWhere((e) => db.gameData.quests.containsKey(e));
          }
        }

        if (uncleared.isEmpty) continue;
        _shownQuestIds.addAll(uncleared);

        final nextClosedAt =
            _getClosestClosedAt(uncleared, skipOutdated: true, eventEndedAt: event.endedAt) ?? event.endedAt;

        yield ListTile(
          dense: true,
          leading: Icon(Icons.map),
          title: Text(event.lShortName.l, maxLines: 1, overflow: TextOverflow.ellipsis),
          subtitle: Text(
            '${uncleared.length}/${questIds.length} uncleared, ${nextClosedAt.sec2date().toCustomString(year: false, second: false)}',
          ),
          trailing: IconButton(
            onPressed: () => event.routeTo(region: runtime.region),
            icon: Icon(DirectionalIcons.keyboard_arrow_forward(context)),
          ),
          onTap: () {
            router.pushPage(QuestListPage.ids(ids: uncleared, mstData: mstData, onSelected: _onSelectQuest));
          },
        );
      }
    }

    // no war event quests
    final timerQuests = runtime.gameData.timerData.allQuests.values
        .where(
          (quest) =>
              isTimeOpen(quest.openedAt, quest.closedAt, now) &&
              quest.closedAt < now + 365 * kSecsPerDay &&
              !mstData.isQuestClear(quest.id) &&
              !const [WarId.interlude].contains(quest.warId) &&
              !quest.isRepeatRaid &&
              !_shownQuestIds.contains(quest.id) &&
              quest.type != QuestType.friendship &&
              quest.warId != WarId.rankup &&
              _isQuestNeedClear(quest.id),
        )
        .toList();
    if (timerQuests.isNotEmpty) {
      yield ListTile(
        dense: true,
        leading: Icon(Icons.flag),
        title: Text('Event quests', maxLines: 1, overflow: TextOverflow.ellipsis),
        subtitle: Text(
          '${timerQuests.length} uncleared, ${Maths.min(timerQuests.map((e) => e.closedAt)).sec2date().toCustomString(year: false, second: false)}',
        ),
        onTap: () {
          router.pushPage(QuestListPage(quests: timerQuests, mstData: mstData, onSelected: _onSelectQuest));
        },
      );
    }
  }

  List<Widget> getOthers(BuildContext context, int now) {
    List<Widget> children = [];

    // coin room
    final userCoinRoom = mstData.userCoinRoom.firstOrNull;
    final maxCoinRoomNum = runtime.gameData.timerData.constants.coinRoomMaxNum;
    if (userCoinRoom != null && userCoinRoom.num < maxCoinRoomNum) {
      children.add(
        ListTile(
          dense: true,
          leading: Item.iconBuilder(context: context, item: Items.grail, width: 32),
          title: Text(S.current.holy_grail_casting),
          onTap: () => router.pushPage(CoinRoomPage(runtime: runtime)),
          trailing: Text(
            [
              '${userCoinRoom.num}/$maxCoinRoomNum/${userCoinRoom.totalNum}',
              if (userCoinRoom.cnt != 0) '${S.current.servant_coin_short} ${userCoinRoom.cnt}',
            ].join('\n'),
            textAlign: TextAlign.end,
          ),
        ),
      );
    }

    // EXP x3 x4
    for (final event in runtime.gameData.timerData.events.values) {
      if (event.startedAt > now || event.endedAt <= now) continue;
      final hasSvtEquipExp3 = event.campaigns.any((e) => e.target == .svtequipSuperSuccess && e.value > 2000);
      if (hasSvtEquipExp3) {
        children.add(
          ListTile(
            dense: true,
            title: Text(event.lName.l),
            subtitle: Text(event.endedAt.sec2date().toCustomString(year: false, second: false)),
            trailing: Icon(DirectionalIcons.keyboard_arrow_forward(context)),
            onTap: () => event.routeTo(region: runtime.region),
          ),
        );
      }
    }

    return children;
  }

  void _onSelectQuest(int questId, Quest? quest) {
    runtime.lockTask(() async {
      await runtime.battle.selectQuest(questId, quest: quest);
    });
  }
}
