import 'dart:convert';

import 'package:flutter/gestures.dart';

import 'package:flutter_easyloading/flutter_easyloading.dart';

import 'package:chaldea/app/app.dart';
import 'package:chaldea/app/descriptors/mission_conds.dart';
import 'package:chaldea/app/modules/common/builders.dart';
import 'package:chaldea/app/modules/common/filter_group.dart';
import 'package:chaldea/app/modules/master_mission/master_mission.dart';
import 'package:chaldea/app/modules/master_mission/solver/custom_mission.dart';
import 'package:chaldea/app/modules/master_mission/solver/scheme.dart';
import 'package:chaldea/generated/l10n.dart';
import 'package:chaldea/models/models.dart';
import 'package:chaldea/packages/platform/platform.dart';
import 'package:chaldea/utils/utils.dart';
import 'package:chaldea/widgets/widgets.dart';

import '../_shared/faker_ui.dart';
import '../runtime.dart';

const int kAnyCardGiftId = -1;

class UserEventMissionReceivePage extends StatefulWidget {
  final FakerRuntime runtime;
  final int? initId;
  const UserEventMissionReceivePage({super.key, required this.runtime, this.initId});

  @override
  State<UserEventMissionReceivePage> createState() => _UserEventMissionReceivePageState();
}

class _UserEventMissionReceivePageState extends State<UserEventMissionReceivePage> with FakerRuntimeStateMixin {
  @override
  late final runtime = widget.runtime;
  final thisYear = DateTime.now().year;
  List<MasterMission> mms = [];
  Map<int, EventMission> eventMissions = {};
  // late final mms = runtime.gameData.masterMissions.values.toList();

  MasterMission? _mm;

  Set<int> selectedMissions = {};

  List<int> giftObjectIds = [];
  final havingGifts = FilterGroupData<int>();
  final notHavingGifts = FilterGroupData<int>();
  final progressFilter = FilterGroupData<MissionProgressType>();

  late final scrollController = ScrollController();

  @override
  void initState() {
    super.initState();
    initData();
  }

  Future<void> initData() async {
    final _mms = Map.of(runtime.gameData.timerData.masterMissions);
    final now = DateTime.now().timestamp;

    _mms.removeWhere((_, mm) {
      if (mm.id == widget.initId) return false;
      if (const [MissionType.event, MissionType.random].contains(mm.type)) return true;
      if (mm.startedAt > now || mm.closedAt < now) return true;
      if (mm.type == MissionType.daily) {
        if (mm.endedAt < now - kSecsPerDay * 40) return true;
      }
      return false;
    });

    for (final event in runtime.gameData.timerData.events.values) {
      if (!(event.startedAt <= now && event.endedAt > now && event.missions.isNotEmpty)) continue;
      List<EventMission> _eventMissions = [], _randomMissions = [];
      for (final mission in event.missions) {
        if (mission.type == MissionType.random) {
          if (mstData.userEventRandomMission[mission.id]?.isInProgress == true) {
            _randomMissions.add(mission);
          }
        } else {
          _eventMissions.add(mission);
        }
      }
      if (_eventMissions.isNotEmpty) {
        _mms[event.id] ??= MasterMission(
          id: event.id,
          startedAt: event.startedAt,
          endedAt: event.endedAt,
          closedAt: event.endedAt,
          missions: _eventMissions,
          script: {MstMasterMission.kMissionIconDetailText: event.lShortName.l.setMaxLines(1)},
        );
      }
      if (_randomMissions.isNotEmpty) {
        _mms[event.id * 100 + 1] ??= MasterMission(
          id: event.id * 100 + 1,
          startedAt: event.startedAt,
          endedAt: event.endedAt,
          closedAt: event.endedAt,
          missions: _randomMissions,
          script: {
            MstMasterMission.kMissionIconDetailText:
                '[${S.current.random_mission}] ${event.lShortName.l.setMaxLines(1)}',
          },
        );
      }
    }

    // mms.removeWhere((mm) => mm.type == MissionType.daily && mm.endedAt - mm.startedAt > kSecsPerDay * 40);
    mms = _mms.values.toList();
    eventMissions = {
      for (final mm in mms)
        for (final m in mm.missions) m.id: m,
    };
    mms.sortByList((e) => [e.endedAt, e.closedAt, e.id]);
    if (mms.isNotEmpty) {
      MasterMission? mm;
      if (widget.initId != null) {
        mm = mms.firstWhereOrNull((e) => e.id == widget.initId);
      }
      mm ??= mms.firstWhere(
        (mm) => mm.missions.any((e) => getMissionProgress(e.id) != MissionProgressType.achieve),
        orElse: () => mms.first,
      );
      onSelectMM(mm);
    }
    if (mounted) setState(() {});
  }

  MissionProgressType getMissionProgress(int eventMissionId) {
    return runtime.condCheck.getEventMissionProgress(eventMissionId);
  }

  bool isMissionClear(int eventMissionId) => getMissionProgress(eventMissionId) == MissionProgressType.clear;

  void onSelectMM(MasterMission mm) {
    if (_mm != mm) {
      selectedMissions.clear();
    }
    _mm = mm;
    giftObjectIds = mm.missions.expand((e) => e.gifts).map((e) => e.objectId).toSet().toList();
    if (mm.id == MasterMission.kExtraMasterMissionId) {
      final clearGifts = mm.missions
          .where((e) => isMissionClear(e.id))
          .expand((e) => e.gifts)
          .map((e) => e.objectId)
          .toSet();
      giftObjectIds.sortByList((e) => [clearGifts.contains(e) ? 0 : 1, e]);
      giftObjectIds.sort((a, b) {
        final r = (clearGifts.contains(a) ? 0 : 1).compareTo((clearGifts.contains(b) ? 0 : 1));
        if (r != 0) return r;
        return Item.compare2(a, b);
      });
    } else {
      giftObjectIds.sort(Item.compare2);
    }
    if (mm.id == MasterMission.kExtraMasterMissionId) {
      giftObjectIds.insert(0, kAnyCardGiftId);
    }
    havingGifts.options.retainAll(giftObjectIds);
    notHavingGifts.options.retainAll(giftObjectIds);
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    selectedMissions.retainWhere(isMissionClear);
    final missions = (_mm?.missions ?? const []).where((mission) {
      final gifts = mission.gifts.map((e) => e.objectId).toSet();
      if (gifts.any((id) => db.gameData.entities.containsKey(id))) gifts.add(kAnyCardGiftId);
      if (havingGifts.isNotEmpty && !havingGifts.matchAny(gifts)) return false;
      if (notHavingGifts.isNotEmpty && notHavingGifts.matchAny(gifts)) return false;
      if (!progressFilter.matchOne(getMissionProgress(mission.id))) return false;
      return true;
    }).toList();
    missions.sort2((e) => e.dispNo);
    final solvable = _collectSolvable(_mm);
    return Scaffold(
      appBar: AppBar(
        title: Text(S.current.master_mission),
        actions: [
          if (_mm != null) ...[
            IconButton(
              onPressed: solvable.merged.isEmpty ? null : solveMissions,
              icon: const Icon(Icons.calculate),
              tooltip: S.current.drop_calc_solve,
            ),
            IconButton(
              onPressed: () {
                router.push(
                  url: Routes.masterMissionI(_mm!.id),
                  child: MasterMissionPage(masterMission: _mm, region: runtime.region),
                );
              },
              icon: Icon(Icons.info_outline),
            ),
          ],
          runtime.buildMenuButton(context),
        ],
      ),
      body: FakerTileTheme(
        child: Column(
          children: [
            buildHeader(),
            Expanded(
              child: Scrollbar(
                trackVisibility: PlatformU.isDesktopOrWeb,
                controller: scrollController,
                child: ListView.builder(
                  controller: scrollController,
                  itemCount: missions.length,
                  itemBuilder: (context, index) {
                    return buildEventMission(missions[index], missions);
                  },
                ),
              ),
            ),
            SafeArea(child: buildButtonBar(missions)),
          ],
        ),
      ),
    );
  }

  Widget buildHeader() {
    Widget child = DropdownButton<MasterMission>(
      isExpanded: true,
      value: _mm,
      items: [for (final mm in mms) DropdownMenuItem(value: mm, child: buildMasterMission(mm))],
      onChanged: (v) {
        setState(() {
          if (v != null) onSelectMM(v);
        });
      },
    );
    return Container(
      color: Theme.of(context).highlightColor,
      padding: EdgeInsets.only(bottom: 8),
      child: DropdownButtonHideUnderline(child: child),
    );
  }

  Widget buildMasterMission(MasterMission mm) {
    int clearNum = mm.missions.where((e) => getMissionProgress(e.id) == MissionProgressType.clear).length;
    int achieveNum = mm.missions.where((e) => getMissionProgress(e.id) == MissionProgressType.achieve).length;
    int notClearNum = mm.missions.length - clearNum - achieveNum;
    final now = DateTime.now().timestamp;
    return ListTile(
      dense: true,
      selected: (clearNum > 0 || notClearNum > 0) && mm.startedAt < now && mm.endedAt > now,
      enabled: !(notClearNum == 0 && clearNum == 0),
      title: Text(
        '[${mm.missions.length} ${Transl.enums(mm.type, (v) => v.missionType).l}] ID ${mm.id} ${mm.lMissionIconDetailText ?? ""}',
        maxLines: 2,
        overflow: TextOverflow.ellipsis,
        textScaler: const TextScaler.linear(0.9),
      ),
      subtitle: Text(
        [mm.startedAt, mm.endedAt, if (mm.closedAt != mm.endedAt) mm.closedAt]
            .map((e) {
              final date = e.sec2date();
              return mm.id == MasterMission.kExtraMasterMissionId
                  ? date.toDateString()
                  : date.toCustomString(year: date.year != thisYear, second: false);
            })
            .join(' ~ '),
      ),
      trailing: Text('$notClearNum/$clearNum/$achieveNum'),
    );
  }

  Widget buildEventMission(EventMission mission, List<EventMission> missions) {
    Widget title = Text.rich(
      TextSpan(
        text: '${mission.dispNo}. ${mission.name}',
        recognizer: TapGestureRecognizer()
          ..onTap = () {
            SimpleConfirmDialog(
              title: Text('No.${mission.dispNo} (${mission.id})'),
              scrollable: true,
              showCancel: false,
              content: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(mission.name, style: Theme.of(context).textTheme.bodySmall),
                  if (mission.startedAt != _mm?.startedAt || mission.endedAt != _mm?.endedAt) ...[
                    const Divider(),
                    Text(
                      [
                        mission.startedAt,
                        mission.endedAt,
                      ].map((e) => e.sec2date().toStringShort(omitSec: true)).join(' ~ '),
                    ),
                  ],
                  const Divider(),
                  MissionCondsDescriptor(mission: mission, missions: missions),
                ],
              ),
            ).showDialog(context);
          },
      ),
      maxLines: 2,
      overflow: TextOverflow.ellipsis,
    );

    Widget subtitle = Column(
      crossAxisAlignment: .start,
      mainAxisSize: .min,
      children: [
        if (mission.endedAt != _mm?.endedAt) Text('~ ${mission.endedAt.sec2date().toStringShort()}'),
        Wrap(
          spacing: 1,
          runSpacing: 1,
          crossAxisAlignment: WrapCrossAlignment.center,
          children: [for (final gift in mission.gifts) gift.iconBuilder(context: context, width: 32)],
        ),
      ],
    );

    // random mission not checked
    final progressType = getMissionProgress(mission.id);

    Widget trailing;
    if (progressType == MissionProgressType.clear) {
      trailing = Checkbox(
        visualDensity: VisualDensity.compact,
        materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
        value: selectedMissions.contains(mission.id),
        onChanged: (v) {
          setState(() {
            if (v!) {
              selectedMissions.add(mission.id);
            } else {
              selectedMissions.remove(mission.id);
            }
          });
        },
      );
    } else {
      int? progressNum, targetNum;
      final eventMissionFix = mstData.userEventMissionFix[mission.id];
      if (eventMissionFix != null) {
        // progressType=eventMissionFix.progressType;
        progressNum = eventMissionFix.num;
      }
      for (final cond in mission.conds) {
        if (cond.missionProgressType != MissionProgressType.clear) continue;
        final _progressNum = runtime.condCheck.getEventMissionProgressNum(
          cond.condType,
          cond.targetIds,
          cond.targetNum,
        );
        progressNum ??= _progressNum;
        if (_progressNum == null) continue; // don't set targetNum
        targetNum = cond.targetNum;
      }

      trailing = Text(
        [
          progressType.name,
          if (progressNum != null || targetNum != null) '${progressNum ?? "?"}/${targetNum ?? "?"}',
        ].join('\n'),
        textAlign: TextAlign.end,
      );
    }
    return ListTileTheme.merge(
      key: ObjectKey(mission),
      dense: true,
      minLeadingWidth: 16,
      child: ListTile(
        title: title,
        subtitle: subtitle,
        enabled: shouldShowEnable(mission, progressType),
        trailing: trailing,
        onTap: () {
          setState(() {
            if (progressType == MissionProgressType.clear) selectedMissions.toggle(mission.id);
          });
        },
      ),
    );
  }

  bool shouldShowEnable(EventMission mission, MissionProgressType progressType) {
    if (progressType.isClearOrAchieve) return true;
    for (final cond in mission.conds) {
      if (const [MissionProgressType.openCondition, MissionProgressType.start].contains(cond.missionProgressType)) {
        if (runtime.condCheck.isCondOpen2(cond.condType, cond.targetIds, cond.targetNum) ?? true) {
          return true;
        }
      }
    }
    return false;
  }

  Widget buildButtonBar(List<EventMission> shownMissions) {
    final clearIds = [
      for (final mission in shownMissions)
        if (isMissionClear(mission.id)) mission.id,
    ];
    final allSelected = clearIds.isNotEmpty && clearIds.every(selectedMissions.contains);
    final showSelectAll = _mm != null && _mm!.id != MasterMission.kExtraMasterMissionId && _mm!.type != .daily;
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        for (final (title, filterData) in [(S.current.show, havingGifts), (S.current.hide, notHavingGifts)])
          Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              SizedBox(width: 16),
              ConstrainedBox(constraints: BoxConstraints(minWidth: 48), child: Text(title)),
              Expanded(
                child: SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: FilterGroup<int>(
                    options: giftObjectIds,
                    values: filterData,
                    padding: EdgeInsets.zero,
                    combined: true,
                    shrinkWrap: true,
                    optionBuilder: (v) {
                      if (v == kAnyCardGiftId) {
                        return GameCardMixin.cardIconBuilder(
                          context: context,
                          icon: Atlas.assetItem(4),
                          height: 36,
                          padding: const EdgeInsets.all(2),
                        );
                      }
                      return GameCardMixin.anyCardItemBuilder(
                        context: context,
                        id: v,
                        height: 36,
                        padding: EdgeInsets.all(2),
                        jumpToDetail: false,
                      );
                    },
                    onFilterChanged: (_, _) {
                      setState(() {});
                    },
                  ),
                ),
              ),
            ],
          ),
        const SizedBox(height: 4),
        FilterGroup<MissionProgressType>(
          options: const [MissionProgressType.none, MissionProgressType.clear, MissionProgressType.achieve],
          values: progressFilter,
          padding: EdgeInsets.only(bottom: 4),
          combined: true,
          optionBuilder: (v) => Text(v.name),
          onFilterChanged: (v, _) {
            setState(() {});
          },
        ),
        FakerActionBar(
          groups: [
            [
              if (showSelectAll) const SizedBox(width: 48),
              FilledButton(
                onPressed: selectedMissions.isEmpty ? null : receiveMissions,
                child: Text('Receive ×${selectedMissions.length}'),
              ),
              if (showSelectAll)
                IconButton(
                  onPressed: clearIds.isEmpty
                      ? null
                      : () {
                          setState(() {
                            if (allSelected) {
                              selectedMissions.removeAll(clearIds);
                            } else {
                              selectedMissions.addAll(clearIds);
                            }
                          });
                        },
                  icon: Icon(allSelected ? Icons.check_box : Icons.square_outlined),
                  tooltip: 'Select all',
                ),
            ],
          ],
        ),
        const SizedBox(height: 4),
      ],
    );
  }

  Future<void> receiveMissions() async {
    final missions = {
      if (_mm != null)
        for (final m in _mm!.missions) m.id: m,
    };
    final gifts = <int, int>{};
    if (selectedMissions.isEmpty || !selectedMissions.every((e) => missions.containsKey(e))) {
      EasyLoading.showError('Another mm mission is selected');
      return;
    }
    if (!selectedMissions.every(isMissionClear)) {
      EasyLoading.showError('Contain non-clear progress mission');
      return;
    }
    for (final id in selectedMissions) {
      for (final gift in missions[id]!.gifts) {
        gifts.addNum(gift.objectId, gift.num);
      }
    }
    if (runtime.runningTask.value) return;
    SimpleConfirmDialog(
      title: Text('Receive ${selectedMissions.length} missions'),
      scrollable: true,
      content: SharedBuilder.itemGrid(context: context, items: gifts.entries.toList(), height: 36),
      onTapOk: () async {
        await runtime.runTask(() => runtime.agent.eventMissionClearReward(missionIds: selectedMissions.toList()));
        selectedMissions.retainWhere(isMissionClear);
        if (mounted) setState(() {});
      },
    ).showDialog(context);
  }

  /// Unfinished missions of [mm] that the custom-mission solver can convert, merged by condition key.
  /// An empty result means nothing to solve — also drives the solve button's disabled state.
  ({Map<String, CustomMission> merged, List<EventMission> multiDetailMissions}) _collectSolvable(MasterMission? mm) {
    final merged = <String, CustomMission>{};
    final multiDetailMissions = <EventMission>[];
    for (final mission in mm?.missions ?? <EventMission>[]) {
      if (getMissionProgress(mission.id).isClearOrAchieve) continue;
      final customMission = CustomMission.fromEventMission(mission);
      if (customMission == null) continue;
      // Match the first condition that fromEventMission can actually convert.
      final cond = mission.conds.firstWhereOrNull((cond) {
        return cond.missionProgressType == MissionProgressType.clear &&
            cond.condType == CondType.missionConditionDetail &&
            cond.details.any((detail) {
              final type = CustomMission.kDetailCondMapping[detail.missionCondType];
              return type != null &&
                  !(type == CustomMissionType.quest && detail.targetIds.length == 1 && detail.targetIds.first == 0);
            });
      });
      if (cond == null) continue;
      customMission.count =
          (cond.targetNum -
                  (runtime.condCheck.getEventMissionProgressNum(cond.condType, cond.targetIds, cond.targetNum) ?? 0))
              .clamp(0, cond.targetNum);
      if (customMission.count == 0) continue;
      if (cond.details.length > 1) multiDetailMissions.add(mission);
      final key = _missionConditionKey(customMission);
      final previous = merged[key];
      if (previous == null || customMission.count > previous.count) merged[key] = customMission;
    }
    return (merged: merged, multiDetailMissions: multiDetailMissions);
  }

  Future<void> solveMissions() async {
    final mm = _mm;
    final solvable = _collectSolvable(mm);
    final merged = solvable.merged;
    if (merged.isEmpty) {
      await SimpleConfirmDialog(
        title: Text(S.current.drop_calc_solve),
        content: const Text('No solvable unfinished missions.'),
        showCancel: false,
      ).showDialog(context);
      return;
    }
    if (solvable.multiDetailMissions.isNotEmpty) {
      final confirmed = await SimpleConfirmDialog(
        title: const Text('Multiple mission condition details'),
        scrollable: true,
        content: Text(
          [
            'These missions contain multiple details. Remaining counts use the first detail progress.',
            for (final mission in solvable.multiDetailMissions) '${mission.dispNo}. ${mission.name}',
          ].join('\n'),
        ),
      ).showDialog(context);
      if (confirmed != true || !mounted || _mm != mm) return;
    }
    if (mm == null) return;
    int? warId;
    final event =
        runtime.gameData.timerData.events[mm.id] ??
        runtime.gameData.timerData.events.values.firstWhereOrNull(
          (event) => event.missions.any((mission) => mission.id == mm.missions.firstOrNull?.id),
        );
    if (event != null) {
      for (final id in event.warIds) {
        if (db.gameData.wars[id]?.quests.any((quest) => quest.isAnyFree) == true) {
          warId = id;
          break;
        }
      }
    } else if (runtime.region != Region.jp) {
      final wars = db.gameData.mappingData.warRelease.ofRegion(runtime.region)?.where((id) => id < 1000).toList();
      if (wars != null && wars.isNotEmpty) warId = Maths.max(wars);
    }
    router.push(
      child: CustomMissionPage(initMissions: merged.values.toList(), initWarId: warId),
    );
  }

  String _missionConditionKey(CustomMission mission) {
    final conds = mission.conds.map((cond) {
      final ids = cond.targetIds.toList()..sort();
      return jsonEncode([cond.type.name, cond.useAnd, ids]);
    }).toList()..sort();
    return jsonEncode([mission.condAnd, mission.enemyDeckOnly, conds]);
  }
}
