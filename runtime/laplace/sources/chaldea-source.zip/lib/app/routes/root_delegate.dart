import 'package:flutter/foundation.dart';

import 'package:material_ui/material_ui.dart';

import 'package:chaldea/models/db.dart';
import 'package:chaldea/packages/platform/platform.dart';
import 'package:chaldea/utils/constants.dart';

import '../../packages/method_channel/method_channel_chaldea.dart';
import '../modules/root/window_manager.dart';
import 'delegate.dart';
import 'routes.dart';

enum WindowStateEnum {
  single,
  windowManager,
  screenshot;

  bool get isSingle => this == single;
}

class AppState extends ChangeNotifier {
  final RootAppRouterDelegate _root;
  late final List<AppRouterDelegate> _children;

  AppState(this._root) {
    addListener(_root.notifyListeners);
    _children = [AppRouterDelegate(_root)];
  }

  /// windows(routers)
  List<AppRouterDelegate> get children => List.unmodifiable(_children);

  int get activeIndex => _activeIndex.clamp(0, _children.length);
  int _activeIndex = 0;

  AppRouterDelegate get activeRouter => _children[activeIndex];

  set activeIndex(int index) {
    if (index >= 0 && index < _children.length && index != _activeIndex) {
      _activeIndex = index;
      notifyListeners();
    }
  }

  int addWindow() {
    _children.add(AppRouterDelegate(_root));
    _activeIndex = _children.length - 1;
    notifyListeners();
    return _activeIndex;
  }

  int removeWindow(int index) {
    assert(index >= 0 && index < _children.length);
    if (index < 0 || index >= _children.length) {
      return -1;
    }
    if (_children.length == 1) return -1;
    final active = activeRouter;
    final int _oldIndex = _activeIndex;
    final removedChild = _children.removeAt(index);
    int newIndex = _children.indexOf(active);
    _activeIndex = newIndex >= 0 ? newIndex : _oldIndex.clamp(0, _children.length - 1);
    removedChild.popAll();
    notifyListeners();
    return _activeIndex;
  }

  void onReorderItem(int oldIndex, int newIndex) {
    final _activeChild = activeRouter;
    final child = _children.removeAt(oldIndex);
    _children.insert(newIndex, child);
    _activeIndex = _children.indexOf(_activeChild);
    notifyListeners();
  }

  WindowStateEnum _windowState = WindowStateEnum.single;
  WindowStateEnum get windowState => _windowState;
  set windowState(WindowStateEnum v) {
    _windowState = v;
    notifyListeners();
  }

  /// _showSidebar
  bool get showSidebar => _showSidebar;
  bool _showSidebar = true;

  set showSidebar(bool v) {
    _showSidebar = v;
    notifyListeners();
  }

  /// _dataReady
  bool get dataReady => _dataReady;
  bool _dataReady = false;

  set dataReady(bool v) {
    _dataReady = v;
    // If data not loaded, only show home page
    if (db.gameData.version.timestamp == 0) {
      activeRouter.popAll();
    }
    notifyListeners();
  }

  bool get consentPending => _consentPending;
  bool _consentPending = false;

  set consentPending(bool v) {
    if (_consentPending == v) return;
    _consentPending = v;
    notifyListeners();
  }
}

class RootAppRouterDelegate extends RouterDelegate<RouteConfiguration>
    with ChangeNotifier, PopNavigatorRouterDelegateMixin<RouteConfiguration> {
  late final AppState appState = AppState(this);

  RootAppRouterDelegate();

  @override
  RouteConfiguration? get currentConfiguration {
    final v = appState.activeRouter.currentConfiguration;
    return v;
  }

  @override
  Widget build(BuildContext context) {
    Widget child = WindowManager(delegate: this);
    if (db.settings.remoteConfig.isSilence == true) {
      child = ColorFiltered(
        colorFilter: const ColorFilter.matrix(<double>[
          // grey scale
          0.2126, 0.7152, 0.0722, 0, 0,
          0.2126, 0.7152, 0.0722, 0, 0,
          0.2126, 0.7152, 0.0722, 0, 0,
          0, 0, 0, 1, 0,
        ]),
        child: child,
      );
    }
    if (PlatformU.isAndroid) {
      // Keep system back in Flutter even when the outer Navigator or an inactive
      // child cannot pop. The active child router handles navigation and backgrounding.
      child = PopScope(canPop: false, child: child);
    }
    return Navigator(
      key: navigatorKey,
      pages: [MaterialPage(child: child)],
      onDidRemovePage: (page) {
        if (!appState.windowState.isSingle) {
          appState.windowState = WindowStateEnum.single;
        }
        notifyListeners();
      },
    );
  }

  @override
  GlobalKey<NavigatorState> get navigatorKey => kAppKey;

  @override
  Future<void> setNewRoutePath(RouteConfiguration configuration) {
    return appState.activeRouter.setNewRoutePath(configuration);
  }

  @override
  Future<bool> popRoute() async {
    if (PlatformU.isAndroid) {
      await db.saveAll();
      MethodChannelChaldea.sendBackground();
      return true;
    }
    return SynchronousFuture(true);
  }
}
