import 'package:auto_size_text/auto_size_text.dart';

import 'package:chaldea/app/app.dart';
import 'package:chaldea/app/battle/utils/battle_utils.dart' show BattleUtils;
import 'package:chaldea/app/modules/common/builders.dart';
import 'package:chaldea/app/modules/common/filter_group.dart';
import 'package:chaldea/generated/l10n.dart';
import 'package:chaldea/models/models.dart';
import 'package:chaldea/packages/language.dart';
import 'package:chaldea/utils/atlas.dart';
import 'package:chaldea/utils/basic.dart';
import 'package:chaldea/utils/constants.dart';
import 'package:chaldea/utils/extension.dart';
import 'package:chaldea/widgets/widgets.dart';

import '../common/filter_page_base.dart';
import '../servant/filter.dart';

const _kExtraPlayableSvtIds = <int>[505700];
const int _kHiddenRate = -1000;

typedef _GroupItem = ({int rateCount, List<int> ceIds, List<({Servant svt, List<int> limitCounts})> svts});

class EquipBondBonusTab extends StatefulWidget {
  final List<Servant> targetSvts;
  const EquipBondBonusTab({super.key, this.targetSvts = const []});

  static Widget scaffold({List<Servant>? targetSvts}) {
    return Scaffold(
      appBar: AppBar(title: Text(S.current.bond_bonus)),
      body: EquipBondBonusTab(targetSvts: targetSvts ?? const []),
    );
  }

  @override
  State<EquipBondBonusTab> createState() => _EquipBondBonusTabState();
}

enum _FilterType {
  none,
  include,
  exclude,
  hide;

  Color? get color {
    return switch (this) {
      none => Colors.grey,
      include => Colors.blue,
      exclude => Colors.red,
      hide => Colors.grey,
    };
  }

  String get shownName {
    if (Language.isZH) {
      return switch (this) {
        none => '默认',
        include => '包含',
        exclude => '排除',
        hide => '隐藏',
      };
    } else {
      return switch (this) {
        none => 'default',
        _ => name,
      };
    }
  }

  String get hint {
    if (Language.isZH) {
      return switch (this) {
        none => '默认',
        include => '必须享受到该礼装加成',
        exclude => '必须不能被该礼装的加成',
        hide => '不显示该礼装',
      };
    } else {
      return switch (this) {
        none => 'default',
        include => 'MUST have bonus from this CE',
        exclude => 'MUST NOT have bonus from this CE',
        hide => 'Hide the CE',
      };
    }
  }
}

class _ExtraFilterData {
  final ceStates = <int, _FilterType>{};
  bool useCostumeTraitForRegion = false;
  final maxRateCountPerSvt = FilterRadioData<int>();
}

/// functvals: traits
/// DataVals: [RateCount], [AddCount] (ignore)
class _EquipBondBonusTabState extends State<EquipBondBonusTab> {
  late final _targetSvts = {for (final svt in widget.targetSvts) svt.id: svt};
  Map<int, ({CraftEssence ce, List<List<int>> traits, int rateCount})> allCeData = {};
  Map<int, Map<int, List<int>>> allCeMatchSvtData = {}; //<ceId, <svtId, [limitCount]>>
  Map<int, Map<int, List<int>>> allSvtMatchCeData = {}; //<svtId, <limitId, [ceIds]>>
  int maxTotalRateCount = 1000;

  final svtFilterData = SvtFilterData(sortKeys: SvtCompare.kRarityFirstKeys);
  final extraFilterData = _ExtraFilterData();

  _FilterType getCeState(int ceId) => extraFilterData.ceStates[ceId] ??= _FilterType.none;

  List<Servant> getAllSvts() {
    return _targetSvts.isNotEmpty
        ? _targetSvts.values.toList()
        : db.gameData.servantsById.values
              .where((e) => e.collectionNo > 0 || _kExtraPlayableSvtIds.contains(e.id))
              .toList();
  }

  @override
  void initState() {
    super.initState();
    initData(initFilters: true);
  }

  void initData({bool initFilters = false}) {
    allCeData.clear();
    allCeMatchSvtData.clear();
    allSvtMatchCeData.clear();
    // ce data
    for (final ce in db.gameData.craftEssencesById.values) {
      if (ce.collectionNo <= 0 || ce.isRegionSpecific) continue;
      if (ce.rarity < 5) continue;
      final skills = ce.getActivatedSkills(true)[1] ?? <NiceSkill>[];
      if (skills.isEmpty) continue;
      if (skills.length > 1) {
        print('CE ${ce.collectionNo} has ${skills.length} bond bonus skills, skip');
        continue;
      }
      final skill = skills.single;
      final funcs = [
        for (final func in skill.functions)
          if (func.funcType == FuncType.servantFriendshipUp &&
              (func.svals.firstOrNull?.EventId ?? 0) == 0 &&
              (func.functvals.isNotEmpty || func.overWriteTvalsList.isNotEmpty))
            func,
      ];
      if (funcs.isEmpty) continue;
      if (funcs.length > 1) {
        print('CE ${ce.collectionNo} skill ${skill.id} ${funcs.length} bond bonus functions, skip');
        continue;
      }
      final func = funcs.single;
      final rateCount = func.svals.firstOrNull?.RateCount ?? 0;
      if (rateCount <= 0) continue;
      // 英霊逢魔: 1973-1979, FSN servant +10%
      if (ce.collectionNo >= 1973 && ce.collectionNo <= 1979) continue;
      allCeData[ce.id] = (
        ce: ce,
        traits: func.overWriteTvalsList.isEmpty ? func.functvals.map((e) => [e]).toList() : func.overWriteTvalsList,
        rateCount: rateCount,
      );
    }

    sortDict(allCeData, inPlace: true, compare: (a, b) => a.value.ce.collectionNo.compareTo(b.value.ce.collectionNo));

    // ce mapping svt
    final svts = getAllSvts();
    for (final (:ce, :traits, rateCount: _) in allCeData.values) {
      final svtLimitsData = allCeMatchSvtData[ce.id] ??= {};
      for (final svt in svts) {
        final limitCounts = getMatchedLimitCounts(svt, traits);
        if (limitCounts.isEmpty) continue;
        svtLimitsData[svt.id] = limitCounts;
      }
    }
    // svt mapping ce
    for (final (ceId, svtLimits) in allCeMatchSvtData.items) {
      for (final (svtId, limits) in svtLimits.items) {
        for (final limit in limits) {
          ((allSvtMatchCeData[svtId] ??= {})[limit] ??= []).add(ceId);
        }
      }
    }

    if (initFilters) {
      // hide unreleased ces
      for (final ceId in allCeData.keys) {
        if (!isCeReleased(ceId, db.curUser.region)) {
          extraFilterData.ceStates[ceId] = _FilterType.hide;
        }
      }
    }
  }

  List<int> getMatchedLimitCounts(Servant svt, List<List<int>> bonusTraitsList) {
    final region = svtFilterData.region.radioValue;

    final baseTraits = svt.traits;
    List<int> matchedLimitCounts = [];
    final allLimitCounts = _getSvtAllLimits(svt);
    for (final limitCount in allLimitCounts) {
      List<int> resultTraits = svt.ascensionAdd.individuality2.all[limitCount] ?? [];
      if (resultTraits.isEmpty) resultTraits = baseTraits;
      resultTraits = List.of(resultTraits);
      final limitCount2 = limitCount < 100 ? limitCount : svt.costume[limitCount]?.id ?? limitCount;
      for (final traitAdd in svt.traitAdd) {
        if (traitAdd.eventId != 0 ||
            traitAdd.condType != CondType.none ||
            (traitAdd.endedAt > 0 && traitAdd.endedAt < kNeverClosedTimestamp)) {
          continue;
        }
        if (traitAdd.limitCount == -1 || traitAdd.limitCount == limitCount2 || traitAdd.limitCount == limitCount) {
          resultTraits.addAll(traitAdd.trait);
        }
      }
      if (extraFilterData.useCostumeTraitForRegion &&
          region != null &&
          !region.isJP &&
          resultTraits.contains(Trait.hasCostume.value)) {
        if (!db.gameData.mappingData.isSvtTraitRelease(
          svtCollectionNo: svt.collectionNo,
          trait: Trait.hasCostume.value,
          region: region,
        )) {
          resultTraits.removeWhere((e) => e == Trait.hasCostume.value);
        }
      }

      bool matched = false;
      for (final andTraits in bonusTraitsList) {
        if (andTraits.isEmpty) continue;
        if (andTraits.every((e) => resultTraits.contains(e))) {
          matched = true;
          break;
        }
      }
      if (matched) {
        matchedLimitCounts.add(limitCount);
      }
    }

    return matchedLimitCounts;
  }

  bool isCeReleased(int ceId, Region region) {
    if (region == Region.jp) return true;
    final releasedIds = db.gameData.mappingData.entityRelease.ofRegion(region);
    if (releasedIds != null && releasedIds.isNotEmpty) {
      return releasedIds.contains(ceId);
    }
    return true;
  }

  List<_GroupItem> getGroupData() {
    final allSvts = getAllSvts();
    final shownSvts = List.of(allSvts)..retainWhere((e) => ServantFilterPage.filter(svtFilterData, e));
    final shownSvtIds = shownSvts.map((e) => e.id).toSet();
    final hiddenSvtIds = shownSvtIds.toSet();

    final List<int> allCeIds = allCeData.keys
        .where((e) => !const [_FilterType.exclude, _FilterType.hide].contains(extraFilterData.ceStates[e]))
        .toList();
    final List<int> excludeCeIds = extraFilterData.ceStates.keys
        .where((e) => extraFilterData.ceStates[e] == _FilterType.exclude)
        .toList();
    final List<int> mustHaveCeIds = extraFilterData.ceStates.keys
        .where((e) => extraFilterData.ceStates[e] == _FilterType.include)
        .toList();
    final List<int> freeCeIds = allCeIds.where((e) => !mustHaveCeIds.contains(e) && !excludeCeIds.contains(e)).toList();
    final int n = freeCeIds.length;
    List<_GroupItem> resultData = [];

    Set<T> intersectionSetList<T>(List<Set<T>> array) {
      if (array.isEmpty) return {};
      Set<T> result = array.first.toSet();
      for (final s in array.skip(1)) {
        result = result.intersection(s);
      }
      return result;
    }

    for (int mask = 0; mask < (1 << n); mask++) {
      final List<int> usedCeIds = List.of(mustHaveCeIds);
      usedCeIds.sort(); // for key sort
      for (int i = 0; i < n; i++) {
        if ((mask & (1 << i)) != 0) {
          usedCeIds.add(freeCeIds[i]);
        }
      }
      if (usedCeIds.isEmpty) continue;

      final List<Set<int>> svtIdList = usedCeIds.map((ceId) => allCeMatchSvtData[ceId]!.keys.toSet()).toList();
      final sameSvtIds = intersectionSetList(svtIdList);
      if (sameSvtIds.isEmpty) continue;

      List<({Servant svt, List<int> limitCounts})> svts = [];
      for (final svtId in sameSvtIds) {
        if (!shownSvtIds.contains(svtId)) continue;
        final svt = _targetSvts[svtId] ?? db.gameData.servantsById[svtId];
        if (svt == null) continue;
        final sameLimitCounts = intersectionSetList(
          usedCeIds.map((ceId) => allCeMatchSvtData[ceId]![svtId]?.toSet() ?? <int>{}).toList(),
        );
        for (final ceId in excludeCeIds) {
          final excludeLimitCounts = allCeMatchSvtData[ceId]![svt.id] ?? [];
          sameLimitCounts.removeAll(excludeLimitCounts);
        }

        if (sameLimitCounts.isNotEmpty) {
          svts.add((svt: svt, limitCounts: sameLimitCounts.toList()));
        }
      }
      if (svts.isEmpty) continue;
      final rateCount = Maths.sum(usedCeIds.map((e) => allCeData[e]!.rateCount));
      resultData.add((ceIds: usedCeIds, rateCount: rateCount, svts: svts));
    }

    // show svts with no bonus for all ces
    final bonusSvtIds = <int>{for (final v in allCeMatchSvtData.values) ...v.keys};
    List<({Servant svt, List<int> limitCounts})> noBonusSvts = [];
    for (final svtId in shownSvtIds) {
      if (!shownSvtIds.contains(svtId)) continue;
      final svt = db.gameData.servantsById[svtId];
      if (svt == null) continue;
      if (!bonusSvtIds.contains(svt.id)) {
        noBonusSvts.add((svt: svt, limitCounts: []));
      }
    }
    resultData.add((ceIds: [], rateCount: 0, svts: noBonusSvts));

    hiddenSvtIds.removeAll({
      for (final v in resultData)
        for (final svt in v.svts) svt.svt.id,
    });
    hiddenSvtIds.removeWhere((svtId) {
      for (final ceId in excludeCeIds) {
        final excludeLimitCounts = allCeMatchSvtData[ceId]![svtId] ?? [];
        if (excludeLimitCounts.isNotEmpty) {
          return true;
        }
      }
      return false;
    });

    if (hiddenSvtIds.isNotEmpty) {
      resultData.add((
        ceIds: [],
        rateCount: _kHiddenRate,
        svts: [
          for (final svtId in hiddenSvtIds)
            if (db.gameData.servantsById.containsKey(svtId)) (limitCounts: [], svt: db.gameData.servantsById[svtId]!),
        ],
      ));
    }

    for (final record in resultData) {
      record.svts.sort(
        (a, b) =>
            SvtFilterData.compare(a.svt, b.svt, keys: svtFilterData.sortKeys, reversed: svtFilterData.sortReversed),
      );
    }
    resultData.sortByList((e) => [-e.rateCount, e.ceIds.length, -e.svts.length, ...e.ceIds]);

    final maxRateCount = extraFilterData.maxRateCountPerSvt.radioValue;
    if (maxRateCount != null && maxRateCount >= 0) {
      Set<int> excludeSvtIds = {};
      for (final (svtId, limitToCeIds) in allSvtMatchCeData.items) {
        int svtMaxRateCount = Maths.max(
          limitToCeIds.values.map((ceIds) => Maths.sum([for (final ceId in ceIds) allCeData[ceId]!.rateCount])),
        );
        if (svtMaxRateCount > maxRateCount) {
          excludeSvtIds.add(svtId);
        }
      }
      for (final group in resultData) {
        group.svts.removeWhere((e) => excludeSvtIds.contains(e.svt.id));
      }
      resultData.removeWhere((e) => e.svts.isEmpty);
    }

    return resultData;
  }

  @override
  Widget build(BuildContext context) {
    final groups = getGroupData();

    return Column(
      children: [
        Expanded(child: _buildMainBody(groups)),
        kDefaultDivider,
        _buildButtonBar(),
      ],
    );
  }

  Widget _buildMainBody(List<_GroupItem> groups) {
    return ListView.separated(
      padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      itemCount: groups.length,
      separatorBuilder: (context, index) => const Divider(),
      itemBuilder: (context, index) {
        final (:ceIds, :rateCount, :svts) = groups[index];
        List<Widget> children = [];
        children.add(
          Wrap(
            crossAxisAlignment: WrapCrossAlignment.center,
            children: [
              Container(
                constraints: BoxConstraints(minWidth: 40),
                padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                margin: EdgeInsetsDirectional.only(end: 8),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(4),
                  border: Border.all(color: Theme.of(context).colorScheme.primary),
                ),
                child: Text(rateCount == _kHiddenRate ? S.current.hide : rateCount.format(percent: true, base: 10)),
              ),
              // if (rateCount < 0) Text(S.current.hide),
              ...ceIds
                  .map((ceId) {
                    final (:ce, :traits, :rateCount) = allCeData[ceId]!;
                    return <Widget>[
                      ce.iconBuilder(context: context, width: 24),
                      InkWell(
                        onTap: ce.routeTo,
                        child: Text('${_describeTraits(traits)}  ', style: Theme.of(context).textTheme.bodySmall),
                      ),
                    ];
                  })
                  .expand((e) => e),
            ],
          ),
        );

        children.add(
          Wrap(
            children: svts.map((x) {
              final (:svt, :limitCounts) = x;
              final allLimitCounts = _getSvtAllLimits(svt);
              final conditional = limitCounts.length != allLimitCounts.length && limitCounts.isNotEmpty;
              Widget child = Container(
                decoration: BoxDecoration(
                  color: conditional ? Theme.of(context).colorScheme.error : null,
                  borderRadius: BorderRadius.circular(4),
                ),
                padding: const EdgeInsets.all(1),
                margin: const EdgeInsets.all(1),
                child: svt.iconBuilder(
                  context: context,
                  // width: 32,
                  text: [
                    if (conditional) '${limitCounts.length}/${allLimitCounts.length}',
                    svt.status.favorite ? 'Lv${svt.status.bond}${svt.status.isReachBondLimit ? "*" : ""}' : '',
                  ].join('\n'),
                  option: ImageWithTextOption(fontSize: 12),
                  width: 48,
                ),
              );
              if (conditional) {
                String msg = limitCounts
                    .map((limitCount) {
                      String name;
                      if (limitCount < 10) {
                        int stage = BattleUtils.limitCountToStage(limitCount);
                        name = '${S.current.ascension_short} $limitCount (${S.current.ascension_stage_short} $stage)';
                      } else {
                        final costume = svt.costume[limitCount];
                        name = costume?.lName.l ?? '${S.current.costume} $limitCount';
                      }
                      return '- $name';
                    })
                    .join('\n');
                msg = '${svt.lName.l}\n$msg';
                child = Tooltip(message: msg, child: child);
              }
              return child;
            }).toList(),
          ),
        );
        return Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: children);
      },
    );
  }

  Widget _buildButtonBar() {
    final ces = [
      null,
      ...(allCeData.values.toList()..sortByList((e) => [-e.rateCount, -e.ce.collectionNo])),
    ];
    final extraBtns = [
      IconButton(
        icon: const Icon(Icons.filter_alt),
        tooltip: S.current.filter,
        onPressed: () => FilterPage.show(
          context: context,
          builder: (context) => ServantFilterPage(
            filterData: svtFilterData,
            onChanged: (_) {
              if (mounted) setState(() {});
            },
            planMode: false,
            extraFilters: (context, update) {
              List<int> validValues = <int>{
                ?extraFilterData.maxRateCountPerSvt.radioValue,
                for (int x = 0; x <= maxTotalRateCount; x += 200) x,
              }.toList()..sort();
              return [
                FilterGroup<int>(
                  title: Text('${S.current.filter_per_servant_bond_bonus_cap}≤'),
                  options: validValues,
                  values: extraFilterData.maxRateCountPerSvt,
                  optionBuilder: (v) => Text(v.format(percent: true, base: 10)),
                  onFilterChanged: (v, _) {
                    if (mounted) setState(() {});
                    update();
                  },
                ),
              ];
            },
          ),
        ),
      ),
      FilterOption(
        selected: svtFilterData.favorite == FavoriteState.owned,
        value: svtFilterData.favorite,
        child: Text(FavoriteState.owned.shownName),
        onChanged: (value) {
          setState(() {
            svtFilterData.favorite = value ? FavoriteState.owned : FavoriteState.all;
          });
        },
      ),
      FilterOption(
        selected:
            svtFilterData.bondCompare.options.equalTo(const {CompareOperator.lessThan}) &&
            svtFilterData.bondValue.radioValue == kBondLvDefaultMax,
        value: 0,
        child: Text('${S.current.bond}＜$kBondLvDefaultMax'),
        onChanged: (value) {
          setState(() {
            if (value) {
              svtFilterData.bondCompare.options = {CompareOperator.lessThan};
              svtFilterData.bondValue.set(kBondLvDefaultMax);
            } else {
              svtFilterData.bondValue.reset();
            }
          });
        },
      ),
      if (!db.curUser.region.isJP)
        FilterOption(
          selected: svtFilterData.region.radioValue == db.curUser.region,
          value: svtFilterData.region.radioValue,
          child: Text(db.curUser.region.localName),
          onChanged: (value) {
            setState(() {
              if (value) {
                svtFilterData.region.set(db.curUser.region);
              } else {
                svtFilterData.region.reset();
              }
            });
          },
        ),
      if (svtFilterData.region.radioValue?.isJP == false)
        FilterOption(
          selected: extraFilterData.useCostumeTraitForRegion,
          value: true,
          child: Text('${S.current.costume}:${svtFilterData.region.radioValue?.localName}'),
          onChanged: (value) {
            setState(() {
              extraFilterData.useCostumeTraitForRegion = value;
              initData();
            });
          },
        ),
    ];
    final List<Widget> ceBtns = ces.map((ce) {
      final curStatus = ce == null ? _FilterType.none : getCeState(ce.ce.id);
      return InkWell(
        onTap: () {
          router.showDialog(
            builder: (context) => SimpleDialog(
              title: ce == null
                  ? Text(S.current.general_all)
                  : Text.rich(
                      TextSpan(
                        children: [
                          CenterWidgetSpan(
                            child: ce.ce.iconBuilder(context: context, width: 32, padding: EdgeInsets.all(2)),
                          ),
                          TextSpan(text: ce.ce.lName.l),
                        ],
                      ),
                    ),
              children: [
                if (ce != null)
                  SimpleDialogOption(
                    onPressed: ce.ce.routeTo,
                    child: Text.rich(
                      TextSpan(
                        text: '[+${ce.rateCount.format(percent: true, base: 10)}] ',
                        children: SharedBuilder.traitsListSpans(context: context, traitsList: ce.traits),
                      ),
                    ),
                  ),
                kDefaultDivider,
                for (final type in _FilterType.values)
                  ListTile(
                    dense: true,
                    contentPadding: EdgeInsets.symmetric(horizontal: 24.0),
                    title: Text(
                      ce != null && curStatus == type ? '${type.shownName} (${S.current.current_})' : type.shownName,
                      style: TextStyle(color: type.color),
                    ),
                    subtitle: Text(type.hint),
                    onTap: () {
                      if (ce == null) {
                        for (final ceId in allCeData.keys) {
                          extraFilterData.ceStates[ceId] = type;
                        }
                      } else {
                        extraFilterData.ceStates[ce.ce.id] = type;
                      }
                      Navigator.pop(context);
                      if (mounted) setState(() {});
                    },
                  ),
              ],
            ),
          );
        },
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            IgnorePointer(
              child: FilterOption(
                selected: ce == null ? false : curStatus != _FilterType.none,
                value: ce?.ce.id,
                shrinkWrap: true,
                constraints: const BoxConstraints(),
                selectedColor: curStatus.color,
                child:
                    ce?.ce.iconBuilder(context: context, jumpToDetail: false, height: 36, padding: EdgeInsets.all(3)) ??
                    GameCardMixin.cardIconBuilder(
                      context: context,
                      icon: Atlas.common.emptySvtIcon,
                      height: 36,
                      padding: EdgeInsets.all(3),
                    ),
              ),
            ),
            SizedBox(
              width: 36,
              height: 20,
              child: AutoSizeText(
                ce == null ? S.current.general_all : (curStatus == _FilterType.none ? '-' : curStatus.shownName),
                maxLines: 1,
                minFontSize: 2,
                maxFontSize: 12,
                style: TextStyle(color: curStatus.color),
                textAlign: TextAlign.center,
              ),
            ),
          ],
        ),
      );
    }).toList();
    return SafeArea(
      right: false,
      child: Padding(
        padding: EdgeInsets.only(top: 4),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          spacing: 4,
          children: [
            Wrap(spacing: 2, runSpacing: 0, crossAxisAlignment: WrapCrossAlignment.center, children: extraBtns),
            Wrap(spacing: 2, runSpacing: 1, crossAxisAlignment: WrapCrossAlignment.start, children: ceBtns),
          ],
        ),
      ),
    );
  }

  String _describeTraits(List<List<int>> traitsList) {
    return traitsList.map((ee) => ee.map((e) => Transl.traitName(e)).join('&')).join('/');
  }

  Set<int> _getSvtAllLimits(Servant svt) {
    return {...range(5), ...svt.costume.keys, ...svt.ascensionAdd.individuality2.all.keys};
  }
}
