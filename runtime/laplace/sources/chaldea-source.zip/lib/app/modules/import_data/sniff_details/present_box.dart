import 'package:chaldea/generated/l10n.dart';
import 'package:chaldea/models/gamedata/mst_data.dart';
import 'package:chaldea/models/models.dart';
import 'package:chaldea/utils/utils.dart';
import 'package:chaldea/widgets/widgets.dart';

class SniffPresentBoxDetailPage extends StatelessWidget {
  final MasterDataManager mstData;
  const SniffPresentBoxDetailPage({super.key, required this.mstData});

  @override
  Widget build(BuildContext context) {
    final Map<int, int> ownedItems = {}, missionItems = {}, presentItems = {};

    // present box
    final presents = mstData.userPresentBox.toList();
    presents.sort2((e) => -e.createdAt);
    int? chocoSvtEquipId;
    for (final present in presents) {
      if (present.giftType == GiftType.servant.value || present.giftType == GiftType.item.value) {
        int objectId = present.objectId;
        // in case hundreds of choco ces shown together
        if (db.gameData.craftEssencesById[objectId]?.flags.contains(SvtFlag.svtEquipChocolate) == true) {
          chocoSvtEquipId ??= objectId;
          objectId = chocoSvtEquipId;
        }
        presentItems.addNum(objectId, present.num);
      }
    }

    // extra mission
    final extraMissions = {
      for (final m in db.gameData.extraMasterMission[MasterMission.kExtraMasterMissionId]?.missions ?? <EventMission>[])
        m.id: m,
    };
    for (final mission in mstData.userEventMission) {
      if (mission.missionProgressType != MissionProgressType.clear.value) continue;
      final eventMission = extraMissions[mission.missionId];
      if (eventMission == null) continue;
      Gift.checkAddGifts(missionItems, eventMission.gifts);
    }

    // own items
    for (final itemId in const [
      Items.stoneId,
      Items.summonTicketId,
      Items.quartzFragmentId,
      Items.lanternId,
      Items.greatLanternId,
      Items.grailId,
      Items.crystalId,
      ...Items.apples,
    ]) {
      final itemNum = mstData.getItemOrSvtNum(itemId);
      if (itemNum != 0) ownedItems[itemId] = itemNum;
    }
    final userGame = mstData.user;
    final allItems = Maths.sumDict([presentItems, missionItems, ownedItems]);
    final stoneCount = Maths.sum([
      (allItems[Items.stoneId] ?? 0),
      (allItems[Items.quartzFragmentId] ?? 0) / 7,
      (allItems[Items.summonTicketId] ?? 0) * 3,
    ]);
    final summonCount = ((stoneCount ~/ 3) * 1.1).toInt();
    int? maxAp = ConstData.userLevel[userGame?.lv]?.maxAp;
    int totalAp = 0;
    if (maxAp != null) {
      for (final appleId in Items.apples) {
        final item = db.gameData.items[appleId];
        if (item == null) continue;
        final itemNum = mstData.getItemOrSvtNum(appleId);
        if (item.type == ItemType.apRecover) {
          totalAp += (item.value / 1000 * maxAp).ceil() * itemNum;
        } else if (item.type == ItemType.apAdd) {
          totalAp += item.value * itemNum;
        }
      }
    }
    double? totalApples = maxAp == null ? null : totalAp / maxAp;

    List<Widget> children = [];
    children.addAll([
      oneGroup(context, S.current.present_box, presentItems),
      oneGroup(context, '${S.current.master_mission}(Extra, cleared but not claimed)', missionItems),
      oneGroup(context, '${S.current.item_own}(Important items only)', ownedItems),
      oneGroup(
        context,
        '${S.current.total}: ${stoneCount.toInt()} ${S.current.sq_short} = ${stoneCount ~/ 3}×1.1 = $summonCount ${S.current.summon_pull_unit}, '
        ' ${totalApples?.toStringAsFixed(1) ?? "?"}×${maxAp ?? "?"} AP',
        allItems,
      ),
    ]);
    children.add(SHeader('${S.current.details}(${S.current.present_box})'));
    children.addAll(presents.map((e) => buildPresent(context, e)));

    return Scaffold(
      appBar: AppBar(title: Text(S.current.present_box)),
      body: ListView(children: children),
    );
  }

  Widget oneGroup(BuildContext context, String header, Map<int, int> items) {
    items = sortDict(items);
    return TileGroup(
      header: header,
      padding: EdgeInsets.zero,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
          child: Wrap(
            spacing: 4,
            runSpacing: 4,
            crossAxisAlignment: WrapCrossAlignment.center,
            children: [
              if (items.isEmpty) const Text('NONE'),
              for (final entry in items.entries)
                GameCardMixin.anyCardItemBuilder(
                  context: context,
                  id: entry.key,
                  text: entry.value.format(),
                  width: 40,
                  aspectRatio: 132 / 144,
                ),
            ],
          ),
        ),
      ],
    );
  }

  Widget buildPresent(BuildContext context, UserPresentBoxEntity present) {
    final gift = present.toGift();
    return ListTile(
      dense: true,
      leading: gift.iconBuilder(context: context, width: 32),
      title: Text('${gift.shownName} ×${gift.num}'),
      subtitle: Text([present.message, present.createdAt.sec2date().toStringShort(omitSec: true)].join('\n')),
      tileColor: Theme.of(context).hoverColor,
      onTap: () {
        gift.routeTo();
      },
    );
  }
}
