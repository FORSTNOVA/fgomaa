import 'package:flutter_easyloading/flutter_easyloading.dart';

import 'package:chaldea/app/api/chaldea_server.dart';
import 'package:chaldea/app/app.dart';
import 'package:chaldea/app/modules/auth/admin/admin_users_page.dart';
import 'package:chaldea/app/modules/auth/change_email_page.dart';
import 'package:chaldea/app/modules/auth/change_password_page.dart';
import 'package:chaldea/app/modules/auth/change_username_page.dart';
import 'package:chaldea/app/modules/auth/delete_account_page.dart';
import 'package:chaldea/generated/l10n.dart';
import 'package:chaldea/models/models.dart';
import 'package:chaldea/utils/utils.dart';
import 'package:chaldea/widgets/modern/modern.dart';
import 'package:chaldea/widgets/widgets.dart';

class ProfilePage extends StatefulWidget {
  const ProfilePage({super.key});

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  final secrets = db.settings.secrets;

  static ({int userId, DateTime refreshTime})? lastRefresh;
  static const _kRefreshDuration = Duration(minutes: 10);

  @override
  void initState() {
    super.initState();
    _refresh();
  }

  Future<bool> _refresh([Duration interval = _kRefreshDuration]) async {
    if (lastRefresh != null) {
      final (:userId, :refreshTime) = lastRefresh!;
      if (db.settings.secrets.user.id == userId && refreshTime.add(interval).isAfter(DateTime.now())) {
        return false;
      }
    }
    final user = await ChaldeaServerApi.getMe();
    if (user != null) {
      secrets.user.updateFromUserInfo(user);
      db.notifySettings();
      if (mounted) {
        setState(() {});
      }
      return true;
    }
    return false;
  }

  String _maskEmail(String email) {
    if (email.isEmpty) return '';
    final at = email.indexOf('@');
    if (at <= 0) return email;
    final domain = email.substring(at);
    final local = email.substring(0, at);
    final first = local.isNotEmpty ? local[0] : '';
    return '$first***$domain';
  }

  Future<void> _logout() async {
    final confirmed = await SimpleConfirmDialog(
      title: Text(S.current.auth_logout),
      content: Text(S.current.auth_logout),
      confirmText: S.current.confirm,
    ).showDialog(context);
    if (confirmed != true) return;
    final ok = await showEasyLoading(() => ChaldeaServerApi.logout());
    if (ok == true) {
      secrets.user.clearAuth();
      secrets.user.secret = null;
      EasyLoading.showSuccess(S.current.success);
      if (!mounted) return;
      Navigator.of(context).pop();
    }
    db.notifySettings();
  }

  Future<void> _pushAndRefresh(Widget child) async {
    await router.push(child: child);
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final user = secrets.user;
    final name = user.name;
    final uid = user.id.toString();
    final email = user.email ?? '';
    final isAdmin = user.isAdmin;

    return Scaffold(
      appBar: AppBar(title: Text(S.current.auth_profile_title)),
      body: RefreshIndicator(
        onRefresh: () async {
          final result = await _refresh(Duration.zero);
          if (result) {
            EasyLoading.showSuccess(S.current.refresh);
          } else {
            EasyLoading.showError(S.current.failed);
          }
          if (mounted) setState(() {});
        },
        child: ListView(
          padding: const EdgeInsets.symmetric(vertical: 16),
          children: [
            // ProfileCard(title: name, subtitle: '${S.current.auth_user_id}: $uid'),
            _buildPersonalInfoSection(name, uid, email, isAdmin),
            _buildAccountActionsSection(),
            if (isAdmin) _buildAdminSection(),
          ],
        ),
      ),
    );
  }

  Widget _buildPersonalInfoSection(String name, String uid, String email, bool isAdmin) {
    return TileGroup(
      header: S.current.auth_personal_info,
      children: [
        InfoRow(leading: Icon(Icons.tag), title: S.current.auth_user_id, value: uid, valueMono: true),
        InfoRow(
          leading: Icon(Icons.person_outline),
          title: S.current.login_username,
          value: name,
          onTap: () => _pushAndRefresh(const ChangeUsernamePage()),
          showChevron: true,
        ),
        InfoRow(
          leading: Icon(Icons.email_outlined),
          title: S.current.auth_email_field,
          value: email.isEmpty ? S.current.auth_admin_no_email : _maskEmail(email),
          valueWidget: Text(
            email.isEmpty ? S.current.auth_admin_no_email : _maskEmail(email),
            style: email.isEmpty ? TextStyle(color: Colors.red) : null,
          ),
          onTap: () => _pushAndRefresh(const ChangeEmailPage()),
          showChevron: true,
        ),
        if (isAdmin)
          InfoRow(
            leading: Icon(Icons.shield_outlined),
            title: S.current.auth_role,
            valueWidget: Text(S.current.auth_role_admin),
          ),
      ],
    );
  }

  Widget _buildAccountActionsSection() {
    return TileGroup(
      header: S.current.auth_account_actions,
      children: [
        ActionRow(
          leading: Icon(Icons.lock_outline),
          title: S.current.auth_change_password,
          onTap: () => _pushAndRefresh(const ChangePasswordPage()),
        ),
        ActionRow(leading: Icon(Icons.logout), title: S.current.auth_logout, onTap: _logout),
        ActionRow(
          leading: Icon(Icons.delete_outline),
          title: S.current.auth_delete_account,
          variant: ActionRowVariant.danger,
          onTap: () async {
            await router.push(child: const DeleteAccountPage());
            if (!secrets.isLoggedIn && mounted) {
              Navigator.of(context).pop();
            }
          },
        ),
      ],
    );
  }

  Widget _buildAdminSection() {
    return TileGroup(
      header: S.current.auth_admin_tools,
      children: [
        ActionRow(
          leading: Icon(Icons.admin_panel_settings_outlined),
          title: S.current.auth_user_management,
          onTap: () => router.push(child: const AdminUsersPage()),
        ),
      ],
    );
  }
}
