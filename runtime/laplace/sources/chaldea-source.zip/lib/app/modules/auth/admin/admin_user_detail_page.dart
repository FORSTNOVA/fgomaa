import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:material_ui/material_ui.dart';

import 'package:chaldea/app/api/chaldea_server.dart';
import 'package:chaldea/app/app.dart';
import 'package:chaldea/app/modules/auth/validators.dart';
import 'package:chaldea/app/modules/battle/teams/teams_query_page.dart';
import 'package:chaldea/generated/l10n.dart';
import 'package:chaldea/models/api/api.dart';
import 'package:chaldea/models/models.dart';
import 'package:chaldea/packages/language.dart';
import 'package:chaldea/utils/utils.dart';
import 'package:chaldea/widgets/custom_dialogs.dart';
import 'package:chaldea/widgets/modern/modern.dart';

class AdminUserDetailPage extends StatefulWidget {
  final int userId;
  const AdminUserDetailPage({super.key, required this.userId});

  @override
  State<AdminUserDetailPage> createState() => _AdminUserDetailPageState();
}

class _AdminUserDetailPageState extends State<AdminUserDetailPage> {
  AdminUserDetail? _detail;
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final result = await ChaldeaServerApi.adminGetUserDetail(widget.userId);
      _detail = result;
    } catch (e) {
      _error = e.toString();
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _resetPassword() async {
    final newPassword = await showDialog<String>(context: context, builder: (context) => const _ResetPasswordDialog());
    if (newPassword == null) return; // User cancelled or validation failed
    if (!mounted) return;
    final resp = await showEasyLoading(
      () => ChaldeaServerApi.adminRecoverUser(userId: widget.userId, password: newPassword),
    );
    if (resp != null) {
      EasyLoading.showSuccess(resp.messageZh.isNotEmpty ? resp.messageZh : resp.message);
    }
    db.notifySettings();
  }

  Future<void> _sendRecoveryEmail() async {
    // Completing recovery binds the submitted email, replacing any existing one.
    final email = await showDialog<String>(
      context: context,
      builder: (context) => InputCancelOkDialog(
        title: S.current.auth_admin_send_recovery,
        initValue: _detail?.user.email,
        keyboardType: TextInputType.emailAddress,
        helperText: Language.isZH
            ? '用户点击邮件中的链接并重置密码后，该邮箱将绑定此账号（替换原有邮箱）'
            : 'After the user clicks the link in the email and resets the '
                  'password, this email will be bound to the account (replacing '
                  'the existing one).',
        // validateEmail allows empty input; this dialog requires an email.
        validate: (s) => s.isNotEmpty && validateEmail(s) == null,
      ),
    );
    if (email == null || email.isEmpty || !mounted) return;
    // The API reports errors and returns null on failure.
    final resp = await showEasyLoading(() => ChaldeaServerApi.adminRecoverUser(userId: widget.userId, email: email));
    if (resp == null || !mounted) return;
    _showRecoveryResult(resp);
  }

  void _showRecoveryResult(AdminRecoverResponse resp) {
    final details = Language.isZH ? resp.detailsZh : resp.details;
    final reminders = Language.isZH ? resp.remindersZh : resp.reminders;
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(Language.isZH ? '发送结果' : 'Result'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            spacing: 8,
            children: [
              Text(details),
              if (reminders.isNotEmpty) ...[const Divider(), for (final r in reminders) Text('• $r')],
            ],
          ),
        ),
        actions: [TextButton(onPressed: () => Navigator.pop(context), child: Text(S.current.ok))],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return Scaffold(
        appBar: AppBar(title: Text(S.current.auth_admin_user_detail_title)),
        body: SafeArea(
          top: false, // AppBar already handles top safe area
          child: const Padding(
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: Center(child: CircularProgressIndicator()),
          ),
        ),
      );
    }
    if (_error != null || _detail == null) {
      return Scaffold(
        appBar: AppBar(title: Text(S.current.auth_admin_user_detail_title)),
        body: SafeArea(
          top: false, // AppBar already handles top safe area
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(_error ?? 'error', style: TextStyle(color: Theme.of(context).colorScheme.error)),
                  const SizedBox(height: 12),
                  TextButton(onPressed: _load, child: Text(S.current.auth_admin_load_more)),
                ],
              ),
            ),
          ),
        ),
      );
    }
    final d = _detail!;
    final user = d.user;
    return Scaffold(
      appBar: AppBar(title: Text(S.current.auth_admin_user_detail_title)),
      body: SafeArea(
        top: false, // AppBar already handles top safe area
        child: ListView(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
          children: [
            ProfileCard(title: user.name, subtitle: '${S.current.auth_user_id}: ${user.id}'),
            _buildBasicInfo(d, user),
            _buildStatistics(d),
            _buildAdminActions(),
          ],
        ),
      ),
    );
  }

  Widget _buildBasicInfo(AdminUserDetail d, ChaldeaUser user) {
    final created = user.createdAt != null
        ? DateTime.fromMillisecondsSinceEpoch(user.createdAt! * 1000).toDateString()
        : '-';
    return SectionCard(
      header: S.current.auth_admin_basic_info,
      children: [
        InfoRow(leading: Icon(Icons.person_outline), title: S.current.login_username, value: user.name),
        InfoRow(leading: Icon(Icons.tag), title: S.current.auth_user_id, value: user.id.toString(), valueMono: true),
        InfoRow(
          leading: Icon(Icons.email_outlined),
          title: S.current.auth_email_field,
          value: (user.email == null || user.email!.isEmpty) ? S.current.auth_admin_no_email : user.email!,
        ),
        InfoRow(
          leading: Icon(Icons.shield_outlined),
          title: S.current.auth_role,
          valueWidget: user.isAdmin ? Chip(label: Text(S.current.auth_role_admin)) : null,
        ),
        InfoRow(leading: Icon(Icons.calendar_today_outlined), title: S.current.auth_admin_created_at, value: created),
      ],
    );
  }

  Widget _buildStatistics(AdminUserDetail detail) {
    return SectionCard(
      header: S.current.auth_admin_statistics,
      children: [
        InfoRow(
          leading: Icon(Icons.cloud_upload_outlined),
          title: S.current.auth_admin_backups_count,
          value: detail.backupsCount.toString(),
          valueMono: true,
        ),
        InfoRow(
          leading: Icon(Icons.groups_outlined),
          title: S.current.auth_admin_teams_count,
          value: detail.teamsCount.toString(),
          valueMono: true,
          onTap: () {
            router.pushPage(TeamsQueryPage(mode: .user, userId: detail.user.id));
          },
        ),
        InfoRow(
          leading: Icon(Icons.devices_outlined),
          title: S.current.auth_admin_sessions,
          value: '${detail.sessions.length}',
          valueMono: true,
          onTap: () {
            if (detail.sessions.isEmpty) return;
            SimpleDialog(
              title: Text(S.current.auth_admin_sessions),
              children: [
                for (final session in detail.sessions)
                  SimpleDialogOption(child: Text(session.device, style: kMonoStyle)),
              ],
            ).showDialog(context);
          },
        ),
        InfoRow(
          leading: Icon(Icons.history_outlined),
          title: S.current.auth_admin_recent_logins,
          value: '${detail.logins.length}',
          valueMono: true,
          onTap: () {
            if (detail.logins.isEmpty) return;
            SimpleDialog(
              title: Text(S.current.auth_admin_recent_logins),
              children: [
                for (final login in detail.logins)
                  SimpleDialogOption(
                    child: Text.rich(
                      TextSpan(
                        text: login.device,
                        style: kMonoStyle,
                        children: [
                          TextSpan(
                            text:
                                '\n${{login.createdAt, login.updatedAt}.map((e) => e.sec2date().toDateString()).join(" / ")}',
                            style: Theme.of(context).textTheme.bodySmall,
                          ),
                        ],
                      ),
                    ),
                  ),
              ],
            ).showDialog(context);
          },
        ),
      ],
    );
  }

  Widget _buildAdminActions() {
    final email = _detail?.user.email;
    final hasEmail = email != null && email.isNotEmpty;
    return SectionCard(
      header: S.current.auth_admin_actions,
      children: [
        ActionRow(
          leading: Icon(Icons.lock_reset_outlined),
          title: S.current.auth_admin_reset_password,
          onTap: _resetPassword,
        ),
        ActionRow(
          leading: Icon(Icons.email_outlined),
          title: S.current.auth_admin_send_recovery,
          subtitle: hasEmail ? email : S.current.auth_admin_no_email,
          onTap: _sendRecoveryEmail,
        ),
      ],
    );
  }
}

class _ResetPasswordDialog extends StatefulWidget {
  const _ResetPasswordDialog();

  @override
  State<_ResetPasswordDialog> createState() => _ResetPasswordDialogState();
}

class _ResetPasswordDialogState extends State<_ResetPasswordDialog> {
  final _controller = TextEditingController();
  bool _forceShowError = false;

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  // validatePassword allows empty input; this dialog requires a password.
  String? _validate(String? value) {
    if (value == null || value.isEmpty) {
      return S.current.validation_required;
    }
    return validatePassword(value);
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(S.current.auth_admin_reset_password),
      content: FormInput(
        controller: _controller,
        label: S.current.login_password,
        obscure: true,
        autocorrect: false,
        validator: _validate,
        errorDisplayMode: ErrorDisplayMode.onBlur,
        forceShowError: _forceShowError,
      ),
      actions: [
        TextButton(onPressed: () => Navigator.of(context).pop(), child: Text(S.current.cancel)),
        TextButton(
          onPressed: () {
            final error = _validate(_controller.text);
            if (error != null) {
              setState(() => _forceShowError = true);
              EasyLoading.showError(error);
              return;
            }
            Navigator.of(context).pop(_controller.text);
          },
          child: Text(S.current.confirm),
        ),
      ],
    );
  }
}
