// GENERATED CODE - DO NOT MODIFY BY HAND

import 'package:intl/intl.dart';
import 'package:material_ui/material_ui.dart';

import 'intl/messages_all.dart';

// **************************************************************************
// Generator: Flutter Intl IDE plugin
// Made by Localizely
// **************************************************************************

// ignore_for_file: non_constant_identifier_names, lines_longer_than_80_chars
// ignore_for_file: join_return_with_assignment, prefer_final_in_for_each
// ignore_for_file: avoid_redundant_argument_values, avoid_escaping_inner_quotes

extension _LocaleEx on Locale {
  String get canonicalizedName {
    if (scriptCode == null) {
      return Intl.canonicalizedLocale(toString());
    }
    return toString();
  }
}

class S {
  final Locale locale;
  final String localeName;

  S(this.locale) : localeName = locale.canonicalizedName;

  static S? _current;

  static S get current {
    assert(
      _current != null,
      'No instance of S was loaded. Try to initialize the S delegate before accessing S.current.',
    );
    return _current!;
  }

  static const AppLocalizationDelegate delegate = AppLocalizationDelegate();

  static Future<S> load(Locale locale, {bool override = false}) {
    final localeName = locale.canonicalizedName;
    return initializeMessages(localeName).then((_) {
      final localizations = S(locale);
      if (override || S._current == null) {
        Intl.defaultLocale = localeName;
        S._current = localizations;
      }
      return localizations;
    });
  }

  static S of(BuildContext context) {
    final instance = S.maybeOf(context);
    assert(
      instance != null,
      'No instance of S present in the widget tree. Did you add S.delegate in localizationsDelegates?',
    );
    return instance!;
  }

  static S? maybeOf(BuildContext context) {
    return Localizations.of<S>(context, S);
  }

  /// `English`
  String get language {
    return Intl.message('English', name: 'language', desc: '', locale: localeName, args: []);
  }

  /// `English`
  String get language_en {
    return Intl.message('English', name: 'language_en', desc: '', locale: localeName, args: []);
  }

  /// `About`
  String get about_app {
    return Intl.message('About', name: 'about_app', desc: '', locale: localeName, args: []);
  }

  /// `The data used in this application comes from the game Fate/GO and the following websites. The copyright of the original texts, pictures and voices of game belongs to TYPE MOON/FGO PROJECT.\n\nThe design of the program is based on the WeChat mini program "Material Programe" and the iOS application "Guda".\n\nBattle Simulator "Laplace" is implemented by Yome - the author of "FGO Simulator" - which is also inspired by FGO teamup.`
  String get about_app_declaration_text {
    return Intl.message(
      'The data used in this application comes from the game Fate/GO and the following websites. The copyright of the original texts, pictures and voices of game belongs to TYPE MOON/FGO PROJECT.\n\nThe design of the program is based on the WeChat mini program "Material Programe" and the iOS application "Guda".\n\nBattle Simulator "Laplace" is implemented by Yome - the author of "FGO Simulator" - which is also inspired by FGO teamup.',
      name: 'about_app_declaration_text',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Data source`
  String get about_data_source {
    return Intl.message('Data source', name: 'about_data_source', desc: '', locale: localeName, args: []);
  }

  /// `Please inform us if there is unmarked source or infringement.`
  String get about_data_source_footer {
    return Intl.message(
      'Please inform us if there is unmarked source or infringement.',
      name: 'about_data_source_footer',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Feedback`
  String get about_feedback {
    return Intl.message('Feedback', name: 'about_feedback', desc: '', locale: localeName, args: []);
  }

  /// `Account`
  String get account_title {
    return Intl.message('Account', name: 'account_title', desc: '', locale: localeName, args: []);
  }

  /// `Active Skill`
  String get active_skill {
    return Intl.message('Active Skill', name: 'active_skill', desc: '', locale: localeName, args: []);
  }

  /// `Active`
  String get active_skill_short {
    return Intl.message('Active', name: 'active_skill_short', desc: '', locale: localeName, args: []);
  }

  /// `Ad`
  String get ad {
    return Intl.message('Ad', name: 'ad', desc: '', locale: localeName, args: []);
  }

  /// `App Open`
  String get ad_type_app_open {
    return Intl.message('App Open', name: 'ad_type_app_open', desc: '', locale: localeName, args: []);
  }

  /// `Banner`
  String get ad_type_banner {
    return Intl.message('Banner', name: 'ad_type_banner', desc: '', locale: localeName, args: []);
  }

  /// `Interstitial`
  String get ad_type_interstitial {
    return Intl.message('Interstitial', name: 'ad_type_interstitial', desc: '', locale: localeName, args: []);
  }

  /// `Ad Types`
  String get ad_types {
    return Intl.message('Ad Types', name: 'ad_types', desc: '', locale: localeName, args: []);
  }

  /// `Add`
  String get add {
    return Intl.message('Add', name: 'add', desc: '', locale: localeName, args: []);
  }

  /// `Add Condition`
  String get add_condition {
    return Intl.message('Add Condition', name: 'add_condition', desc: '', locale: localeName, args: []);
  }

  /// `Please add feedback details`
  String get add_feedback_details_warning {
    return Intl.message(
      'Please add feedback details',
      name: 'add_feedback_details_warning',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Add Mission`
  String get add_mission {
    return Intl.message('Add Mission', name: 'add_mission', desc: '', locale: localeName, args: []);
  }

  /// `Add to blacklist`
  String get add_to_blacklist {
    return Intl.message('Add to blacklist', name: 'add_to_blacklist', desc: '', locale: localeName, args: []);
  }

  /// `Additional Enemy`
  String get additional_enemy {
    return Intl.message('Additional Enemy', name: 'additional_enemy', desc: '', locale: localeName, args: []);
  }

  /// `Anniversary`
  String get anniversary {
    return Intl.message('Anniversary', name: 'anniversary', desc: '', locale: localeName, args: []);
  }

  /// `AP`
  String get ap {
    return Intl.message('AP', name: 'ap', desc: '', locale: localeName, args: []);
  }

  /// `Quest Campaigns' start time of non-JP regions may be incorrect`
  String get ap_campaign_time_mismatch_hint {
    return Intl.message(
      'Quest Campaigns\' start time of non-JP regions may be incorrect',
      name: 'ap_campaign_time_mismatch_hint',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `AP rate`
  String get ap_efficiency {
    return Intl.message('AP rate', name: 'ap_efficiency', desc: '', locale: localeName, args: []);
  }

  /// `All AP Restored`
  String get ap_fully_recovered {
    return Intl.message('All AP Restored', name: 'ap_fully_recovered', desc: '', locale: localeName, args: []);
  }

  /// `Data Folder`
  String get app_data_folder {
    return Intl.message('Data Folder', name: 'app_data_folder', desc: '', locale: localeName, args: []);
  }

  /// `Use External Storage (SD card)`
  String get app_data_use_external_storage {
    return Intl.message(
      'Use External Storage (SD card)',
      name: 'app_data_use_external_storage',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Appearance`
  String get appearance {
    return Intl.message('Appearance', name: 'appearance', desc: '', locale: localeName, args: []);
  }

  /// `Append Skill`
  String get append_skill {
    return Intl.message('Append Skill', name: 'append_skill', desc: '', locale: localeName, args: []);
  }

  /// `Append`
  String get append_skill_short {
    return Intl.message('Append', name: 'append_skill_short', desc: '', locale: localeName, args: []);
  }

  /// `April Fool`
  String get april_fool {
    return Intl.message('April Fool', name: 'april_fool', desc: '', locale: localeName, args: []);
  }

  /// `Ascension`
  String get ascension {
    return Intl.message('Ascension', name: 'ascension', desc: '', locale: localeName, args: []);
  }

  /// `Ascension info changes`
  String get ascension_info_changes {
    return Intl.message(
      'Ascension info changes',
      name: 'ascension_info_changes',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Ascen`
  String get ascension_short {
    return Intl.message('Ascen', name: 'ascension_short', desc: '', locale: localeName, args: []);
  }

  /// `Ascension Stage`
  String get ascension_stage {
    return Intl.message('Ascension Stage', name: 'ascension_stage', desc: '', locale: localeName, args: []);
  }

  /// `Stage`
  String get ascension_stage_short {
    return Intl.message('Stage', name: 'ascension_stage_short', desc: '', locale: localeName, args: []);
  }

  /// `Ascension`
  String get ascension_up {
    return Intl.message('Ascension', name: 'ascension_up', desc: '', locale: localeName, args: []);
  }

  /// `Load`
  String get atlas_load {
    return Intl.message('Load', name: 'atlas_load', desc: '', locale: localeName, args: []);
  }

  /// `From Files`
  String get attach_from_files {
    return Intl.message('From Files', name: 'attach_from_files', desc: '', locale: localeName, args: []);
  }

  /// `From Photos`
  String get attach_from_photos {
    return Intl.message('From Photos', name: 'attach_from_photos', desc: '', locale: localeName, args: []);
  }

  /// `If you have trouble picking images, use files instead`
  String get attach_help {
    return Intl.message(
      'If you have trouble picking images, use files instead',
      name: 'attach_help',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Attachment`
  String get attachment {
    return Intl.message('Attachment', name: 'attachment', desc: '', locale: localeName, args: []);
  }

  /// `Attack NP Rate`
  String get attack_np_rate {
    return Intl.message('Attack NP Rate', name: 'attack_np_rate', desc: '', locale: localeName, args: []);
  }

  /// `Account Actions`
  String get auth_account_actions {
    return Intl.message('Account Actions', name: 'auth_account_actions', desc: '', locale: localeName, args: []);
  }

  /// `Admin Actions`
  String get auth_admin_actions {
    return Intl.message('Admin Actions', name: 'auth_admin_actions', desc: '', locale: localeName, args: []);
  }

  /// `Backups`
  String get auth_admin_backups_count {
    return Intl.message('Backups', name: 'auth_admin_backups_count', desc: '', locale: localeName, args: []);
  }

  /// `Basic Info`
  String get auth_admin_basic_info {
    return Intl.message('Basic Info', name: 'auth_admin_basic_info', desc: '', locale: localeName, args: []);
  }

  /// `Created At`
  String get auth_admin_created_at {
    return Intl.message('Created At', name: 'auth_admin_created_at', desc: '', locale: localeName, args: []);
  }

  /// `Load More`
  String get auth_admin_load_more {
    return Intl.message('Load More', name: 'auth_admin_load_more', desc: '', locale: localeName, args: []);
  }

  /// `Not bound`
  String get auth_admin_no_email {
    return Intl.message('Not bound', name: 'auth_admin_no_email', desc: '', locale: localeName, args: []);
  }

  /// `No users found`
  String get auth_admin_no_users {
    return Intl.message('No users found', name: 'auth_admin_no_users', desc: '', locale: localeName, args: []);
  }

  /// `Offline`
  String get auth_admin_offline {
    return Intl.message('Offline', name: 'auth_admin_offline', desc: '', locale: localeName, args: []);
  }

  /// `Online`
  String get auth_admin_online {
    return Intl.message('Online', name: 'auth_admin_online', desc: '', locale: localeName, args: []);
  }

  /// `Online Status`
  String get auth_admin_online_status {
    return Intl.message('Online Status', name: 'auth_admin_online_status', desc: '', locale: localeName, args: []);
  }

  /// `Recent Logins`
  String get auth_admin_recent_logins {
    return Intl.message('Recent Logins', name: 'auth_admin_recent_logins', desc: '', locale: localeName, args: []);
  }

  /// `Reset Password`
  String get auth_admin_reset_password {
    return Intl.message('Reset Password', name: 'auth_admin_reset_password', desc: '', locale: localeName, args: []);
  }

  /// `Reset this user's password?`
  String get auth_admin_reset_password_confirm {
    return Intl.message(
      'Reset this user\'s password?',
      name: 'auth_admin_reset_password_confirm',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Enter new password`
  String get auth_admin_reset_password_prompt {
    return Intl.message(
      'Enter new password',
      name: 'auth_admin_reset_password_prompt',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Send Recovery Email`
  String get auth_admin_send_recovery {
    return Intl.message(
      'Send Recovery Email',
      name: 'auth_admin_send_recovery',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Active Sessions`
  String get auth_admin_sessions {
    return Intl.message('Active Sessions', name: 'auth_admin_sessions', desc: '', locale: localeName, args: []);
  }

  /// `Statistics`
  String get auth_admin_statistics {
    return Intl.message('Statistics', name: 'auth_admin_statistics', desc: '', locale: localeName, args: []);
  }

  /// `Teams`
  String get auth_admin_teams_count {
    return Intl.message('Teams', name: 'auth_admin_teams_count', desc: '', locale: localeName, args: []);
  }

  /// `Admin Tools`
  String get auth_admin_tools {
    return Intl.message('Admin Tools', name: 'auth_admin_tools', desc: '', locale: localeName, args: []);
  }

  /// `User Detail`
  String get auth_admin_user_detail_title {
    return Intl.message('User Detail', name: 'auth_admin_user_detail_title', desc: '', locale: localeName, args: []);
  }

  /// `User Management`
  String get auth_admin_users_title {
    return Intl.message('User Management', name: 'auth_admin_users_title', desc: '', locale: localeName, args: []);
  }

  /// `Cancel, Go Back`
  String get auth_cancel_back {
    return Intl.message('Cancel, Go Back', name: 'auth_cancel_back', desc: '', locale: localeName, args: []);
  }

  /// `Change Email`
  String get auth_change_email_title {
    return Intl.message('Change Email', name: 'auth_change_email_title', desc: '', locale: localeName, args: []);
  }

  /// `Change Password`
  String get auth_change_password {
    return Intl.message('Change Password', name: 'auth_change_password', desc: '', locale: localeName, args: []);
  }

  /// `Change Password`
  String get auth_change_password_title {
    return Intl.message('Change Password', name: 'auth_change_password_title', desc: '', locale: localeName, args: []);
  }

  /// `After changing password, all devices will need to re-login.`
  String get auth_change_password_warning {
    return Intl.message(
      'After changing password, all devices will need to re-login.',
      name: 'auth_change_password_warning',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Change Username`
  String get auth_change_username_title {
    return Intl.message('Change Username', name: 'auth_change_username_title', desc: '', locale: localeName, args: []);
  }

  /// `Confirm Change`
  String get auth_confirm_change {
    return Intl.message('Confirm Change', name: 'auth_confirm_change', desc: '', locale: localeName, args: []);
  }

  /// `Enter password to confirm`
  String get auth_confirm_password_prompt {
    return Intl.message(
      'Enter password to confirm',
      name: 'auth_confirm_password_prompt',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Email Developer`
  String get auth_contact_developer_btn {
    return Intl.message('Email Developer', name: 'auth_contact_developer_btn', desc: '', locale: localeName, args: []);
  }

  /// `Your device UUID (please include in your message)`
  String get auth_contact_device_uuid_hint {
    return Intl.message(
      'Your device UUID (please include in your message)',
      name: 'auth_contact_device_uuid_hint',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Please provide your username and new email when contacting support`
  String get auth_contact_required_info_hint {
    return Intl.message(
      'Please provide your username and new email when contacting support',
      name: 'auth_contact_required_info_hint',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Current Email`
  String get auth_current_email {
    return Intl.message('Current Email', name: 'auth_current_email', desc: '', locale: localeName, args: []);
  }

  /// `Current Password`
  String get auth_current_password {
    return Intl.message('Current Password', name: 'auth_current_password', desc: '', locale: localeName, args: []);
  }

  /// `Current Username`
  String get auth_current_username {
    return Intl.message('Current Username', name: 'auth_current_username', desc: '', locale: localeName, args: []);
  }

  /// `Hints:\n- userId here is not friend code you saw on login/friend page\n- DO NOT share above keys or screenshot to others!!!\n- choose one of following methods to import`
  String get auth_data_hints {
    return Intl.message(
      'Hints:\n- userId here is not friend code you saw on login/friend page\n- DO NOT share above keys or screenshot to others!!!\n- choose one of following methods to import',
      name: 'auth_data_hints',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Delete Account`
  String get auth_delete_account {
    return Intl.message('Delete Account', name: 'auth_delete_account', desc: '', locale: localeName, args: []);
  }

  /// `Delete My Account`
  String get auth_delete_account_confirm {
    return Intl.message(
      'Delete My Account',
      name: 'auth_delete_account_confirm',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `All backups will be lost.`
  String get auth_delete_account_consequence_1 {
    return Intl.message(
      'All backups will be lost.',
      name: 'auth_delete_account_consequence_1',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `All shared teams will be removed.`
  String get auth_delete_account_consequence_2 {
    return Intl.message(
      'All shared teams will be removed.',
      name: 'auth_delete_account_consequence_2',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Account cannot be recovered.`
  String get auth_delete_account_consequence_3 {
    return Intl.message(
      'Account cannot be recovered.',
      name: 'auth_delete_account_consequence_3',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Login credentials will be cleared.`
  String get auth_delete_account_consequence_4 {
    return Intl.message(
      'Login credentials will be cleared.',
      name: 'auth_delete_account_consequence_4',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Delete Account`
  String get auth_delete_account_title {
    return Intl.message('Delete Account', name: 'auth_delete_account_title', desc: '', locale: localeName, args: []);
  }

  /// `This action cannot be undone. All data will be permanently deleted.`
  String get auth_delete_account_warning {
    return Intl.message(
      'This action cannot be undone. All data will be permanently deleted.',
      name: 'auth_delete_account_warning',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Device ID`
  String get auth_device_id {
    return Intl.message('Device ID', name: 'auth_device_id', desc: '', locale: localeName, args: []);
  }

  /// `The current device ID is randomly generated and may not match the server record. It updates after granting privacy consent and restarting the app.`
  String get auth_device_id_random_hint {
    return Intl.message(
      'The current device ID is randomly generated and may not match the server record. It updates after granting privacy consent and restarting the app.',
      name: 'auth_device_id_random_hint',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Email`
  String get auth_email_field {
    return Intl.message('Email', name: 'auth_email_field', desc: '', locale: localeName, args: []);
  }

  /// `Email not bound`
  String get auth_email_not_bound_hint {
    return Intl.message('Email not bound', name: 'auth_email_not_bound_hint', desc: '', locale: localeName, args: []);
  }

  /// `Didn't get the code? Check your spam folder or add us to your allowlist, then resend.`
  String get auth_email_not_received_hint {
    return Intl.message(
      'Didn\'t get the code? Check your spam folder or add us to your allowlist, then resend.',
      name: 'auth_email_not_received_hint',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `If you forgot your password, you can reset it via email or device verification.`
  String get auth_forgot_password_hint {
    return Intl.message(
      'If you forgot your password, you can reset it via email or device verification.',
      name: 'auth_forgot_password_hint',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Forgot Password?`
  String get auth_forgot_password_link {
    return Intl.message('Forgot Password?', name: 'auth_forgot_password_link', desc: '', locale: localeName, args: []);
  }

  /// `Forgot Password`
  String get auth_forgot_password_title {
    return Intl.message('Forgot Password', name: 'auth_forgot_password_title', desc: '', locale: localeName, args: []);
  }

  /// `Invalid username or password`
  String get auth_invalid_credentials {
    return Intl.message(
      'Invalid username or password',
      name: 'auth_invalid_credentials',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Login`
  String get auth_login_title {
    return Intl.message('Login', name: 'auth_login_title', desc: '', locale: localeName, args: []);
  }

  /// `Logout`
  String get auth_logout {
    return Intl.message('Logout', name: 'auth_logout', desc: '', locale: localeName, args: []);
  }

  /// `Contact the developer for help.`
  String get auth_method_contact_developer_desc {
    return Intl.message(
      'Contact the developer for help.',
      name: 'auth_method_contact_developer_desc',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Contact Developer`
  String get auth_method_contact_developer_title {
    return Intl.message(
      'Contact Developer',
      name: 'auth_method_contact_developer_title',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Verify by username and device ID.`
  String get auth_method_device_verify_desc {
    return Intl.message(
      'Verify by username and device ID.',
      name: 'auth_method_device_verify_desc',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Device Verification`
  String get auth_method_device_verify_title {
    return Intl.message(
      'Device Verification',
      name: 'auth_method_device_verify_title',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Send a reset link to your bound email.`
  String get auth_method_email_reset_desc {
    return Intl.message(
      'Send a reset link to your bound email.',
      name: 'auth_method_email_reset_desc',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Reset via Email`
  String get auth_method_email_reset_title {
    return Intl.message(
      'Reset via Email',
      name: 'auth_method_email_reset_title',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Migrate Account`
  String get auth_migrate_account {
    return Intl.message('Migrate Account', name: 'auth_migrate_account', desc: '', locale: localeName, args: []);
  }

  /// `Migration failed. Please try again.`
  String get auth_migration_failed {
    return Intl.message(
      'Migration failed. Please try again.',
      name: 'auth_migration_failed',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Account migrated successfully.`
  String get auth_migration_success {
    return Intl.message(
      'Account migrated successfully.',
      name: 'auth_migration_success',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `New Email`
  String get auth_new_email {
    return Intl.message('New Email', name: 'auth_new_email', desc: '', locale: localeName, args: []);
  }

  /// `New Username`
  String get auth_new_username {
    return Intl.message('New Username', name: 'auth_new_username', desc: '', locale: localeName, args: []);
  }

  /// `Account not migrated, tap to migrate`
  String get auth_not_migrated_hint {
    return Intl.message(
      'Account not migrated, tap to migrate',
      name: 'auth_not_migrated_hint',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Open Feedback`
  String get auth_open_feedback {
    return Intl.message('Open Feedback', name: 'auth_open_feedback', desc: '', locale: localeName, args: []);
  }

  /// `Personal Info`
  String get auth_personal_info {
    return Intl.message('Personal Info', name: 'auth_personal_info', desc: '', locale: localeName, args: []);
  }

  /// `Profile`
  String get auth_profile_title {
    return Intl.message('Profile', name: 'auth_profile_title', desc: '', locale: localeName, args: []);
  }

  /// `Register Account`
  String get auth_register_account {
    return Intl.message('Register Account', name: 'auth_register_account', desc: '', locale: localeName, args: []);
  }

  /// `Register`
  String get auth_register_title {
    return Intl.message('Register', name: 'auth_register_title', desc: '', locale: localeName, args: []);
  }

  /// `Resend Code`
  String get auth_resend_code {
    return Intl.message('Resend Code', name: 'auth_resend_code', desc: '', locale: localeName, args: []);
  }

  /// `Role`
  String get auth_role {
    return Intl.message('Role', name: 'auth_role', desc: '', locale: localeName, args: []);
  }

  /// `Admin`
  String get auth_role_admin {
    return Intl.message('Admin', name: 'auth_role_admin', desc: '', locale: localeName, args: []);
  }

  /// `Search username or email`
  String get auth_search_users {
    return Intl.message('Search username or email', name: 'auth_search_users', desc: '', locale: localeName, args: []);
  }

  /// `Send Code`
  String get auth_send_code {
    return Intl.message('Send Code', name: 'auth_send_code', desc: '', locale: localeName, args: []);
  }

  /// `Send Reset Email`
  String get auth_send_reset_email {
    return Intl.message('Send Reset Email', name: 'auth_send_reset_email', desc: '', locale: localeName, args: []);
  }

  /// `Your session has expired. Please log in again.`
  String get auth_session_expired_message {
    return Intl.message(
      'Your session has expired. Please log in again.',
      name: 'auth_session_expired_message',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Session Expired`
  String get auth_session_expired_title {
    return Intl.message('Session Expired', name: 'auth_session_expired_title', desc: '', locale: localeName, args: []);
  }

  /// `Submit Verification`
  String get auth_submit_verification {
    return Intl.message(
      'Submit Verification',
      name: 'auth_submit_verification',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `User ID`
  String get auth_user_id {
    return Intl.message('User ID', name: 'auth_user_id', desc: '', locale: localeName, args: []);
  }

  /// `User Management`
  String get auth_user_management {
    return Intl.message('User Management', name: 'auth_user_management', desc: '', locale: localeName, args: []);
  }

  /// `4-18 chars, letters/digits/underscore only`
  String get auth_username_helper {
    return Intl.message(
      '4-18 chars, letters/digits/underscore only',
      name: 'auth_username_helper',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Username or Email`
  String get auth_username_or_email {
    return Intl.message('Username or Email', name: 'auth_username_or_email', desc: '', locale: localeName, args: []);
  }

  /// `A verification code has been sent to`
  String get auth_verification_code_sent {
    return Intl.message(
      'A verification code has been sent to',
      name: 'auth_verification_code_sent',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Read usage and RISK first! `
  String get authfile_login_warning {
    return Intl.message(
      'Read usage and RISK first! ',
      name: 'authfile_login_warning',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Auto reset`
  String get auto_reset {
    return Intl.message('Auto reset', name: 'auto_reset', desc: '', locale: localeName, args: []);
  }

  /// `Auto Update`
  String get auto_update {
    return Intl.message('Auto Update', name: 'auto_update', desc: '', locale: localeName, args: []);
  }

  /// `Autoplay`
  String get autoplay {
    return Intl.message('Autoplay', name: 'autoplay', desc: '', locale: localeName, args: []);
  }

  /// `Background`
  String get background {
    return Intl.message('Background', name: 'background', desc: '', locale: localeName, args: []);
  }

  /// `Backup`
  String get backup {
    return Intl.message('Backup', name: 'backup', desc: '', locale: localeName, args: []);
  }

  /// `Backup failed`
  String get backup_failed {
    return Intl.message('Backup failed', name: 'backup_failed', desc: '', locale: localeName, args: []);
  }

  /// `Backup History`
  String get backup_history {
    return Intl.message('Backup History', name: 'backup_history', desc: '', locale: localeName, args: []);
  }

  /// `Base bond`
  String get base_bond {
    return Intl.message('Base bond', name: 'base_bond', desc: '', locale: localeName, args: []);
  }

  /// `Activate Custom Skill`
  String get battle_activate_custom_skill {
    return Intl.message(
      'Activate Custom Skill',
      name: 'battle_activate_custom_skill',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Activation Probability`
  String get battle_activate_probability {
    return Intl.message(
      'Activation Probability',
      name: 'battle_activate_probability',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Ally`
  String get battle_ally {
    return Intl.message('Ally', name: 'battle_ally', desc: '', locale: localeName, args: []);
  }

  /// `Attack NP Parameters`
  String get battle_atk_np_parameters {
    return Intl.message(
      'Attack NP Parameters',
      name: 'battle_atk_np_parameters',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Attack`
  String get battle_attack {
    return Intl.message('Attack', name: 'battle_attack', desc: '', locale: localeName, args: []);
  }

  /// `Battle Log`
  String get battle_battle_log {
    return Intl.message('Battle Log', name: 'battle_battle_log', desc: '', locale: localeName, args: []);
  }

  /// `Permanent`
  String get battle_buff_permanent {
    return Intl.message('Permanent', name: 'battle_buff_permanent', desc: '', locale: localeName, args: []);
  }

  /// `Buster Chain Damage`
  String get battle_buster_chain {
    return Intl.message('Buster Chain Damage', name: 'battle_buster_chain', desc: '', locale: localeName, args: []);
  }

  /// `Disable used command card`
  String get battle_card_deck_simulation {
    return Intl.message(
      'Disable used command card',
      name: 'battle_card_deck_simulation',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Card NP Rate`
  String get battle_card_np_rate {
    return Intl.message('Card NP Rate', name: 'battle_card_np_rate', desc: '', locale: localeName, args: []);
  }

  /// `Card Star Rate`
  String get battle_card_star_rate {
    return Intl.message('Card Star Rate', name: 'battle_card_star_rate', desc: '', locale: localeName, args: []);
  }

  /// `Change Ascension`
  String get battle_change_ascension {
    return Intl.message('Change Ascension', name: 'battle_change_ascension', desc: '', locale: localeName, args: []);
  }

  /// `Charge 100% NP to party`
  String get battle_charge_party {
    return Intl.message('Charge 100% NP to party', name: 'battle_charge_party', desc: '', locale: localeName, args: []);
  }

  /// `Click to select servant`
  String get battle_click_to_select_servants {
    return Intl.message(
      'Click to select servant',
      name: 'battle_click_to_select_servants',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Command Card`
  String get battle_command_card {
    return Intl.message('Command Card', name: 'battle_command_card', desc: '', locale: localeName, args: []);
  }

  /// `Damage`
  String get battle_damage {
    return Intl.message('Damage', name: 'battle_damage', desc: '', locale: localeName, args: []);
  }

  /// `Damage Parameters`
  String get battle_damage_parameters {
    return Intl.message('Damage Parameters', name: 'battle_damage_parameters', desc: '', locale: localeName, args: []);
  }

  /// `Damage Rate`
  String get battle_damage_rate {
    return Intl.message('Damage Rate', name: 'battle_damage_rate', desc: '', locale: localeName, args: []);
  }

  /// `Defeated`
  String get battle_death {
    return Intl.message('Defeated', name: 'battle_death', desc: '', locale: localeName, args: []);
  }

  /// `Edit Servant Option`
  String get battle_edit_servant_option {
    return Intl.message(
      'Edit Servant Option',
      name: 'battle_edit_servant_option',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Enemy Remaining`
  String get battle_enemy_remaining {
    return Intl.message('Enemy Remaining', name: 'battle_enemy_remaining', desc: '', locale: localeName, args: []);
  }

  /// `Extra Damage Rate`
  String get battle_extra_rate {
    return Intl.message('Extra Damage Rate', name: 'battle_extra_rate', desc: '', locale: localeName, args: []);
  }

  /// `First Card Bonus`
  String get battle_first_card_bonus {
    return Intl.message('First Card Bonus', name: 'battle_first_card_bonus', desc: '', locale: localeName, args: []);
  }

  /// `Heal`
  String get battle_heal {
    return Intl.message('Heal', name: 'battle_heal', desc: '', locale: localeName, args: []);
  }

  /// `Invalid`
  String get battle_invalid {
    return Intl.message('Invalid', name: 'battle_invalid', desc: '', locale: localeName, args: []);
  }

  /// `Misc Configs`
  String get battle_misc_config {
    return Intl.message('Misc Configs', name: 'battle_misc_config', desc: '', locale: localeName, args: []);
  }

  /// `No quest phase selected.`
  String get battle_no_quest_phase {
    return Intl.message(
      'No quest phase selected.',
      name: 'battle_no_quest_phase',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `No servant selected.`
  String get battle_no_servant {
    return Intl.message('No servant selected.', name: 'battle_no_servant', desc: '', locale: localeName, args: []);
  }

  /// `No skill selected`
  String get battle_no_skill_selected {
    return Intl.message('No skill selected', name: 'battle_no_skill_selected', desc: '', locale: localeName, args: []);
  }

  /// `No Source`
  String get battle_no_source {
    return Intl.message('No Source', name: 'battle_no_source', desc: '', locale: localeName, args: []);
  }

  /// `NP Card`
  String get battle_np_card {
    return Intl.message('NP Card', name: 'battle_np_card', desc: '', locale: localeName, args: []);
  }

  /// `Probability Threshold`
  String get battle_probability_threshold {
    return Intl.message(
      'Probability Threshold',
      name: 'battle_probability_threshold',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `From`
  String get battle_quest_from {
    return Intl.message('From', name: 'battle_quest_from', desc: '', locale: localeName, args: []);
  }

  /// `Random`
  String get battle_random {
    return Intl.message('Random', name: 'battle_random', desc: '', locale: localeName, args: []);
  }

  /// `Records`
  String get battle_records {
    return Intl.message('Records', name: 'battle_records', desc: '', locale: localeName, args: []);
  }

  /// `Remaining HP`
  String get battle_remaining_hp {
    return Intl.message('Remaining HP', name: 'battle_remaining_hp', desc: '', locale: localeName, args: []);
  }

  /// `Required field traits`
  String get battle_require_field_traits {
    return Intl.message(
      'Required field traits',
      name: 'battle_require_field_traits',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Required opponent traits`
  String get battle_require_opponent_traits {
    return Intl.message(
      'Required opponent traits',
      name: 'battle_require_opponent_traits',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Select Activator`
  String get battle_select_activator {
    return Intl.message('Select Activator', name: 'battle_select_activator', desc: '', locale: localeName, args: []);
  }

  /// `Select Card`
  String get battle_select_card {
    return Intl.message('Select Card', name: 'battle_select_card', desc: '', locale: localeName, args: []);
  }

  /// `Repeatedly click Command Card and will be Critical Attack when in red`
  String get battle_select_critical_card_hint {
    return Intl.message(
      'Repeatedly click Command Card and will be Critical Attack when in red',
      name: 'battle_select_critical_card_hint',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Select Effect`
  String get battle_select_effect {
    return Intl.message('Select Effect', name: 'battle_select_effect', desc: '', locale: localeName, args: []);
  }

  /// `Should Activate`
  String get battle_should_activate {
    return Intl.message('Should Activate', name: 'battle_should_activate', desc: '', locale: localeName, args: []);
  }

  /// `Battle Simulation`
  String get battle_simulation {
    return Intl.message('Battle Simulation', name: 'battle_simulation', desc: '', locale: localeName, args: []);
  }

  /// `Team Setup`
  String get battle_simulation_setup {
    return Intl.message('Team Setup', name: 'battle_simulation_setup', desc: '', locale: localeName, args: []);
  }

  /// `Skip current stage`
  String get battle_skip_current_wave {
    return Intl.message('Skip current stage', name: 'battle_skip_current_wave', desc: '', locale: localeName, args: []);
  }

  /// `Star Parameters`
  String get battle_star_parameters {
    return Intl.message('Star Parameters', name: 'battle_star_parameters', desc: '', locale: localeName, args: []);
  }

  /// `Manual random value mode`
  String get battle_tailored_execution {
    return Intl.message(
      'Manual random value mode',
      name: 'battle_tailored_execution',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Make sure enemy/ally are correctly targeted first.`
  String get battle_targeted_required_hint {
    return Intl.message(
      'Make sure enemy/ally are correctly targeted first.',
      name: 'battle_targeted_required_hint',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Turn`
  String get battle_turn {
    return Intl.message('Turn', name: 'battle_turn', desc: '', locale: localeName, args: []);
  }

  /// `Turn End`
  String get battle_turn_end {
    return Intl.message('Turn End', name: 'battle_turn_end', desc: '', locale: localeName, args: []);
  }

  /// `Undo last action`
  String get battle_undo {
    return Intl.message('Undo last action', name: 'battle_undo', desc: '', locale: localeName, args: []);
  }

  /// `Beast's Footprint`
  String get beast_footprint {
    return Intl.message('Beast\'s Footprint', name: 'beast_footprint', desc: '', locale: localeName, args: []);
  }

  /// `BGM`
  String get bgm {
    return Intl.message('BGM', name: 'bgm', desc: '', locale: localeName, args: []);
  }

  /// `Blacklist`
  String get blacklist {
    return Intl.message('Blacklist', name: 'blacklist', desc: '', locale: localeName, args: []);
  }

  /// `Bond`
  String get bond {
    return Intl.message('Bond', name: 'bond', desc: '', locale: localeName, args: []);
  }

  /// `Bond Bonus`
  String get bond_bonus {
    return Intl.message('Bond Bonus', name: 'bond_bonus', desc: '', locale: localeName, args: []);
  }

  /// `All settings in positions beyond this limit will be cleared (servants, support, CEs, Grand, etc.).`
  String get bond_clear_excess_positions {
    return Intl.message(
      'All settings in positions beyond this limit will be cleared (servants, support, CEs, Grand, etc.).',
      name: 'bond_clear_excess_positions',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Bond Craft`
  String get bond_craft {
    return Intl.message('Bond Craft', name: 'bond_craft', desc: '', locale: localeName, args: []);
  }

  /// `Bond Eff`
  String get bond_eff {
    return Intl.message('Bond Eff', name: 'bond_eff', desc: '', locale: localeName, args: []);
  }

  /// `Change Bond CE effect`
  String get bond_equip_change_skill {
    return Intl.message(
      'Change Bond CE effect',
      name: 'bond_equip_change_skill',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Bond Limit`
  String get bond_limit {
    return Intl.message('Bond Limit', name: 'bond_limit', desc: '', locale: localeName, args: []);
  }

  /// `Max servants`
  String get bond_max_servants {
    return Intl.message('Max servants', name: 'bond_max_servants', desc: '', locale: localeName, args: []);
  }

  /// `Bond not maxed only`
  String get bond_not_full_only {
    return Intl.message('Bond not maxed only', name: 'bond_not_full_only', desc: '', locale: localeName, args: []);
  }

  /// `Search fixed servant ascensions`
  String get bond_search_fixed_ascensions {
    return Intl.message(
      'Search fixed servant ascensions',
      name: 'bond_search_fixed_ascensions',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Bootstrap Page`
  String get bootstrap_page_title {
    return Intl.message('Bootstrap Page', name: 'bootstrap_page_title', desc: '', locale: localeName, args: []);
  }

  /// `Branch Quest`
  String get branch_quest {
    return Intl.message('Branch Quest', name: 'branch_quest', desc: '', locale: localeName, args: []);
  }

  /// `Bronze`
  String get bronze {
    return Intl.message('Bronze', name: 'bronze', desc: '', locale: localeName, args: []);
  }

  /// `Opponent`
  String get buff_check_opponent {
    return Intl.message('Opponent', name: 'buff_check_opponent', desc: '', locale: localeName, args: []);
  }

  /// `Self`
  String get buff_check_self {
    return Intl.message('Self', name: 'buff_check_self', desc: '', locale: localeName, args: []);
  }

  /// `Cache Icons`
  String get cache_icons {
    return Intl.message('Cache Icons', name: 'cache_icons', desc: '', locale: localeName, args: []);
  }

  /// `Weight`
  String get calc_weight {
    return Intl.message('Weight', name: 'calc_weight', desc: '', locale: localeName, args: []);
  }

  /// `Calculate`
  String get calculate {
    return Intl.message('Calculate', name: 'calculate', desc: '', locale: localeName, args: []);
  }

  /// `Cancel`
  String get cancel {
    return Intl.message('Cancel', name: 'cancel', desc: '', locale: localeName, args: []);
  }

  /// `Figure`
  String get card_asset_chara_figure {
    return Intl.message('Figure', name: 'card_asset_chara_figure', desc: '', locale: localeName, args: []);
  }

  /// `Command Card`
  String get card_asset_command {
    return Intl.message('Command Card', name: 'card_asset_command', desc: '', locale: localeName, args: []);
  }

  /// `Thumbnail`
  String get card_asset_face {
    return Intl.message('Thumbnail', name: 'card_asset_face', desc: '', locale: localeName, args: []);
  }

  /// `Formation`
  String get card_asset_narrow_figure {
    return Intl.message('Formation', name: 'card_asset_narrow_figure', desc: '', locale: localeName, args: []);
  }

  /// `Status Icon`
  String get card_asset_status {
    return Intl.message('Status Icon', name: 'card_asset_status', desc: '', locale: localeName, args: []);
  }

  /// `Status`
  String get card_collection_status {
    return Intl.message('Status', name: 'card_collection_status', desc: '', locale: localeName, args: []);
  }

  /// `Description`
  String get card_description {
    return Intl.message('Description', name: 'card_description', desc: '', locale: localeName, args: []);
  }

  /// `Info`
  String get card_info {
    return Intl.message('Info', name: 'card_info', desc: '', locale: localeName, args: []);
  }

  /// `Card Name`
  String get card_name {
    return Intl.message('Card Name', name: 'card_name', desc: '', locale: localeName, args: []);
  }

  /// `{count} of total {total} command cards didn't attack, please remove unnecessary cards`
  String card_not_attack_warning(Object count, Object total) {
    return Intl.message(
      '$count of total $total command cards didn\'t attack, please remove unnecessary cards',
      name: 'card_not_attack_warning',
      desc: '',
      locale: localeName,
      args: [count, total],
    );
  }

  /// `Met`
  String get card_status_met {
    return Intl.message('Met', name: 'card_status_met', desc: '', locale: localeName, args: []);
  }

  /// `Not Met`
  String get card_status_not_met {
    return Intl.message('Not Met', name: 'card_status_not_met', desc: '', locale: localeName, args: []);
  }

  /// `Owned`
  String get card_status_owned {
    return Intl.message('Owned', name: 'card_status_owned', desc: '', locale: localeName, args: []);
  }

  /// `Card Strengthen`
  String get card_strengthen {
    return Intl.message('Card Strengthen', name: 'card_strengthen', desc: '', locale: localeName, args: []);
  }

  /// `Carousel`
  String get carousel {
    return Intl.message('Carousel', name: 'carousel', desc: '', locale: localeName, args: []);
  }

  /// `Equipped Servants`
  String get cc_equipped_svt {
    return Intl.message('Equipped Servants', name: 'cc_equipped_svt', desc: '', locale: localeName, args: []);
  }

  /// `Please add custom skills/buffs through servant options`
  String get ce_custom_skill_hint {
    return Intl.message(
      'Please add custom skills/buffs through servant options',
      name: 'ce_custom_skill_hint',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Chaldea Account`
  String get chaldea_account {
    return Intl.message('Chaldea Account', name: 'chaldea_account', desc: '', locale: localeName, args: []);
  }

  /// `  Not compatible with V1 data.\n  A simple account system for userdata backup to server and multi-device synchronization\n  NO security guarantee, PLEASE DON'T set frequently used passwords!!!\n  No need to register if you do not need these two features.`
  String get chaldea_account_system_hint {
    return Intl.message(
      '  Not compatible with V1 data.\n  A simple account system for userdata backup to server and multi-device synchronization\n  NO security guarantee, PLEASE DON\'T set frequently used passwords!!!\n  No need to register if you do not need these two features.',
      name: 'chaldea_account_system_hint',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Chaldea App Backup`
  String get chaldea_backup {
    return Intl.message('Chaldea App Backup', name: 'chaldea_backup', desc: '', locale: localeName, args: []);
  }

  /// `Chaldea Gate`
  String get chaldea_gate {
    return Intl.message('Chaldea Gate', name: 'chaldea_gate', desc: '', locale: localeName, args: []);
  }

  /// `5{kstar} Summons`
  String chaldea_report_5star_pull(Object kstar) {
    return Intl.message(
      '5$kstar Summons',
      name: 'chaldea_report_5star_pull',
      desc: '',
      locale: localeName,
      args: [kstar],
    );
  }

  /// `5{kstar} Summon Probability`
  String chaldea_report_5star_pull_prob(Object kstar) {
    return Intl.message(
      '5$kstar Summon Probability',
      name: 'chaldea_report_5star_pull_prob',
      desc: '',
      locale: localeName,
      args: [kstar],
    );
  }

  /// `- Based on historical data, Lucky Bag pulls removed`
  String get chaldea_report_5star_stat_dis_detail {
    return Intl.message(
      '- Based on historical data, Lucky Bag pulls removed',
      name: 'chaldea_report_5star_stat_dis_detail',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `- For entertainment purpose only`
  String get chaldea_report_5star_stat_dis_ent {
    return Intl.message(
      '- For entertainment purpose only',
      name: 'chaldea_report_5star_stat_dis_ent',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `5{kstar} Count / NP Lvs`
  String chaldea_report_5star_svts_count(Object kstar) {
    return Intl.message(
      '5$kstar Count / NP Lvs',
      name: 'chaldea_report_5star_svts_count',
      desc: '',
      locale: localeName,
      args: [kstar],
    );
  }

  /// `Master for`
  String get chaldea_report_account_created {
    return Intl.message('Master for', name: 'chaldea_report_account_created', desc: '', locale: localeName, args: []);
  }

  /// `Servant Collections`
  String get chaldea_report_compendium {
    return Intl.message(
      'Servant Collections',
      name: 'chaldea_report_compendium',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Year {year}`
  String chaldea_report_cur_year(Object year) {
    return Intl.message('Year $year', name: 'chaldea_report_cur_year', desc: '', locale: localeName, args: [year]);
  }

  /// `Favorite`
  String get chaldea_report_favorite {
    return Intl.message('Favorite', name: 'chaldea_report_favorite', desc: '', locale: localeName, args: []);
  }

  /// `Conclusion`
  String get chaldea_report_likely {
    return Intl.message('Conclusion', name: 'chaldea_report_likely', desc: '', locale: localeName, args: []);
  }

  /// `Grand Gacha God`
  String get chaldea_report_luck_grand_lucky {
    return Intl.message(
      'Grand Gacha God',
      name: 'chaldea_report_luck_grand_lucky',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `You're the chosen one!`
  String get chaldea_report_luck_grand_lucky_desc {
    return Intl.message(
      'You\'re the chosen one!',
      name: 'chaldea_report_luck_grand_lucky_desc',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Gacha King`
  String get chaldea_report_luck_lucky {
    return Intl.message('Gacha King', name: 'chaldea_report_luck_lucky', desc: '', locale: localeName, args: []);
  }

  /// `The fate favors you.`
  String get chaldea_report_luck_lucky_desc {
    return Intl.message(
      'The fate favors you.',
      name: 'chaldea_report_luck_lucky_desc',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Gacha Man`
  String get chaldea_report_luck_mid_lucky {
    return Intl.message('Gacha Man', name: 'chaldea_report_luck_mid_lucky', desc: '', locale: localeName, args: []);
  }

  /// `Stability is a gift.`
  String get chaldea_report_luck_mid_lucky_desc {
    return Intl.message(
      'Stability is a gift.',
      name: 'chaldea_report_luck_mid_lucky_desc',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Gacha Gambit`
  String get chaldea_report_luck_not_lucky {
    return Intl.message('Gacha Gambit', name: 'chaldea_report_luck_not_lucky', desc: '', locale: localeName, args: []);
  }

  /// `Saving luck for next time.`
  String get chaldea_report_luck_not_lucky_desc {
    return Intl.message(
      'Saving luck for next time.',
      name: 'chaldea_report_luck_not_lucky_desc',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Gacha Enjoyer`
  String get chaldea_report_luck_unlucky {
    return Intl.message('Gacha Enjoyer', name: 'chaldea_report_luck_unlucky', desc: '', locale: localeName, args: []);
  }

  /// `Next time for sure!`
  String get chaldea_report_luck_unlucky_desc {
    return Intl.message(
      'Next time for sure!',
      name: 'chaldea_report_luck_unlucky_desc',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Grand Gacha Enjoyer`
  String get chaldea_report_luck_very_unlucky {
    return Intl.message(
      'Grand Gacha Enjoyer',
      name: 'chaldea_report_luck_very_unlucky',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `I roll for Mana Prisms.`
  String get chaldea_report_luck_very_unlucky_desc {
    return Intl.message(
      'I roll for Mana Prisms.',
      name: 'chaldea_report_luck_very_unlucky_desc',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Most Event Free`
  String get chaldea_report_most_event_free {
    return Intl.message(
      'Most Event Free',
      name: 'chaldea_report_most_event_free',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Most Failures`
  String get chaldea_report_most_fail {
    return Intl.message('Most Failures', name: 'chaldea_report_most_fail', desc: '', locale: localeName, args: []);
  }

  /// `Most Free`
  String get chaldea_report_most_free {
    return Intl.message('Most Free', name: 'chaldea_report_most_free', desc: '', locale: localeName, args: []);
  }

  /// `Most Raid`
  String get chaldea_report_most_raid {
    return Intl.message('Most Raid', name: 'chaldea_report_most_raid', desc: '', locale: localeName, args: []);
  }

  /// `{curYear} Pulls`
  String chaldea_report_pull_cur_year(Object curYear) {
    return Intl.message(
      '$curYear Pulls',
      name: 'chaldea_report_pull_cur_year',
      desc: '',
      locale: localeName,
      args: [curYear],
    );
  }

  /// `All Time`
  String get chaldea_report_pull_stat_all {
    return Intl.message('All Time', name: 'chaldea_report_pull_stat_all', desc: '', locale: localeName, args: []);
  }

  /// `{curYear}`
  String chaldea_report_pull_stat_cur_year(Object curYear) {
    return Intl.message(
      '$curYear',
      name: 'chaldea_report_pull_stat_cur_year',
      desc: '',
      locale: localeName,
      args: [curYear],
    );
  }

  /// `{curYear} Top {count} Pulls`
  String chaldea_report_pull_stat_top_title(Object curYear, Object count) {
    return Intl.message(
      '$curYear Top $count Pulls',
      name: 'chaldea_report_pull_stat_top_title',
      desc: '',
      locale: localeName,
      args: [curYear, count],
    );
  }

  /// `Push`
  String get chaldea_report_push {
    return Intl.message('Push', name: 'chaldea_report_push', desc: '', locale: localeName, args: []);
  }

  /// `Quest Stat`
  String get chaldea_report_quests_stat {
    return Intl.message('Quest Stat', name: 'chaldea_report_quests_stat', desc: '', locale: localeName, args: []);
  }

  /// `for {year}yr {month}mo {day}d`
  String chaldea_report_since_account_created_date(Object year, Object month, Object day) {
    return Intl.message(
      'for ${year}yr ${month}mo ${day}d',
      name: 'chaldea_report_since_account_created_date',
      desc: '',
      locale: localeName,
      args: [year, month, day],
    );
  }

  /// ` Times`
  String get chaldea_report_times {
    return Intl.message(' Times', name: 'chaldea_report_times', desc: '', locale: localeName, args: []);
  }

  /// `Chaldea Report`
  String get chaldea_report_title {
    return Intl.message('Chaldea Report', name: 'chaldea_report_title', desc: '', locale: localeName, args: []);
  }

  /// ` Days`
  String get chaldea_report_total_days {
    return Intl.message(' Days', name: 'chaldea_report_total_days', desc: '', locale: localeName, args: []);
  }

  /// `Total Login`
  String get chaldea_report_total_login {
    return Intl.message('Total Login', name: 'chaldea_report_total_login', desc: '', locale: localeName, args: []);
  }

  /// `Servants`
  String get chaldea_report_total_svts {
    return Intl.message('Servants', name: 'chaldea_report_total_svts', desc: '', locale: localeName, args: []);
  }

  /// `Please adjust window size`
  String get chaldea_report_window_size_warn {
    return Intl.message(
      'Please adjust window size',
      name: 'chaldea_report_window_size_warn',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Chaldea Server`
  String get chaldea_server {
    return Intl.message('Chaldea Server', name: 'chaldea_server', desc: '', locale: localeName, args: []);
  }

  /// `China`
  String get chaldea_server_cn {
    return Intl.message('China', name: 'chaldea_server_cn', desc: '', locale: localeName, args: []);
  }

  /// `Global`
  String get chaldea_server_global {
    return Intl.message('Global', name: 'chaldea_server_global', desc: '', locale: localeName, args: []);
  }

  /// `Chaldea - A cross-platform utility for Fate/GO. Supporting game data review, servant/event/item planning, master mission planning, summon simulator and so on.\n\nFor details: \n{url}\n`
  String chaldea_share_msg(Object url) {
    return Intl.message(
      'Chaldea - A cross-platform utility for Fate/GO. Supporting game data review, servant/event/item planning, master mission planning, summon simulator and so on.\n\nFor details: \n$url\n',
      name: 'chaldea_share_msg',
      desc: '',
      locale: localeName,
      args: [url],
    );
  }

  /// `Change Log`
  String get change_log {
    return Intl.message('Change Log', name: 'change_log', desc: '', locale: localeName, args: []);
  }

  /// `Characters`
  String get characters_in_card {
    return Intl.message('Characters', name: 'characters_in_card', desc: '', locale: localeName, args: []);
  }

  /// `Charge NP to {count}`
  String charge_np_to(Object count) {
    return Intl.message('Charge NP to $count', name: 'charge_np_to', desc: '', locale: localeName, args: [count]);
  }

  /// `Verify file integrity`
  String get check_file_hash {
    return Intl.message('Verify file integrity', name: 'check_file_hash', desc: '', locale: localeName, args: []);
  }

  /// `Check update`
  String get check_update {
    return Intl.message('Check update', name: 'check_update', desc: '', locale: localeName, args: []);
  }

  /// `Class Advantage`
  String get class_advantage {
    return Intl.message('Class Advantage', name: 'class_advantage', desc: '', locale: localeName, args: []);
  }

  /// `Class Damage Multiplier`
  String get class_attack_rate {
    return Intl.message('Class Damage Multiplier', name: 'class_attack_rate', desc: '', locale: localeName, args: []);
  }

  /// `Class Score`
  String get class_board {
    return Intl.message('Class Score', name: 'class_board', desc: '', locale: localeName, args: []);
  }

  /// `Sign`
  String get class_board_square {
    return Intl.message('Sign', name: 'class_board_square', desc: '', locale: localeName, args: []);
  }

  /// `Clear`
  String get clear {
    return Intl.message('Clear', name: 'clear', desc: '', locale: localeName, args: []);
  }

  /// `Clear Backups`
  String get clear_backup {
    return Intl.message('Clear Backups', name: 'clear_backup', desc: '', locale: localeName, args: []);
  }

  /// `Clear Cache`
  String get clear_cache {
    return Intl.message('Clear Cache', name: 'clear_cache', desc: '', locale: localeName, args: []);
  }

  /// `Cache cleared`
  String get clear_cache_finish {
    return Intl.message('Cache cleared', name: 'clear_cache_finish', desc: '', locale: localeName, args: []);
  }

  /// `Including illustrations, voices`
  String get clear_cache_hint {
    return Intl.message(
      'Including illustrations, voices',
      name: 'clear_cache_hint',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Clear Data`
  String get clear_data {
    return Intl.message('Clear Data', name: 'clear_data', desc: '', locale: localeName, args: []);
  }

  /// `Summon Coins`
  String get coin_summon_num {
    return Intl.message('Summon Coins', name: 'coin_summon_num', desc: '', locale: localeName, args: []);
  }

  /// `Collapse`
  String get collapse {
    return Intl.message('Collapse', name: 'collapse', desc: '', locale: localeName, args: []);
  }

  /// `Command Assist`
  String get command_assist {
    return Intl.message('Command Assist', name: 'command_assist', desc: '', locale: localeName, args: []);
  }

  /// `Command Code`
  String get command_code {
    return Intl.message('Command Code', name: 'command_code', desc: '', locale: localeName, args: []);
  }

  /// `CC`
  String get command_code_short {
    return Intl.message('CC', name: 'command_code_short', desc: '', locale: localeName, args: []);
  }

  /// `Command Spell`
  String get command_spell {
    return Intl.message('Command Spell', name: 'command_spell', desc: '', locale: localeName, args: []);
  }

  /// `Only need to meet one *Group* of conditions`
  String get common_release_group_hint {
    return Intl.message(
      'Only need to meet one *Group* of conditions',
      name: 'common_release_group_hint',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Condition`
  String get condition {
    return Intl.message('Condition', name: 'condition', desc: '', locale: localeName, args: []);
  }

  /// `Confirm`
  String get confirm {
    return Intl.message('Confirm', name: 'confirm', desc: '', locale: localeName, args: []);
  }

  /// `Agree`
  String get consent_agree {
    return Intl.message('Agree', name: 'consent_agree', desc: '', locale: localeName, args: []);
  }

  /// `To provide optional features such as crash diagnostics, product analytics and advertising, we need your consent to process certain device information. If you disagree, these optional features stay off while everything else (including data updates and cloud backup) keeps working. You can withdraw consent, disable personalized ads, or delete your account anytime in Settings → Privacy & Data.`
  String get consent_body_optional {
    return Intl.message(
      'To provide optional features such as crash diagnostics, product analytics and advertising, we need your consent to process certain device information. If you disagree, these optional features stay off while everything else (including data updates and cloud backup) keeps working. You can withdraw consent, disable personalized ads, or delete your account anytime in Settings → Privacy & Data.',
      name: 'consent_body_optional',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Disagree`
  String get consent_disagree {
    return Intl.message('Disagree', name: 'consent_disagree', desc: '', locale: localeName, args: []);
  }

  /// `Privacy Policy`
  String get consent_title {
    return Intl.message('Privacy Policy', name: 'consent_title', desc: '', locale: localeName, args: []);
  }

  /// `We have updated the Chaldea Privacy Policy. Please review and confirm the updated policy before continuing.`
  String get consent_update_body {
    return Intl.message(
      'We have updated the Chaldea Privacy Policy. Please review and confirm the updated policy before continuing.',
      name: 'consent_update_body',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Privacy Policy Updated`
  String get consent_update_title {
    return Intl.message('Privacy Policy Updated', name: 'consent_update_title', desc: '', locale: localeName, args: []);
  }

  /// `View Privacy Policy`
  String get consent_view_policy {
    return Intl.message('View Privacy Policy', name: 'consent_view_policy', desc: '', locale: localeName, args: []);
  }

  /// `Consumed`
  String get consumed {
    return Intl.message('Consumed', name: 'consumed', desc: '', locale: localeName, args: []);
  }

  /// `Contact information is not filled in`
  String get contact_information_not_filled {
    return Intl.message(
      'Contact information is not filled in',
      name: 'contact_information_not_filled',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Copied`
  String get copied {
    return Intl.message('Copied', name: 'copied', desc: '', locale: localeName, args: []);
  }

  /// `Copy`
  String get copy {
    return Intl.message('Copy', name: 'copy', desc: '', locale: localeName, args: []);
  }

  /// `Copy Plan from...`
  String get copy_plan_menu {
    return Intl.message('Copy Plan from...', name: 'copy_plan_menu', desc: '', locale: localeName, args: []);
  }

  /// `Cost`
  String get cost {
    return Intl.message('Cost', name: 'cost', desc: '', locale: localeName, args: []);
  }

  /// `Costume`
  String get costume {
    return Intl.message('Costume', name: 'costume', desc: '', locale: localeName, args: []);
  }

  /// `Costume Unlock`
  String get costume_unlock {
    return Intl.message('Costume Unlock', name: 'costume_unlock', desc: '', locale: localeName, args: []);
  }

  /// `Counts`
  String get counts {
    return Intl.message('Counts', name: 'counts', desc: '', locale: localeName, args: []);
  }

  /// `Craft Essence`
  String get craft_essence {
    return Intl.message('Craft Essence', name: 'craft_essence', desc: '', locale: localeName, args: []);
  }

  /// `CE`
  String get craft_essence_short {
    return Intl.message('CE', name: 'craft_essence_short', desc: '', locale: localeName, args: []);
  }

  /// `Crash Diagnostics`
  String get crash_report {
    return Intl.message('Crash Diagnostics', name: 'crash_report', desc: '', locale: localeName, args: []);
  }

  /// `Report crash logs and device info to help fix issues.`
  String get crash_report_desc {
    return Intl.message(
      'Report crash logs and device info to help fix issues.',
      name: 'crash_report_desc',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `You can add more accounts later in Settings`
  String get create_account_textfield_helper {
    return Intl.message(
      'You can add more accounts later in Settings',
      name: 'create_account_textfield_helper',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Create Custom Skill`
  String get create_custom_skill {
    return Intl.message('Create Custom Skill', name: 'create_custom_skill', desc: '', locale: localeName, args: []);
  }

  /// `Create duplicated`
  String get create_duplicated_svt {
    return Intl.message('Create duplicated', name: 'create_duplicated_svt', desc: '', locale: localeName, args: []);
  }

  /// `Create Mooncell Summon`
  String get create_mooncell_summon {
    return Intl.message(
      'Create Mooncell Summon',
      name: 'create_mooncell_summon',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Crit Star Mod`
  String get crit_star_mod {
    return Intl.message('Crit Star Mod', name: 'crit_star_mod', desc: '', locale: localeName, args: []);
  }

  /// `Critical`
  String get critical_attack {
    return Intl.message('Critical', name: 'critical_attack', desc: '', locale: localeName, args: []);
  }

  /// `Critical Star`
  String get critical_star {
    return Intl.message('Critical Star', name: 'critical_star', desc: '', locale: localeName, args: []);
  }

  /// `Critical Team`
  String get critical_team {
    return Intl.message('Critical Team', name: 'critical_team', desc: '', locale: localeName, args: []);
  }

  /// `Current Account`
  String get cur_account {
    return Intl.message('Current Account', name: 'cur_account', desc: '', locale: localeName, args: []);
  }

  /// `Current`
  String get current_ {
    return Intl.message('Current', name: 'current_', desc: '', locale: localeName, args: []);
  }

  /// `Current Version`
  String get current_version {
    return Intl.message('Current Version', name: 'current_version', desc: '', locale: localeName, args: []);
  }

  /// `Custom Chara Figure Face`
  String get custom_chara_figure {
    return Intl.message(
      'Custom Chara Figure Face',
      name: 'custom_chara_figure',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Long press on any Figure(with multiple faces, url contains /CharaFigure/[id]/) will take you here. Or input the figure id/url below.\n - Servant-Illustration-Figure\n - Event/War "Assets" page\n - Story script - open menu - Assets`
  String get custom_chara_figure_intro {
    return Intl.message(
      'Long press on any Figure(with multiple faces, url contains /CharaFigure/[id]/) will take you here. Or input the figure id/url below.\n - Servant-Illustration-Figure\n - Event/War "Assets" page\n - Story script - open menu - Assets',
      name: 'custom_chara_figure_intro',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Custom Mission`
  String get custom_mission {
    return Intl.message('Custom Mission', name: 'custom_mission', desc: '', locale: localeName, args: []);
  }

  /// `Enemy conditions and Quest conditions must not be mixed in one mission`
  String get custom_mission_mixed_type_hint {
    return Intl.message(
      'Enemy conditions and Quest conditions must not be mixed in one mission',
      name: 'custom_mission_mixed_type_hint',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `No mission, click + to add mission`
  String get custom_mission_nothing_hint {
    return Intl.message(
      'No mission, click + to add mission',
      name: 'custom_mission_nothing_hint',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Original Mission`
  String get custom_mission_source_mission {
    return Intl.message(
      'Original Mission',
      name: 'custom_mission_source_mission',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Custom Skill`
  String get custom_skill {
    return Intl.message('Custom Skill', name: 'custom_skill', desc: '', locale: localeName, args: []);
  }

  /// `Ember Gathering`
  String get daily_ember_quest {
    return Intl.message('Ember Gathering', name: 'daily_ember_quest', desc: '', locale: localeName, args: []);
  }

  /// `Enter the Treasure Vault`
  String get daily_qp_quest {
    return Intl.message('Enter the Treasure Vault', name: 'daily_qp_quest', desc: '', locale: localeName, args: []);
  }

  /// `Training Ground`
  String get daily_training_quest {
    return Intl.message('Training Ground', name: 'daily_training_quest', desc: '', locale: localeName, args: []);
  }

  /// `Damage`
  String get damage {
    return Intl.message('Damage', name: 'damage', desc: '', locale: localeName, args: []);
  }

  /// `More Powerful with Lower/Higher HP: Use MAX Rate`
  String get damage_np_hp_ratio_max_rate {
    return Intl.message(
      'More Powerful with Lower/Higher HP: Use MAX Rate',
      name: 'damage_np_hp_ratio_max_rate',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `More powerful with more stackable traits`
  String get damage_np_indiv_sum_count {
    return Intl.message(
      'More powerful with more stackable traits',
      name: 'damage_np_indiv_sum_count',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Damage Rate`
  String get damage_rate {
    return Intl.message('Damage Rate', name: 'damage_rate', desc: '', locale: localeName, args: []);
  }

  /// `Click to show calculation parameters`
  String get damage_recorder_param_hint {
    return Intl.message(
      'Click to show calculation parameters',
      name: 'damage_recorder_param_hint',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Dark mode`
  String get dark_mode {
    return Intl.message('Dark mode', name: 'dark_mode', desc: '', locale: localeName, args: []);
  }

  /// `Dark`
  String get dark_mode_dark {
    return Intl.message('Dark', name: 'dark_mode_dark', desc: '', locale: localeName, args: []);
  }

  /// `Light`
  String get dark_mode_light {
    return Intl.message('Light', name: 'dark_mode_light', desc: '', locale: localeName, args: []);
  }

  /// `System`
  String get dark_mode_system {
    return Intl.message('System', name: 'dark_mode_system', desc: '', locale: localeName, args: []);
  }

  /// `Database`
  String get database {
    return Intl.message('Database', name: 'database', desc: '', locale: localeName, args: []);
  }

  /// `Database is not downloaded, please try again.`
  String get database_not_downloaded_warning {
    return Intl.message(
      'Database is not downloaded, please try again.',
      name: 'database_not_downloaded_warning',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Dataset version`
  String get dataset_version {
    return Intl.message('Dataset version', name: 'dataset_version', desc: '', locale: localeName, args: []);
  }

  /// `Date`
  String get date {
    return Intl.message('Date', name: 'date', desc: '', locale: localeName, args: []);
  }

  /// `Death Chance`
  String get death_chance {
    return Intl.message('Death Chance', name: 'death_chance', desc: '', locale: localeName, args: []);
  }

  /// `Death Effect Rate`
  String get death_effect_rate {
    return Intl.message('Death Effect Rate', name: 'death_effect_rate', desc: '', locale: localeName, args: []);
  }

  /// `Debuff Immune`
  String get debuff_immune {
    return Intl.message('Debuff Immune', name: 'debuff_immune', desc: '', locale: localeName, args: []);
  }

  /// `Debug`
  String get debug {
    return Intl.message('Debug', name: 'debug', desc: '', locale: localeName, args: []);
  }

  /// `Debug FAB`
  String get debug_fab {
    return Intl.message('Debug FAB', name: 'debug_fab', desc: '', locale: localeName, args: []);
  }

  /// `Debug Menu`
  String get debug_menu {
    return Intl.message('Debug Menu', name: 'debug_menu', desc: '', locale: localeName, args: []);
  }

  /// `Def NP Gain Mod`
  String get def_np_gain_mod {
    return Intl.message('Def NP Gain Mod', name: 'def_np_gain_mod', desc: '', locale: localeName, args: []);
  }

  /// `Default Lvs`
  String get default_lvs {
    return Intl.message('Default Lvs', name: 'default_lvs', desc: '', locale: localeName, args: []);
  }

  /// `Default lv setting is used only if "Prefer Player Data" turned off or servant/CE not favorite.`
  String get default_lvs_hint {
    return Intl.message(
      'Default lv setting is used only if "Prefer Player Data" turned off or servant/CE not favorite.',
      name: 'default_lvs_hint',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Defense NP Rate`
  String get defense_np_rate {
    return Intl.message('Defense NP Rate', name: 'defense_np_rate', desc: '', locale: localeName, args: []);
  }

  /// `Delete`
  String get delete {
    return Intl.message('Delete', name: 'delete', desc: '', locale: localeName, args: []);
  }

  /// `Sign in to delete your account`
  String get delete_account_login_required {
    return Intl.message(
      'Sign in to delete your account',
      name: 'delete_account_login_required',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Reason for Deletion`
  String get delete_reason {
    return Intl.message('Reason for Deletion', name: 'delete_reason', desc: '', locale: localeName, args: []);
  }

  /// `Delete Unreleased Cards`
  String get delete_unreleased_card {
    return Intl.message(
      'Delete Unreleased Cards',
      name: 'delete_unreleased_card',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Demands`
  String get demands {
    return Intl.message('Demands', name: 'demands', desc: '', locale: localeName, args: []);
  }

  /// `Desktop only`
  String get desktop_only {
    return Intl.message('Desktop only', name: 'desktop_only', desc: '', locale: localeName, args: []);
  }

  /// `Details`
  String get details {
    return Intl.message('Details', name: 'details', desc: '', locale: localeName, args: []);
  }

  /// `Detective Missions`
  String get detective_mission {
    return Intl.message('Detective Missions', name: 'detective_mission', desc: '', locale: localeName, args: []);
  }

  /// `Detective Rank`
  String get detective_rank {
    return Intl.message('Detective Rank', name: 'detective_rank', desc: '', locale: localeName, args: []);
  }

  /// `Disable`
  String get disable {
    return Intl.message('Disable', name: 'disable', desc: '', locale: localeName, args: []);
  }

  /// `Disable Event Effects`
  String get disable_event_effects {
    return Intl.message('Disable Event Effects', name: 'disable_event_effects', desc: '', locale: localeName, args: []);
  }

  /// `Disabled`
  String get disabled {
    return Intl.message('Disabled', name: 'disabled', desc: '', locale: localeName, args: []);
  }

  /// `Disallow MLB`
  String get disallow_mlb {
    return Intl.message('Disallow MLB', name: 'disallow_mlb', desc: '', locale: localeName, args: []);
  }

  /// `Grid`
  String get display_grid {
    return Intl.message('Grid', name: 'display_grid', desc: '', locale: localeName, args: []);
  }

  /// `List`
  String get display_list {
    return Intl.message('List', name: 'display_list', desc: '', locale: localeName, args: []);
  }

  /// `Display Settings`
  String get display_setting {
    return Intl.message('Display Settings', name: 'display_setting', desc: '', locale: localeName, args: []);
  }

  /// `Show Multi-Window Button`
  String get display_show_window_fab {
    return Intl.message(
      'Show Multi-Window Button',
      name: 'display_show_window_fab',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `DONE`
  String get done {
    return Intl.message('DONE', name: 'done', desc: '', locale: localeName, args: []);
  }

  /// `Download`
  String get download {
    return Intl.message('Download', name: 'download', desc: '', locale: localeName, args: []);
  }

  /// `Download cancelled.`
  String get download_cancelled {
    return Intl.message('Download cancelled.', name: 'download_cancelled', desc: '', locale: localeName, args: []);
  }

  /// `To ensure compatibility, please upgrade to the latest APP version before updating`
  String get download_latest_gamedata_hint {
    return Intl.message(
      'To ensure compatibility, please upgrade to the latest APP version before updating',
      name: 'download_latest_gamedata_hint',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Download source`
  String get download_source {
    return Intl.message('Download source', name: 'download_source', desc: '', locale: localeName, args: []);
  }

  /// `CN endpoint for China mainland`
  String get download_source_hint {
    return Intl.message(
      'CN endpoint for China mainland',
      name: 'download_source_hint',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Downloaded`
  String get downloaded {
    return Intl.message('Downloaded', name: 'downloaded', desc: '', locale: localeName, args: []);
  }

  /// `Downloading`
  String get downloading {
    return Intl.message('Downloading', name: 'downloading', desc: '', locale: localeName, args: []);
  }

  /// `Drag to sort`
  String get drag_to_sort {
    return Intl.message('Drag to sort', name: 'drag_to_sort', desc: '', locale: localeName, args: []);
  }

  /// `Click + to add items`
  String get drop_calc_empty_hint {
    return Intl.message('Click + to add items', name: 'drop_calc_empty_hint', desc: '', locale: localeName, args: []);
  }

  /// `Min AP`
  String get drop_calc_min_ap {
    return Intl.message('Min AP', name: 'drop_calc_min_ap', desc: '', locale: localeName, args: []);
  }

  /// `Solve`
  String get drop_calc_solve {
    return Intl.message('Solve', name: 'drop_calc_solve', desc: '', locale: localeName, args: []);
  }

  /// `The quest enemies only show a certain version, but the drop data is collected from all versions.`
  String get drop_from_all_hashes_hint {
    return Intl.message(
      'The quest enemies only show a certain version, but the drop data is collected from all versions.',
      name: 'drop_from_all_hashes_hint',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Drop rate`
  String get drop_rate {
    return Intl.message('Drop rate', name: 'drop_rate', desc: '', locale: localeName, args: []);
  }

  /// `There are rare or additional enemies in this quest. Please switch versions to get the correct drop information.`
  String get drops_warning_has_rare_enemy {
    return Intl.message(
      'There are rare or additional enemies in this quest. Please switch versions to get the correct drop information.',
      name: 'drops_warning_has_rare_enemy',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Duplicated Servant`
  String get duplicated_servant {
    return Intl.message('Duplicated Servant', name: 'duplicated_servant', desc: '', locale: localeName, args: []);
  }

  /// `Duplicated`
  String get duplicated_servant_duplicated {
    return Intl.message('Duplicated', name: 'duplicated_servant_duplicated', desc: '', locale: localeName, args: []);
  }

  /// `Primary`
  String get duplicated_servant_primary {
    return Intl.message('Primary', name: 'duplicated_servant_primary', desc: '', locale: localeName, args: []);
  }

  /// `Force Enable Edge-swipe pop gesture`
  String get edge_swipe_pop_gesture {
    return Intl.message(
      'Force Enable Edge-swipe pop gesture',
      name: 'edge_swipe_pop_gesture',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Edit`
  String get edit {
    return Intl.message('Edit', name: 'edit', desc: '', locale: localeName, args: []);
  }

  /// `Effect Scope`
  String get effect_scope {
    return Intl.message('Effect Scope', name: 'effect_scope', desc: '', locale: localeName, args: []);
  }

  /// `Effect Search`
  String get effect_search {
    return Intl.message('Effect Search', name: 'effect_search', desc: '', locale: localeName, args: []);
  }

  /// `Effective condition of Func or Buff. Poison/Curse/Burn also search buffs containing the trait.`
  String get effect_search_trait_hint {
    return Intl.message(
      'Effective condition of Func or Buff. Poison/Curse/Burn also search buffs containing the trait.',
      name: 'effect_search_trait_hint',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Effect Target`
  String get effect_target {
    return Intl.message('Effect Target', name: 'effect_target', desc: '', locale: localeName, args: []);
  }

  /// `Effect Type`
  String get effect_type {
    return Intl.message('Effect Type', name: 'effect_type', desc: '', locale: localeName, args: []);
  }

  /// `Effective Condition`
  String get effective_condition {
    return Intl.message('Effective Condition', name: 'effective_condition', desc: '', locale: localeName, args: []);
  }

  /// `Efficiency`
  String get efficiency {
    return Intl.message('Efficiency', name: 'efficiency', desc: '', locale: localeName, args: []);
  }

  /// `Efficient`
  String get efficiency_type {
    return Intl.message('Efficient', name: 'efficiency_type', desc: '', locale: localeName, args: []);
  }

  /// `20AP Rate`
  String get efficiency_type_ap {
    return Intl.message('20AP Rate', name: 'efficiency_type_ap', desc: '', locale: localeName, args: []);
  }

  /// `Drop Rate`
  String get efficiency_type_drop {
    return Intl.message('Drop Rate', name: 'efficiency_type_drop', desc: '', locale: localeName, args: []);
  }

  /// `Email`
  String get email {
    return Intl.message('Email', name: 'email', desc: '', locale: localeName, args: []);
  }

  /// `Empty`
  String get empty_hint {
    return Intl.message('Empty', name: 'empty_hint', desc: '', locale: localeName, args: []);
  }

  /// `Enable`
  String get enable {
    return Intl.message('Enable', name: 'enable', desc: '', locale: localeName, args: []);
  }

  /// `Enable Split View`
  String get enable_split_view {
    return Intl.message('Enable Split View', name: 'enable_split_view', desc: '', locale: localeName, args: []);
  }

  /// `End Enemy Turn`
  String get end_enemy_turn {
    return Intl.message('End Enemy Turn', name: 'end_enemy_turn', desc: '', locale: localeName, args: []);
  }

  /// `Ended`
  String get ended {
    return Intl.message('Ended', name: 'ended', desc: '', locale: localeName, args: []);
  }

  /// `Enemy`
  String get enemy {
    return Intl.message('Enemy', name: 'enemy', desc: '', locale: localeName, args: []);
  }

  /// `Enemy Count`
  String get enemy_count {
    return Intl.message('Enemy Count', name: 'enemy_count', desc: '', locale: localeName, args: []);
  }

  /// `Trait filter is only used for enemies in Main Story's free quests`
  String get enemy_filter_trait_hint {
    return Intl.message(
      'Trait filter is only used for enemies in Main Story\'s free quests',
      name: 'enemy_filter_trait_hint',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Leader: battle ends if defeated`
  String get enemy_leader_hint {
    return Intl.message(
      'Leader: battle ends if defeated',
      name: 'enemy_leader_hint',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Enemies`
  String get enemy_list {
    return Intl.message('Enemies', name: 'enemy_list', desc: '', locale: localeName, args: []);
  }

  /// `Enemy Master`
  String get enemy_master {
    return Intl.message('Enemy Master', name: 'enemy_master', desc: '', locale: localeName, args: []);
  }

  /// `Non-Servant`
  String get enemy_not_servant {
    return Intl.message('Non-Servant', name: 'enemy_not_servant', desc: '', locale: localeName, args: []);
  }

  /// `Enemy Only`
  String get enemy_only {
    return Intl.message('Enemy Only', name: 'enemy_only', desc: '', locale: localeName, args: []);
  }

  /// `Enemy Only NPs`
  String get enemy_only_nps {
    return Intl.message('Enemy Only NPs', name: 'enemy_only_nps', desc: '', locale: localeName, args: []);
  }

  /// `Summary`
  String get enemy_summary {
    return Intl.message('Summary', name: 'enemy_summary', desc: '', locale: localeName, args: []);
  }

  /// `Enhance`
  String get enhance {
    return Intl.message('Enhance', name: 'enhance', desc: '', locale: localeName, args: []);
  }

  /// `The following items will be consumed for enhancement`
  String get enhance_warning {
    return Intl.message(
      'The following items will be consumed for enhancement',
      name: 'enhance_warning',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Error`
  String get error {
    return Intl.message('Error', name: 'error', desc: '', locale: localeName, args: []);
  }

  /// `No data found`
  String get error_no_data_found {
    return Intl.message('No data found', name: 'error_no_data_found', desc: '', locale: localeName, args: []);
  }

  /// `No internet`
  String get error_no_internet {
    return Intl.message('No internet', name: 'error_no_internet', desc: '', locale: localeName, args: []);
  }

  /// `Required app version: ≥ {version} (Current: {curVer})`
  String error_required_app_version(Object version, Object curVer) {
    return Intl.message(
      'Required app version: ≥ $version (Current: $curVer)',
      name: 'error_required_app_version',
      desc: '',
      locale: localeName,
      args: [version, curVer],
    );
  }

  /// `Error! Click to go back >_<`
  String get error_widget_hint {
    return Intl.message(
      'Error! Click to go back >_<',
      name: 'error_widget_hint',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Event`
  String get event {
    return Intl.message('Event', name: 'event', desc: '', locale: localeName, args: []);
  }

  /// `AP Cost 1/2`
  String get event_ap_cost_half {
    return Intl.message('AP Cost 1/2', name: 'event_ap_cost_half', desc: '', locale: localeName, args: []);
  }

  /// `Bonus`
  String get event_bonus {
    return Intl.message('Bonus', name: 'event_bonus', desc: '', locale: localeName, args: []);
  }

  /// `Bulletin`
  String get event_bulletin_board {
    return Intl.message('Bulletin', name: 'event_bulletin_board', desc: '', locale: localeName, args: []);
  }

  /// `Campaign`
  String get event_campaign {
    return Intl.message('Campaign', name: 'event_campaign', desc: '', locale: localeName, args: []);
  }

  /// `Collect Items`
  String get event_collect_items {
    return Intl.message('Collect Items', name: 'event_collect_items', desc: '', locale: localeName, args: []);
  }

  /// `Cooltime`
  String get event_cooltime {
    return Intl.message('Cooltime', name: 'event_cooltime', desc: '', locale: localeName, args: []);
  }

  /// `Custom Getatable Items`
  String get event_custom_item {
    return Intl.message('Custom Getatable Items', name: 'event_custom_item', desc: '', locale: localeName, args: []);
  }

  /// `Click + button to customize items`
  String get event_custom_item_empty_hint {
    return Intl.message(
      'Click + button to customize items',
      name: 'event_custom_item_empty_hint',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Digging`
  String get event_digging {
    return Intl.message('Digging', name: 'event_digging', desc: '', locale: localeName, args: []);
  }

  /// `Fortification`
  String get event_fortification {
    return Intl.message('Fortification', name: 'event_fortification', desc: '', locale: localeName, args: []);
  }

  /// `Event FQ`
  String get event_free_quest {
    return Intl.message('Event FQ', name: 'event_free_quest', desc: '', locale: localeName, args: []);
  }

  /// `Heel`
  String get event_heel {
    return Intl.message('Heel', name: 'event_heel', desc: '', locale: localeName, args: []);
  }

  /// `Extra Items`
  String get event_item_extra {
    return Intl.message('Extra Items', name: 'event_item_extra', desc: '', locale: localeName, args: []);
  }

  /// `Extra Fixed Items`
  String get event_item_fixed_extra {
    return Intl.message('Extra Fixed Items', name: 'event_item_fixed_extra', desc: '', locale: localeName, args: []);
  }

  /// `Lottery`
  String get event_lottery {
    return Intl.message('Lottery', name: 'event_lottery', desc: '', locale: localeName, args: []);
  }

  /// `Max {n} lottery`
  String event_lottery_limit_hint(Object n) {
    return Intl.message('Max $n lottery', name: 'event_lottery_limit_hint', desc: '', locale: localeName, args: [n]);
  }

  /// `Limited lottery`
  String get event_lottery_limited {
    return Intl.message('Limited lottery', name: 'event_lottery_limited', desc: '', locale: localeName, args: []);
  }

  /// `Lottery`
  String get event_lottery_unit {
    return Intl.message('Lottery', name: 'event_lottery_unit', desc: '', locale: localeName, args: []);
  }

  /// `Unlimited lottery`
  String get event_lottery_unlimited {
    return Intl.message('Unlimited lottery', name: 'event_lottery_unlimited', desc: '', locale: localeName, args: []);
  }

  /// `Murals`
  String get event_mural {
    return Intl.message('Murals', name: 'event_mural', desc: '', locale: localeName, args: []);
  }

  /// `This trait may be event only servant/enemy trait or field trait.\n Normal servant or enemy may not have this trait, they may have another trait with similar name but different ID.\nSome traits are not translated with 'Servant', but they may be servant only trait in event.`
  String get event_only_trait_hint {
    return Intl.message(
      'This trait may be event only servant/enemy trait or field trait.\n Normal servant or enemy may not have this trait, they may have another trait with similar name but different ID.\nSome traits are not translated with \'Servant\', but they may be servant only trait in event.',
      name: 'event_only_trait_hint',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Event Point`
  String get event_point {
    return Intl.message('Event Point', name: 'event_point', desc: '', locale: localeName, args: []);
  }

  /// `Points`
  String get event_point_reward {
    return Intl.message('Points', name: 'event_point_reward', desc: '', locale: localeName, args: []);
  }

  /// `Event Quests`
  String get event_quest {
    return Intl.message('Event Quests', name: 'event_quest', desc: '', locale: localeName, args: []);
  }

  /// `Raid`
  String get event_raid {
    return Intl.message('Raid', name: 'event_raid', desc: '', locale: localeName, args: []);
  }

  /// `Recipe`
  String get event_recipe {
    return Intl.message('Recipe', name: 'event_recipe', desc: '', locale: localeName, args: []);
  }

  /// `Grail to crystal: {n}/{total}`
  String event_rerun_replace_grail(Object n, Object total) {
    return Intl.message(
      'Grail to crystal: $n/$total',
      name: 'event_rerun_replace_grail',
      desc: '',
      locale: localeName,
      args: [n, total],
    );
  }

  /// `Event Shop`
  String get event_shop {
    return Intl.message('Event Shop', name: 'event_shop', desc: '', locale: localeName, args: []);
  }

  /// `Event Skill`
  String get event_skill {
    return Intl.message('Event Skill', name: 'event_skill', desc: '', locale: localeName, args: []);
  }

  /// `Event Servant`
  String get event_svt {
    return Intl.message('Event Servant', name: 'event_svt', desc: '', locale: localeName, args: []);
  }

  /// `Withdrawn`
  String get event_svt_withdraw {
    return Intl.message('Withdrawn', name: 'event_svt_withdraw', desc: '', locale: localeName, args: []);
  }

  /// `Tower`
  String get event_tower {
    return Intl.message('Tower', name: 'event_tower', desc: '', locale: localeName, args: []);
  }

  /// `Trade`
  String get event_trade {
    return Intl.message('Trade', name: 'event_trade', desc: '', locale: localeName, args: []);
  }

  /// `Treasure Box`
  String get event_treasure_box {
    return Intl.message('Treasure Box', name: 'event_treasure_box', desc: '', locale: localeName, args: []);
  }

  /// `Exchange Count`
  String get exchange_count {
    return Intl.message('Exchange Count', name: 'exchange_count', desc: '', locale: localeName, args: []);
  }

  /// `Exchange Ticket`
  String get exchange_ticket {
    return Intl.message('Exchange Ticket', name: 'exchange_ticket', desc: '', locale: localeName, args: []);
  }

  /// `Ticket`
  String get exchange_ticket_short {
    return Intl.message('Ticket', name: 'exchange_ticket_short', desc: '', locale: localeName, args: []);
  }

  /// `Exclude`
  String get exclude {
    return Intl.message('Exclude', name: 'exclude', desc: '', locale: localeName, args: []);
  }

  /// `Exclude Random Enemy Quests`
  String get exclude_random_enemy_quests {
    return Intl.message(
      'Exclude Random Enemy Quests',
      name: 'exclude_random_enemy_quests',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Levels`
  String get exp_card_plan_lv {
    return Intl.message('Levels', name: 'exp_card_plan_lv', desc: '', locale: localeName, args: []);
  }

  /// `NEXT`
  String get exp_card_plan_next {
    return Intl.message('NEXT', name: 'exp_card_plan_next', desc: '', locale: localeName, args: []);
  }

  /// `Same Class`
  String get exp_card_same_class {
    return Intl.message('Same Class', name: 'exp_card_same_class', desc: '', locale: localeName, args: []);
  }

  /// `Exp Card`
  String get exp_card_title {
    return Intl.message('Exp Card', name: 'exp_card_title', desc: '', locale: localeName, args: []);
  }

  /// `Expand`
  String get expand {
    return Intl.message('Expand', name: 'expand', desc: '', locale: localeName, args: []);
  }

  /// `Extra Passive`
  String get extra_passive {
    return Intl.message('Extra Passive', name: 'extra_passive', desc: '', locale: localeName, args: []);
  }

  /// `Failed`
  String get failed {
    return Intl.message('Failed', name: 'failed', desc: '', locale: localeName, args: []);
  }

  /// `FAQ`
  String get faq {
    return Intl.message('FAQ', name: 'faq', desc: '', locale: localeName, args: []);
  }

  /// `Favorite`
  String get favorite {
    return Intl.message('Favorite', name: 'favorite', desc: '', locale: localeName, args: []);
  }

  /// `Favorite All Shown Svts`
  String get favorite_all_shown_svt {
    return Intl.message(
      'Favorite All Shown Svts',
      name: 'favorite_all_shown_svt',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Favorite Teams`
  String get favorite_teams {
    return Intl.message('Favorite Teams', name: 'favorite_teams', desc: '', locale: localeName, args: []);
  }

  /// `e.g. screenshots, files.`
  String get feedback_add_attachments {
    return Intl.message(
      'e.g. screenshots, files.',
      name: 'feedback_add_attachments',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Contact information`
  String get feedback_contact {
    return Intl.message('Contact information', name: 'feedback_contact', desc: '', locale: localeName, args: []);
  }

  /// `Feedback or Suggestion`
  String get feedback_content_hint {
    return Intl.message(
      'Feedback or Suggestion',
      name: 'feedback_content_hint',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Feedback form is not empty, still exit?`
  String get feedback_form_alert {
    return Intl.message(
      'Feedback form is not empty, still exit?',
      name: 'feedback_form_alert',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Please check <**FAQ**> first before sending feedback. And following detail is desired:\n- How to reproduce, expected behaviour\n- App/dataset version, device system and version\n- Attach screenshots and logs\n- provide contact info (Email) if want reply\n- DO NOT ask me why cannot find servant xxx`
  String get feedback_info {
    return Intl.message(
      'Please check <**FAQ**> first before sending feedback. And following detail is desired:\n- How to reproduce, expected behaviour\n- App/dataset version, device system and version\n- Attach screenshots and logs\n- provide contact info (Email) if want reply\n- DO NOT ask me why cannot find servant xxx',
      name: 'feedback_info',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Password recovery support — please include your username and device UUID in your message`
  String get feedback_password_recovery_banner {
    return Intl.message(
      'Password recovery support — please include your username and device UUID in your message',
      name: 'feedback_password_recovery_banner',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Send`
  String get feedback_send {
    return Intl.message('Send', name: 'feedback_send', desc: '', locale: localeName, args: []);
  }

  /// `Subject`
  String get feedback_subject {
    return Intl.message('Subject', name: 'feedback_subject', desc: '', locale: localeName, args: []);
  }

  /// `Body`
  String get ffo_body {
    return Intl.message('Body', name: 'ffo_body', desc: '', locale: localeName, args: []);
  }

  /// `Crop`
  String get ffo_crop {
    return Intl.message('Crop', name: 'ffo_crop', desc: '', locale: localeName, args: []);
  }

  /// `Head`
  String get ffo_head {
    return Intl.message('Head', name: 'ffo_head', desc: '', locale: localeName, args: []);
  }

  /// `Please download or import FFO data first↗`
  String get ffo_missing_data_hint {
    return Intl.message(
      'Please download or import FFO data first↗',
      name: 'ffo_missing_data_hint',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Same Servant`
  String get ffo_same_svt {
    return Intl.message('Same Servant', name: 'ffo_same_svt', desc: '', locale: localeName, args: []);
  }

  /// `Domus Aurea`
  String get fgo_domus_aurea {
    return Intl.message('Domus Aurea', name: 'fgo_domus_aurea', desc: '', locale: localeName, args: []);
  }

  /// `Field AI`
  String get field_ai {
    return Intl.message('Field AI', name: 'field_ai', desc: '', locale: localeName, args: []);
  }

  /// `File {filename} not found or mismatched hash: {hash} - {localHash}`
  String file_not_found_or_mismatched_hash(Object filename, Object hash, Object localHash) {
    return Intl.message(
      'File $filename not found or mismatched hash: $hash - $localHash',
      name: 'file_not_found_or_mismatched_hash',
      desc: '',
      locale: localeName,
      args: [filename, hash, localHash],
    );
  }

  /// `filename`
  String get filename {
    return Intl.message('filename', name: 'filename', desc: '', locale: localeName, args: []);
  }

  /// `Filter`
  String get filter {
    return Intl.message('Filter', name: 'filter', desc: '', locale: localeName, args: []);
  }

  /// `Type`
  String get filter_atk_hp_type {
    return Intl.message('Type', name: 'filter_atk_hp_type', desc: '', locale: localeName, args: []);
  }

  /// `Category`
  String get filter_category {
    return Intl.message('Category', name: 'filter_category', desc: '', locale: localeName, args: []);
  }

  /// `Match All`
  String get filter_match_all {
    return Intl.message('Match All', name: 'filter_match_all', desc: '', locale: localeName, args: []);
  }

  /// `Obtains`
  String get filter_obtain {
    return Intl.message('Obtains', name: 'filter_obtain', desc: '', locale: localeName, args: []);
  }

  /// `Per-Servant Bond Bonus Cap`
  String get filter_per_servant_bond_bonus_cap {
    return Intl.message(
      'Per-Servant Bond Bonus Cap',
      name: 'filter_per_servant_bond_bonus_cap',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Plan Not Reach`
  String get filter_plan_not_reached {
    return Intl.message('Plan Not Reach', name: 'filter_plan_not_reached', desc: '', locale: localeName, args: []);
  }

  /// `Revert`
  String get filter_revert {
    return Intl.message('Revert', name: 'filter_revert', desc: '', locale: localeName, args: []);
  }

  /// `Display`
  String get filter_shown_type {
    return Intl.message('Display', name: 'filter_shown_type', desc: '', locale: localeName, args: []);
  }

  /// `Sort`
  String get filter_sort {
    return Intl.message('Sort', name: 'filter_sort', desc: '', locale: localeName, args: []);
  }

  /// `No`
  String get filter_sort_number {
    return Intl.message('No', name: 'filter_sort_number', desc: '', locale: localeName, args: []);
  }

  /// `Rarity`
  String get filter_sort_rarity {
    return Intl.message('Rarity', name: 'filter_sort_rarity', desc: '', locale: localeName, args: []);
  }

  /// `Fixed OC`
  String get fixed_oc {
    return Intl.message('Fixed OC', name: 'fixed_oc', desc: '', locale: localeName, args: []);
  }

  /// `Force Enable NP S.E.`
  String get force_enable_np_se {
    return Intl.message('Force Enable NP S.E.', name: 'force_enable_np_se', desc: '', locale: localeName, args: []);
  }

  /// `Force Death`
  String get force_instant_death {
    return Intl.message('Force Death', name: 'force_instant_death', desc: '', locale: localeName, args: []);
  }

  /// `Forced Update`
  String get forced_update {
    return Intl.message('Forced Update', name: 'forced_update', desc: '', locale: localeName, args: []);
  }

  /// `Read FAQ first about password reset then contact developer with required info.`
  String get forgot_password_hint {
    return Intl.message(
      'Read FAQ first about password reset then contact developer with required info.',
      name: 'forgot_password_hint',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Fou`
  String get foukun {
    return Intl.message('Fou', name: 'foukun', desc: '', locale: localeName, args: []);
  }

  /// `Decimals are not displayed, there may be an error of ±1 between the displayed result and the calculated result`
  String get fq_plan_decimal_hint {
    return Intl.message(
      'Decimals are not displayed, there may be an error of ±1 between the displayed result and the calculated result',
      name: 'fq_plan_decimal_hint',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Free Exchange Servant`
  String get free_exchange_svt {
    return Intl.message('Free Exchange Servant', name: 'free_exchange_svt', desc: '', locale: localeName, args: []);
  }

  /// `Latest(JP)`
  String get free_progress_newest {
    return Intl.message('Latest(JP)', name: 'free_progress_newest', desc: '', locale: localeName, args: []);
  }

  /// `Free Quest`
  String get free_quest {
    return Intl.message('Free Quest', name: 'free_quest', desc: '', locale: localeName, args: []);
  }

  /// `Free Quest`
  String get free_quest_calculator {
    return Intl.message('Free Quest', name: 'free_quest_calculator', desc: '', locale: localeName, args: []);
  }

  /// `Free Quest`
  String get free_quest_calculator_short {
    return Intl.message('Free Quest', name: 'free_quest_calculator_short', desc: '', locale: localeName, args: []);
  }

  /// `Gacha`
  String get gacha {
    return Intl.message('Gacha', name: 'gacha', desc: '', locale: localeName, args: []);
  }

  /// `Prob.`
  String get gacha_draw_rate {
    return Intl.message('Prob.', name: 'gacha_draw_rate', desc: '', locale: localeName, args: []);
  }

  /// `Banner image may be overridden by`
  String get gacha_image_overridden_hint {
    return Intl.message(
      'Banner image may be overridden by',
      name: 'gacha_image_overridden_hint',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Gacha Prob Calc`
  String get gacha_prob_calc {
    return Intl.message('Gacha Prob Calc', name: 'gacha_prob_calc', desc: '', locale: localeName, args: []);
  }

  /// `{rarity}☆ CE Pick Up`
  String gacha_prob_ce_pickup(Object rarity) {
    return Intl.message(
      '$rarity☆ CE Pick Up',
      name: 'gacha_prob_ce_pickup',
      desc: '',
      locale: localeName,
      args: [rarity],
    );
  }

  /// `Custom Rate`
  String get gacha_prob_custom_rate {
    return Intl.message('Custom Rate', name: 'gacha_prob_custom_rate', desc: '', locale: localeName, args: []);
  }

  /// `If the value is too large or too small, the calculation result is inaccurate due to the double precision problem.`
  String get gacha_prob_precision_hint {
    return Intl.message(
      'If the value is too large or too small, the calculation result is inaccurate due to the double precision problem.',
      name: 'gacha_prob_precision_hint',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `{rarity}☆ SVT Pick Up`
  String gacha_prob_svt_pickup(Object rarity) {
    return Intl.message(
      '$rarity☆ SVT Pick Up',
      name: 'gacha_prob_svt_pickup',
      desc: '',
      locale: localeName,
      args: [rarity],
    );
  }

  /// `Both excluded event SR and FP SR.\nOwned: Sum of NP level of servants in Inventory & Second Archive, don't include burned.\nObtain: all historical Gachas and 'PART' of 5/4-Star Servant Present.\nSee link ↓ for details.`
  String get gacha_svt_count_hint {
    return Intl.message(
      'Both excluded event SR and FP SR.\nOwned: Sum of NP level of servants in Inventory & Second Archive, don\'t include burned.\nObtain: all historical Gachas and \'PART\' of 5/4-Star Servant Present.\nSee link ↓ for details.',
      name: 'gacha_svt_count_hint',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Home`
  String get gallery_tab_name {
    return Intl.message('Home', name: 'gallery_tab_name', desc: '', locale: localeName, args: []);
  }

  /// `Game Account`
  String get game_account {
    return Intl.message('Game Account', name: 'game_account', desc: '', locale: localeName, args: []);
  }

  /// `Loading game data failed, please download data again`
  String get game_data_not_found {
    return Intl.message(
      'Loading game data failed, please download data again',
      name: 'game_data_not_found',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Drop`
  String get game_drop {
    return Intl.message('Drop', name: 'game_drop', desc: '', locale: localeName, args: []);
  }

  /// `Experience`
  String get game_experience {
    return Intl.message('Experience', name: 'game_experience', desc: '', locale: localeName, args: []);
  }

  /// `Bond`
  String get game_kizuna {
    return Intl.message('Bond', name: 'game_kizuna', desc: '', locale: localeName, args: []);
  }

  /// `Rewards`
  String get game_rewards {
    return Intl.message('Rewards', name: 'game_rewards', desc: '', locale: localeName, args: []);
  }

  /// `Game Server`
  String get game_server {
    return Intl.message('Game Server', name: 'game_server', desc: '', locale: localeName, args: []);
  }

  /// `Gamedata`
  String get gamedata {
    return Intl.message('Gamedata', name: 'gamedata', desc: '', locale: localeName, args: []);
  }

  /// `Gender`
  String get gender {
    return Intl.message('Gender', name: 'gender', desc: '', locale: localeName, args: []);
  }

  /// `All`
  String get general_all {
    return Intl.message('All', name: 'general_all', desc: '', locale: localeName, args: []);
  }

  /// `Any`
  String get general_any {
    return Intl.message('Any', name: 'general_any', desc: '', locale: localeName, args: []);
  }

  /// `Close`
  String get general_close {
    return Intl.message('Close', name: 'general_close', desc: '', locale: localeName, args: []);
  }

  /// `Custom`
  String get general_custom {
    return Intl.message('Custom', name: 'general_custom', desc: '', locale: localeName, args: []);
  }

  /// `Default`
  String get general_default {
    return Intl.message('Default', name: 'general_default', desc: '', locale: localeName, args: []);
  }

  /// `Export`
  String get general_export {
    return Intl.message('Export', name: 'general_export', desc: '', locale: localeName, args: []);
  }

  /// `Import`
  String get general_import {
    return Intl.message('Import', name: 'general_import', desc: '', locale: localeName, args: []);
  }

  /// `Next`
  String get general_next {
    return Intl.message('Next', name: 'general_next', desc: '', locale: localeName, args: []);
  }

  /// `Others`
  String get general_others {
    return Intl.message('Others', name: 'general_others', desc: '', locale: localeName, args: []);
  }

  /// `Previous`
  String get general_previous {
    return Intl.message('Previous', name: 'general_previous', desc: '', locale: localeName, args: []);
  }

  /// `Special`
  String get general_special {
    return Intl.message('Special', name: 'general_special', desc: '', locale: localeName, args: []);
  }

  /// `Type`
  String get general_type {
    return Intl.message('Type', name: 'general_type', desc: '', locale: localeName, args: []);
  }

  /// `Global Text Selectable`
  String get global_text_selection {
    return Intl.message(
      'Global Text Selectable',
      name: 'global_text_selection',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Invalid input or no valid target found`
  String get glpk_error_no_valid_target {
    return Intl.message(
      'Invalid input or no valid target found',
      name: 'glpk_error_no_valid_target',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Gold`
  String get gold {
    return Intl.message('Gold', name: 'gold', desc: '', locale: localeName, args: []);
  }

  /// `Grail`
  String get grail {
    return Intl.message('Grail', name: 'grail', desc: '', locale: localeName, args: []);
  }

  /// `Palingenesis`
  String get grail_up {
    return Intl.message('Palingenesis', name: 'grail_up', desc: '', locale: localeName, args: []);
  }

  /// `Grand Duel`
  String get grand_board_war {
    return Intl.message('Grand Duel', name: 'grand_board_war', desc: '', locale: localeName, args: []);
  }

  /// `Grand Servant`
  String get grand_servant {
    return Intl.message('Grand Servant', name: 'grand_servant', desc: '', locale: localeName, args: []);
  }

  /// `Growth Curve`
  String get growth_curve {
    return Intl.message('Growth Curve', name: 'growth_curve', desc: '', locale: localeName, args: []);
  }

  /// `Gudako`
  String get guda_female {
    return Intl.message('Gudako', name: 'guda_female', desc: '', locale: localeName, args: []);
  }

  /// `Gudao`
  String get guda_male {
    return Intl.message('Gudao', name: 'guda_male', desc: '', locale: localeName, args: []);
  }

  /// `Possible related {item} "GUESSED" based on time`
  String guessed_on_time_hint(Object item) {
    return Intl.message(
      'Possible related $item "GUESSED" based on time',
      name: 'guessed_on_time_hint',
      desc: '',
      locale: localeName,
      args: [item],
    );
  }

  /// `Help`
  String get help {
    return Intl.message('Help', name: 'help', desc: '', locale: localeName, args: []);
  }

  /// `Hide`
  String get hide {
    return Intl.message('Hide', name: 'hide', desc: '', locale: localeName, args: []);
  }

  /// `Hide Plan Detail`
  String get hide_svt_plan_details {
    return Intl.message('Hide Plan Detail', name: 'hide_svt_plan_details', desc: '', locale: localeName, args: []);
  }

  /// `It is only not displayed on plan tab, but it is actually still included in the material planning and statistics.`
  String get hide_svt_plan_details_hint {
    return Intl.message(
      'It is only not displayed on plan tab, but it is actually still included in the material planning and statistics.',
      name: 'hide_svt_plan_details_hint',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Hide Unreleased Cards`
  String get hide_unreleased_card {
    return Intl.message('Hide Unreleased Cards', name: 'hide_unreleased_card', desc: '', locale: localeName, args: []);
  }

  /// `High DIfficulty Quest`
  String get high_difficulty_quest {
    return Intl.message('High DIfficulty Quest', name: 'high_difficulty_quest', desc: '', locale: localeName, args: []);
  }

  /// `Hint`
  String get hint {
    return Intl.message('Hint', name: 'hint', desc: '', locale: localeName, args: []);
  }

  /// `History`
  String get history {
    return Intl.message('History', name: 'history', desc: '', locale: localeName, args: []);
  }

  /// `Holy Grail Casting`
  String get holy_grail_casting {
    return Intl.message('Holy Grail Casting', name: 'holy_grail_casting', desc: '', locale: localeName, args: []);
  }

  /// `Home Page Icon Size`
  String get home_page_icon_size {
    return Intl.message('Home Page Icon Size', name: 'home_page_icon_size', desc: '', locale: localeName, args: []);
  }

  /// `(JP/NA/CN/TW)Capture the data when logging in`
  String get http_sniff_hint {
    return Intl.message(
      '(JP/NA/CN/TW)Capture the data when logging in',
      name: 'http_sniff_hint',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Https Sniffing`
  String get https_sniff {
    return Intl.message('Https Sniffing', name: 'https_sniff', desc: '', locale: localeName, args: []);
  }

  /// `Hunting Quests`
  String get hunting_quest {
    return Intl.message('Hunting Quests', name: 'hunting_quest', desc: '', locale: localeName, args: []);
  }

  /// `Icons`
  String get icons {
    return Intl.message('Icons', name: 'icons', desc: '', locale: localeName, args: []);
  }

  /// `Ignore`
  String get ignore {
    return Intl.message('Ignore', name: 'ignore', desc: '', locale: localeName, args: []);
  }

  /// `Illustration`
  String get illustration {
    return Intl.message('Illustration', name: 'illustration', desc: '', locale: localeName, args: []);
  }

  /// `Illustrator`
  String get illustrator {
    return Intl.message('Illustrator', name: 'illustrator', desc: '', locale: localeName, args: []);
  }

  /// `Image`
  String get image {
    return Intl.message('Image', name: 'image', desc: '', locale: localeName, args: []);
  }

  /// `Enhance - Skill`
  String get import_active_skill_hint {
    return Intl.message('Enhance - Skill', name: 'import_active_skill_hint', desc: '', locale: localeName, args: []);
  }

  /// `Active Skill Screenshots`
  String get import_active_skill_screenshots {
    return Intl.message(
      'Active Skill Screenshots',
      name: 'import_active_skill_screenshots',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Enhance - Append Skill`
  String get import_append_skill_hint {
    return Intl.message(
      'Enhance - Append Skill',
      name: 'import_append_skill_hint',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Append Skill Screenshots`
  String get import_append_skill_screenshots {
    return Intl.message(
      'Append Skill Screenshots',
      name: 'import_append_skill_screenshots',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Account File`
  String get import_auth_file {
    return Intl.message('Account File', name: 'import_auth_file', desc: '', locale: localeName, args: []);
  }

  /// `Import Backup`
  String get import_backup {
    return Intl.message('Import Backup', name: 'import_backup', desc: '', locale: localeName, args: []);
  }

  /// `All servants`
  String get import_csv_export_all {
    return Intl.message('All servants', name: 'import_csv_export_all', desc: '', locale: localeName, args: []);
  }

  /// `Empty template`
  String get import_csv_export_empty {
    return Intl.message('Empty template', name: 'import_csv_export_empty', desc: '', locale: localeName, args: []);
  }

  /// `Only favorite servants`
  String get import_csv_export_favorite {
    return Intl.message(
      'Only favorite servants',
      name: 'import_csv_export_favorite',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Export Template`
  String get import_csv_export_template {
    return Intl.message('Export Template', name: 'import_csv_export_template', desc: '', locale: localeName, args: []);
  }

  /// `Load CSV`
  String get import_csv_load_csv {
    return Intl.message('Load CSV', name: 'import_csv_load_csv', desc: '', locale: localeName, args: []);
  }

  /// `CSV Template`
  String get import_csv_title {
    return Intl.message('CSV Template', name: 'import_csv_title', desc: '', locale: localeName, args: []);
  }

  /// `Import`
  String get import_data {
    return Intl.message('Import', name: 'import_data', desc: '', locale: localeName, args: []);
  }

  /// `Import failed. Error:\n{error}`
  String import_data_error(Object error) {
    return Intl.message(
      'Import failed. Error:\n$error',
      name: 'import_data_error',
      desc: '',
      locale: localeName,
      args: [error],
    );
  }

  /// `Import data successfully`
  String get import_data_success {
    return Intl.message(
      'Import data successfully',
      name: 'import_data_success',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `From Clipboard`
  String get import_from_clipboard {
    return Intl.message('From Clipboard', name: 'import_from_clipboard', desc: '', locale: localeName, args: []);
  }

  /// `From File`
  String get import_from_file {
    return Intl.message('From File', name: 'import_from_file', desc: '', locale: localeName, args: []);
  }

  /// `Duplicated`
  String get import_http_body_duplicated {
    return Intl.message('Duplicated', name: 'import_http_body_duplicated', desc: '', locale: localeName, args: []);
  }

  /// `Locked Only`
  String get import_http_body_locked {
    return Intl.message('Locked Only', name: 'import_http_body_locked', desc: '', locale: localeName, args: []);
  }

  /// `Import Image`
  String get import_image {
    return Intl.message('Import Image', name: 'import_image', desc: '', locale: localeName, args: []);
  }

  /// `My Room - Item List`
  String get import_item_hint {
    return Intl.message('My Room - Item List', name: 'import_item_hint', desc: '', locale: localeName, args: []);
  }

  /// `Items Screenshots`
  String get import_item_screenshots {
    return Intl.message('Items Screenshots', name: 'import_item_screenshots', desc: '', locale: localeName, args: []);
  }

  /// `Import Screenshots`
  String get import_screenshot {
    return Intl.message('Import Screenshots', name: 'import_screenshot', desc: '', locale: localeName, args: []);
  }

  /// `Only update recognized results`
  String get import_screenshot_hint {
    return Intl.message(
      'Only update recognized results',
      name: 'import_screenshot_hint',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Update Items`
  String get import_screenshot_update_items {
    return Intl.message('Update Items', name: 'import_screenshot_update_items', desc: '', locale: localeName, args: []);
  }

  /// `Import Source File`
  String get import_source_file {
    return Intl.message('Import Source File', name: 'import_source_file', desc: '', locale: localeName, args: []);
  }

  /// `More import methods`
  String get import_userdata_more {
    return Intl.message('More import methods', name: 'import_userdata_more', desc: '', locale: localeName, args: []);
  }

  /// `Include`
  String get include {
    return Intl.message('Include', name: 'include', desc: '', locale: localeName, args: []);
  }

  /// `Agility`
  String get info_agility {
    return Intl.message('Agility', name: 'info_agility', desc: '', locale: localeName, args: []);
  }

  /// `Bond Points`
  String get info_bond_points {
    return Intl.message('Bond Points', name: 'info_bond_points', desc: '', locale: localeName, args: []);
  }

  /// `Point`
  String get info_bond_points_single {
    return Intl.message('Point', name: 'info_bond_points_single', desc: '', locale: localeName, args: []);
  }

  /// `Sum`
  String get info_bond_points_sum {
    return Intl.message('Sum', name: 'info_bond_points_sum', desc: '', locale: localeName, args: []);
  }

  /// `Cards`
  String get info_cards {
    return Intl.message('Cards', name: 'info_cards', desc: '', locale: localeName, args: []);
  }

  /// `Charge`
  String get info_charge {
    return Intl.message('Charge', name: 'info_charge', desc: '', locale: localeName, args: []);
  }

  /// `Critical Rate`
  String get info_critical_rate {
    return Intl.message('Critical Rate', name: 'info_critical_rate', desc: '', locale: localeName, args: []);
  }

  /// `Voice Actor`
  String get info_cv {
    return Intl.message('Voice Actor', name: 'info_cv', desc: '', locale: localeName, args: []);
  }

  /// `Death Rate`
  String get info_death_rate {
    return Intl.message('Death Rate', name: 'info_death_rate', desc: '', locale: localeName, args: []);
  }

  /// `Endurance`
  String get info_endurance {
    return Intl.message('Endurance', name: 'info_endurance', desc: '', locale: localeName, args: []);
  }

  /// `Luck`
  String get info_luck {
    return Intl.message('Luck', name: 'info_luck', desc: '', locale: localeName, args: []);
  }

  /// `Mana`
  String get info_mana {
    return Intl.message('Mana', name: 'info_mana', desc: '', locale: localeName, args: []);
  }

  /// `NP`
  String get info_np {
    return Intl.message('NP', name: 'info_np', desc: '', locale: localeName, args: []);
  }

  /// `NP Rate`
  String get info_np_rate {
    return Intl.message('NP Rate', name: 'info_np_rate', desc: '', locale: localeName, args: []);
  }

  /// `Star Rate`
  String get info_star_rate {
    return Intl.message('Star Rate', name: 'info_star_rate', desc: '', locale: localeName, args: []);
  }

  /// `Strength`
  String get info_strength {
    return Intl.message('Strength', name: 'info_strength', desc: '', locale: localeName, args: []);
  }

  /// `Value`
  String get info_value {
    return Intl.message('Value', name: 'info_value', desc: '', locale: localeName, args: []);
  }

  /// `Invalid inputs`
  String get input_invalid_hint {
    return Intl.message('Invalid inputs', name: 'input_invalid_hint', desc: '', locale: localeName, args: []);
  }

  /// `Install`
  String get install {
    return Intl.message('Install', name: 'install', desc: '', locale: localeName, args: []);
  }

  /// `Failed to start the system installer.`
  String get install_failed_to_start {
    return Intl.message(
      'Failed to start the system installer.',
      name: 'install_failed_to_start',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Direct installs need a one-time system permission. Tap "Open Settings" and allow "Allow from this source" for Chaldea, then return and tap Install again.`
  String get install_permission_hint {
    return Intl.message(
      'Direct installs need a one-time system permission. Tap "Open Settings" and allow "Allow from this source" for Chaldea, then return and tap Install again.',
      name: 'install_permission_hint',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Instant Death`
  String get instant_death {
    return Intl.message('Instant Death', name: 'instant_death', desc: '', locale: localeName, args: []);
  }

  /// `Instant Death Params`
  String get instant_death_params {
    return Intl.message('Instant Death Params', name: 'instant_death_params', desc: '', locale: localeName, args: []);
  }

  /// `Interlude`
  String get interlude {
    return Intl.message('Interlude', name: 'interlude', desc: '', locale: localeName, args: []);
  }

  /// `Interlude & Rank Up`
  String get interlude_and_rankup {
    return Intl.message('Interlude & Rank Up', name: 'interlude_and_rankup', desc: '', locale: localeName, args: []);
  }

  /// `Invalid input.`
  String get invalid_input {
    return Intl.message('Invalid input.', name: 'invalid_input', desc: '', locale: localeName, args: []);
  }

  /// `Invalid startup path!`
  String get invalid_startup_path {
    return Intl.message('Invalid startup path!', name: 'invalid_startup_path', desc: '', locale: localeName, args: []);
  }

  /// `Please, extract zip to non-system path then start the app. "C:\", "C:\Program Files" are not allowed.`
  String get invalid_startup_path_info {
    return Intl.message(
      'Please, extract zip to non-system path then start the app. "C:\\", "C:\\Program Files" are not allowed.',
      name: 'invalid_startup_path_info',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `"Files" app/On My iPhone/Chaldea`
  String get ios_app_path {
    return Intl.message(
      '"Files" app/On My iPhone/Chaldea',
      name: 'ios_app_path',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Authorized`
  String get ios_att_authorized {
    return Intl.message('Authorized', name: 'ios_att_authorized', desc: '', locale: localeName, args: []);
  }

  /// `Denied — non-personalized ads only`
  String get ios_att_denied {
    return Intl.message(
      'Denied — non-personalized ads only',
      name: 'ios_att_denied',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Not yet requested`
  String get ios_att_not_requested {
    return Intl.message('Not yet requested', name: 'ios_att_not_requested', desc: '', locale: localeName, args: []);
  }

  /// `Allow`
  String get ios_att_request {
    return Intl.message('Allow', name: 'ios_att_request', desc: '', locale: localeName, args: []);
  }

  /// `Ad Tracking (iOS)`
  String get ios_att_title {
    return Intl.message('Ad Tracking (iOS)', name: 'ios_att_title', desc: '', locale: localeName, args: []);
  }

  /// `Item`
  String get item {
    return Intl.message('Item', name: 'item', desc: '', locale: localeName, args: []);
  }

  /// `{name} already exist`
  String item_already_exist_hint(Object name) {
    return Intl.message(
      '$name already exist',
      name: 'item_already_exist_hint',
      desc: '',
      locale: localeName,
      args: [name],
    );
  }

  /// `Apple`
  String get item_apple {
    return Intl.message('Apple', name: 'item_apple', desc: '', locale: localeName, args: []);
  }

  /// `Bronze Items`
  String get item_category_bronze {
    return Intl.message('Bronze Items', name: 'item_category_bronze', desc: '', locale: localeName, args: []);
  }

  /// `Gem`
  String get item_category_gem {
    return Intl.message('Gem', name: 'item_category_gem', desc: '', locale: localeName, args: []);
  }

  /// `Gold Items`
  String get item_category_gold {
    return Intl.message('Gold Items', name: 'item_category_gold', desc: '', locale: localeName, args: []);
  }

  /// `Magic Gem`
  String get item_category_magic_gem {
    return Intl.message('Magic Gem', name: 'item_category_magic_gem', desc: '', locale: localeName, args: []);
  }

  /// `Monument`
  String get item_category_monument {
    return Intl.message('Monument', name: 'item_category_monument', desc: '', locale: localeName, args: []);
  }

  /// `Piece`
  String get item_category_piece {
    return Intl.message('Piece', name: 'item_category_piece', desc: '', locale: localeName, args: []);
  }

  /// `Secret Gem`
  String get item_category_secret_gem {
    return Intl.message('Secret Gem', name: 'item_category_secret_gem', desc: '', locale: localeName, args: []);
  }

  /// `Silver Items`
  String get item_category_silver {
    return Intl.message('Silver Items', name: 'item_category_silver', desc: '', locale: localeName, args: []);
  }

  /// `Special Items`
  String get item_category_special {
    return Intl.message('Special Items', name: 'item_category_special', desc: '', locale: localeName, args: []);
  }

  /// `Edit Owned Amount`
  String get item_edit_owned_amount {
    return Intl.message('Edit Owned Amount', name: 'item_edit_owned_amount', desc: '', locale: localeName, args: []);
  }

  /// `Item Eff`
  String get item_eff {
    return Intl.message('Item Eff', name: 'item_eff', desc: '', locale: localeName, args: []);
  }

  /// `Before planning, you can set exceeded num for items(Only used for free quest planning)`
  String get item_exceed_hint {
    return Intl.message(
      'Before planning, you can set exceeded num for items(Only used for free quest planning)',
      name: 'item_exceed_hint',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Grail → Lore`
  String get item_grail2crystal {
    return Intl.message('Grail → Lore', name: 'item_grail2crystal', desc: '', locale: localeName, args: []);
  }

  /// `Left`
  String get item_left {
    return Intl.message('Left', name: 'item_left', desc: '', locale: localeName, args: []);
  }

  /// `No Free Quests`
  String get item_no_free_quests {
    return Intl.message('No Free Quests', name: 'item_no_free_quests', desc: '', locale: localeName, args: []);
  }

  /// `Pay attention to the quest runs, few runs may result inaccurate stats!`
  String get item_obtain_event_free_hint {
    return Intl.message(
      'Pay attention to the quest runs, few runs may result inaccurate stats!',
      name: 'item_obtain_event_free_hint',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Only show lacked`
  String get item_only_show_lack {
    return Intl.message('Only show lacked', name: 'item_only_show_lack', desc: '', locale: localeName, args: []);
  }

  /// `Owned`
  String get item_own {
    return Intl.message('Owned', name: 'item_own', desc: '', locale: localeName, args: []);
  }

  /// `Item Screenshot`
  String get item_screenshot {
    return Intl.message('Item Screenshot', name: 'item_screenshot', desc: '', locale: localeName, args: []);
  }

  /// `Include Owned`
  String get item_stat_include_owned {
    return Intl.message('Include Owned', name: 'item_stat_include_owned', desc: '', locale: localeName, args: []);
  }

  /// `Subtract Event`
  String get item_stat_sub_event {
    return Intl.message('Subtract Event', name: 'item_stat_sub_event', desc: '', locale: localeName, args: []);
  }

  /// `Subtract Owned`
  String get item_stat_sub_owned {
    return Intl.message('Subtract Owned', name: 'item_stat_sub_owned', desc: '', locale: localeName, args: []);
  }

  /// `Join Beta Program`
  String get join_beta {
    return Intl.message('Join Beta Program', name: 'join_beta', desc: '', locale: localeName, args: []);
  }

  /// `Jump to {site}`
  String jump_to(Object site) {
    return Intl.message('Jump to $site', name: 'jump_to', desc: '', locale: localeName, args: [site]);
  }

  /// `Warning that this quest contains multiple enemy configurations, when searching shared teams or simulating check the corresponding version:\nClick Details - Select Version - Click the Calculate Button`
  String get laplace_enemy_multi_ver_hint {
    return Intl.message(
      'Warning that this quest contains multiple enemy configurations, when searching shared teams or simulating check the corresponding version:\nClick Details - Select Version - Click the Calculate Button',
      name: 'laplace_enemy_multi_ver_hint',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `My Teams`
  String get laplace_my_teams {
    return Intl.message('My Teams', name: 'laplace_my_teams', desc: '', locale: localeName, args: []);
  }

  /// `This quest may have complex mechanism or AI, which may not be simulated accurately. Please make sure you understand how enemy AI/field AI work before simulating and manually triggering AI skills.`
  String get laplace_quest_complex_ai_hint {
    return Intl.message(
      'This quest may have complex mechanism or AI, which may not be simulated accurately. Please make sure you understand how enemy AI/field AI work before simulating and manually triggering AI skills.',
      name: 'laplace_quest_complex_ai_hint',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Multi-step NP found, please check MIN/MAX RNG to ensure NP refund is sufficient and able to clear the quest`
  String get laplace_upload_td_multi_dmg_func_hint {
    return Intl.message(
      'Multi-step NP found, please check MIN/MAX RNG to ensure NP refund is sufficient and able to clear the quest',
      name: 'laplace_upload_td_multi_dmg_func_hint',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Level`
  String get level {
    return Intl.message('Level', name: 'level', desc: '', locale: localeName, args: []);
  }

  /// `Limited Event`
  String get limited_event {
    return Intl.message('Limited Event', name: 'limited_event', desc: '', locale: localeName, args: []);
  }

  /// `Limited Time`
  String get limited_time {
    return Intl.message('Limited Time', name: 'limited_time', desc: '', locale: localeName, args: []);
  }

  /// `link`
  String get link {
    return Intl.message('link', name: 'link', desc: '', locale: localeName, args: []);
  }

  /// `{shown} shown (total {total})`
  String list_count_shown_all(Object shown, Object total) {
    return Intl.message(
      '$shown shown (total $total)',
      name: 'list_count_shown_all',
      desc: '',
      locale: localeName,
      args: [shown, total],
    );
  }

  /// `{shown} shown, {ignore} ignored (total {total})`
  String list_count_shown_hidden_all(Object shown, Object ignore, Object total) {
    return Intl.message(
      '$shown shown, $ignore ignored (total $total)',
      name: 'list_count_shown_hidden_all',
      desc: '',
      locale: localeName,
      args: [shown, ignore, total],
    );
  }

  /// `{first, select, true{Already the first one} false{Already the last one} other{No more}}`
  String list_end_hint(Object first) {
    return Intl.select(
      first,
      {'true': 'Already the first one', 'false': 'Already the last one', 'other': 'No more'},
      name: 'list_end_hint',
      desc: '',
      locale: localeName,
      args: [first],
    );
  }

  /// `Load FFO Data`
  String get load_ffo_data {
    return Intl.message('Load FFO Data', name: 'load_ffo_data', desc: '', locale: localeName, args: []);
  }

  /// `Only save quest and team info, no replay data`
  String get local_team_save_no_replay_warning {
    return Intl.message(
      'Only save quest and team info, no replay data',
      name: 'local_team_save_no_replay_warning',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Logic Type`
  String get logic_type {
    return Intl.message('Logic Type', name: 'logic_type', desc: '', locale: localeName, args: []);
  }

  /// `AND`
  String get logic_type_and {
    return Intl.message('AND', name: 'logic_type_and', desc: '', locale: localeName, args: []);
  }

  /// `OR`
  String get logic_type_or {
    return Intl.message('OR', name: 'logic_type_or', desc: '', locale: localeName, args: []);
  }

  /// `Login Auth`
  String get login_auth {
    return Intl.message('Login Auth', name: 'login_auth', desc: '', locale: localeName, args: []);
  }

  /// `Login Bonus`
  String get login_bonus {
    return Intl.message('Login Bonus', name: 'login_bonus', desc: '', locale: localeName, args: []);
  }

  /// `Change Name`
  String get login_change_name {
    return Intl.message('Change Name', name: 'login_change_name', desc: '', locale: localeName, args: []);
  }

  /// `Change Password`
  String get login_change_password {
    return Intl.message('Change Password', name: 'login_change_password', desc: '', locale: localeName, args: []);
  }

  /// `Confirm Password`
  String get login_confirm_password {
    return Intl.message('Confirm Password', name: 'login_confirm_password', desc: '', locale: localeName, args: []);
  }

  /// `Please login first`
  String get login_first_hint {
    return Intl.message('Please login first', name: 'login_first_hint', desc: '', locale: localeName, args: []);
  }

  /// `Forget Password`
  String get login_forget_pwd {
    return Intl.message('Forget Password', name: 'login_forget_pwd', desc: '', locale: localeName, args: []);
  }

  /// `Login`
  String get login_login {
    return Intl.message('Login', name: 'login_login', desc: '', locale: localeName, args: []);
  }

  /// `Logout`
  String get login_logout {
    return Intl.message('Logout', name: 'login_logout', desc: '', locale: localeName, args: []);
  }

  /// `New Name`
  String get login_new_name {
    return Intl.message('New Name', name: 'login_new_name', desc: '', locale: localeName, args: []);
  }

  /// `New Password`
  String get login_new_password {
    return Intl.message('New Password', name: 'login_new_password', desc: '', locale: localeName, args: []);
  }

  /// `Password`
  String get login_password {
    return Intl.message('Password', name: 'login_password', desc: '', locale: localeName, args: []);
  }

  /// `6-18 characters, at least one alphabet`
  String get login_password_error {
    return Intl.message(
      '6-18 characters, at least one alphabet',
      name: 'login_password_error',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Passwords do not match`
  String get login_password_error_confirm_mismatch {
    return Intl.message(
      'Passwords do not match',
      name: 'login_password_error_confirm_mismatch',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Cannot be the same as the old password`
  String get login_password_error_same_as_old {
    return Intl.message(
      'Cannot be the same as the old password',
      name: 'login_password_error_same_as_old',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Signup`
  String get login_signup {
    return Intl.message('Signup', name: 'login_signup', desc: '', locale: localeName, args: []);
  }

  /// `Username`
  String get login_username {
    return Intl.message('Username', name: 'login_username', desc: '', locale: localeName, args: []);
  }

  /// `Can only contain letters and numbers, starting with a letter, no less than 4 digits`
  String get login_username_error {
    return Intl.message(
      'Can only contain letters and numbers, starting with a letter, no less than 4 digits',
      name: 'login_username_error',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Long press to remove`
  String get long_press_to_remove {
    return Intl.message('Long press to remove', name: 'long_press_to_remove', desc: '', locale: localeName, args: []);
  }

  /// `Long press to save`
  String get long_press_to_save_hint {
    return Intl.message('Long press to save', name: 'long_press_to_save_hint', desc: '', locale: localeName, args: []);
  }

  /// `Cost of 1 roll`
  String get lottery_cost_per_roll {
    return Intl.message('Cost of 1 roll', name: 'lottery_cost_per_roll', desc: '', locale: localeName, args: []);
  }

  /// `Lucky Bag`
  String get lucky_bag {
    return Intl.message('Lucky Bag', name: 'lucky_bag', desc: '', locale: localeName, args: []);
  }

  /// `Best`
  String get lucky_bag_best {
    return Intl.message('Best', name: 'lucky_bag_best', desc: '', locale: localeName, args: []);
  }

  /// `Expectation`
  String get lucky_bag_expectation {
    return Intl.message('Expectation', name: 'lucky_bag_expectation', desc: '', locale: localeName, args: []);
  }

  /// `Exp.`
  String get lucky_bag_expectation_short {
    return Intl.message('Exp.', name: 'lucky_bag_expectation_short', desc: '', locale: localeName, args: []);
  }

  /// `Rating`
  String get lucky_bag_rating {
    return Intl.message('Rating', name: 'lucky_bag_rating', desc: '', locale: localeName, args: []);
  }

  /// `Unwanted`
  String get lucky_bag_tooltip_unwanted {
    return Intl.message('Unwanted', name: 'lucky_bag_tooltip_unwanted', desc: '', locale: localeName, args: []);
  }

  /// `Wanted`
  String get lucky_bag_tooltip_wanted {
    return Intl.message('Wanted', name: 'lucky_bag_tooltip_wanted', desc: '', locale: localeName, args: []);
  }

  /// `Worst`
  String get lucky_bag_worst {
    return Intl.message('Worst', name: 'lucky_bag_worst', desc: '', locale: localeName, args: []);
  }

  /// `Main Interlude`
  String get main_interlude {
    return Intl.message('Main Interlude', name: 'main_interlude', desc: '', locale: localeName, args: []);
  }

  /// `Main Quests`
  String get main_quest {
    return Intl.message('Main Quests', name: 'main_quest', desc: '', locale: localeName, args: []);
  }

  /// `Main Record`
  String get main_story {
    return Intl.message('Main Record', name: 'main_story', desc: '', locale: localeName, args: []);
  }

  /// `Chapter`
  String get main_story_chapter {
    return Intl.message('Chapter', name: 'main_story_chapter', desc: '', locale: localeName, args: []);
  }

  /// `Gimmicks`
  String get map_gimmicks {
    return Intl.message('Gimmicks', name: 'map_gimmicks', desc: '', locale: localeName, args: []);
  }

  /// `Layer {layer}`
  String map_layer_n(Object layer) {
    return Intl.message('Layer $layer', name: 'map_layer_n', desc: '', locale: localeName, args: [layer]);
  }

  /// `FQ spots only`
  String get map_show_fq_spots_only {
    return Intl.message('FQ spots only', name: 'map_show_fq_spots_only', desc: '', locale: localeName, args: []);
  }

  /// `Show Header Image`
  String get map_show_header_image {
    return Intl.message('Show Header Image', name: 'map_show_header_image', desc: '', locale: localeName, args: []);
  }

  /// `Show Roads`
  String get map_show_roads {
    return Intl.message('Show Roads', name: 'map_show_roads', desc: '', locale: localeName, args: []);
  }

  /// `Show Spots`
  String get map_show_spots {
    return Intl.message('Show Spots', name: 'map_show_spots', desc: '', locale: localeName, args: []);
  }

  /// `Master Affection`
  String get master_affection {
    return Intl.message('Master Affection', name: 'master_affection', desc: '', locale: localeName, args: []);
  }

  /// `Master-Detail width`
  String get master_detail_width {
    return Intl.message('Master-Detail width', name: 'master_detail_width', desc: '', locale: localeName, args: []);
  }

  /// `Master Mission`
  String get master_mission {
    return Intl.message('Master Mission', name: 'master_mission', desc: '', locale: localeName, args: []);
  }

  /// `Related Quests`
  String get master_mission_related_quest {
    return Intl.message('Related Quests', name: 'master_mission_related_quest', desc: '', locale: localeName, args: []);
  }

  /// `Solution`
  String get master_mission_solution {
    return Intl.message('Solution', name: 'master_mission_solution', desc: '', locale: localeName, args: []);
  }

  /// `Weekly Mission`
  String get master_mission_weekly {
    return Intl.message('Weekly Mission', name: 'master_mission_weekly', desc: '', locale: localeName, args: []);
  }

  /// `Max enemy act count`
  String get max_enemy_act_count {
    return Intl.message('Max enemy act count', name: 'max_enemy_act_count', desc: '', locale: localeName, args: []);
  }

  /// `Max enemies on stage`
  String get max_enemy_on_stage {
    return Intl.message('Max enemies on stage', name: 'max_enemy_on_stage', desc: '', locale: localeName, args: []);
  }

  /// `MLB`
  String get max_limit_break {
    return Intl.message('MLB', name: 'max_limit_break', desc: '', locale: localeName, args: []);
  }

  /// `Max Window Width`
  String get max_window_width {
    return Intl.message('Max Window Width', name: 'max_window_width', desc: '', locale: localeName, args: []);
  }

  /// `Assets`
  String get media_assets {
    return Intl.message('Assets', name: 'media_assets', desc: '', locale: localeName, args: []);
  }

  /// `Merge`
  String get merge {
    return Intl.message('Merge', name: 'merge', desc: '', locale: localeName, args: []);
  }

  /// `Merge Same Drop Item`
  String get merge_same_drop {
    return Intl.message('Merge Same Drop Item', name: 'merge_same_drop', desc: '', locale: localeName, args: []);
  }

  /// `NOT MIGRATE`
  String get migrate_external_storage_btn_no {
    return Intl.message('NOT MIGRATE', name: 'migrate_external_storage_btn_no', desc: '', locale: localeName, args: []);
  }

  /// `MIGRATE`
  String get migrate_external_storage_btn_yes {
    return Intl.message('MIGRATE', name: 'migrate_external_storage_btn_yes', desc: '', locale: localeName, args: []);
  }

  /// `Please move the data manually, otherwise the data will be empty after startup.`
  String get migrate_external_storage_manual_warning {
    return Intl.message(
      'Please move the data manually, otherwise the data will be empty after startup.',
      name: 'migrate_external_storage_manual_warning',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Migrate Data`
  String get migrate_external_storage_title {
    return Intl.message('Migrate Data', name: 'migrate_external_storage_title', desc: '', locale: localeName, args: []);
  }

  /// `Mission`
  String get mission {
    return Intl.message('Mission', name: 'mission', desc: '', locale: localeName, args: []);
  }

  /// `Mission Targets`
  String get mission_target {
    return Intl.message('Mission Targets', name: 'mission_target', desc: '', locale: localeName, args: []);
  }

  /// `Move down`
  String get move_down {
    return Intl.message('Move down', name: 'move_down', desc: '', locale: localeName, args: []);
  }

  /// `Move up`
  String get move_up {
    return Intl.message('Move up', name: 'move_up', desc: '', locale: localeName, args: []);
  }

  /// `My Room`
  String get my_room {
    return Intl.message('My Room', name: 'my_room', desc: '', locale: localeName, args: []);
  }

  /// `Mystic Code`
  String get mystic_code {
    return Intl.message('Mystic Code', name: 'mystic_code', desc: '', locale: localeName, args: []);
  }

  /// `Name`
  String get name {
    return Intl.message('Name', name: 'name', desc: '', locale: localeName, args: []);
  }

  /// `Force Online Mode`
  String get network_force_online {
    return Intl.message('Force Online Mode', name: 'network_force_online', desc: '', locale: localeName, args: []);
  }

  /// `App will change to offline mode if no network detected`
  String get network_force_online_hint {
    return Intl.message(
      'App will change to offline mode if no network detected',
      name: 'network_force_online_hint',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Network Settings`
  String get network_settings {
    return Intl.message('Network Settings', name: 'network_settings', desc: '', locale: localeName, args: []);
  }

  /// `Network Status`
  String get network_status {
    return Intl.message('Network Status', name: 'network_status', desc: '', locale: localeName, args: []);
  }

  /// `New account`
  String get new_account {
    return Intl.message('New account', name: 'new_account', desc: '', locale: localeName, args: []);
  }

  /// `New data available`
  String get new_data_available {
    return Intl.message('New data available', name: 'new_data_available', desc: '', locale: localeName, args: []);
  }

  /// `Next`
  String get next_card {
    return Intl.message('Next', name: 'next_card', desc: '', locale: localeName, args: []);
  }

  /// `NEXT`
  String get next_page {
    return Intl.message('NEXT', name: 'next_page', desc: '', locale: localeName, args: []);
  }

  /// `There is no interlude or rank up quest`
  String get no_servant_quest_hint {
    return Intl.message(
      'There is no interlude or rank up quest',
      name: 'no_servant_quest_hint',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Click ♡ to view all servants' quests`
  String get no_servant_quest_hint_subtitle {
    return Intl.message(
      'Click ♡ to view all servants\' quests',
      name: 'no_servant_quest_hint_subtitle',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Noble Phantasm`
  String get noble_phantasm {
    return Intl.message('Noble Phantasm', name: 'noble_phantasm', desc: '', locale: localeName, args: []);
  }

  /// `Noble Phantasm`
  String get noble_phantasm_level {
    return Intl.message('Noble Phantasm', name: 'noble_phantasm_level', desc: '', locale: localeName, args: []);
  }

  /// `Non-favorite servants will be skipped`
  String get non_favorite_svt_be_skipped {
    return Intl.message(
      'Non-favorite servants will be skipped',
      name: 'non_favorite_svt_be_skipped',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Normal`
  String get normal {
    return Intl.message('Normal', name: 'normal', desc: '', locale: localeName, args: []);
  }

  /// `Normal Attack`
  String get normal_attack {
    return Intl.message('Normal Attack', name: 'normal_attack', desc: '', locale: localeName, args: []);
  }

  /// `Not Found`
  String get not_found {
    return Intl.message('Not Found', name: 'not_found', desc: '', locale: localeName, args: []);
  }

  /// `Not yet implemented`
  String get not_implemented {
    return Intl.message('Not yet implemented', name: 'not_implemented', desc: '', locale: localeName, args: []);
  }

  /// `Not Started`
  String get not_started {
    return Intl.message('Not Started', name: 'not_started', desc: '', locale: localeName, args: []);
  }

  /// `NP Charge`
  String get np_charge {
    return Intl.message('NP Charge', name: 'np_charge', desc: '', locale: localeName, args: []);
  }

  /// `Instant`
  String get np_charge_type_instant {
    return Intl.message('Instant', name: 'np_charge_type_instant', desc: '', locale: localeName, args: []);
  }

  /// `Instant Sum`
  String get np_charge_type_instant_sum {
    return Intl.message('Instant Sum', name: 'np_charge_type_instant_sum', desc: '', locale: localeName, args: []);
  }

  /// `Per Turn`
  String get np_charge_type_perturn {
    return Intl.message('Per Turn', name: 'np_charge_type_perturn', desc: '', locale: localeName, args: []);
  }

  /// `NP Damage`
  String get np_damage {
    return Intl.message('NP Damage', name: 'np_damage', desc: '', locale: localeName, args: []);
  }

  /// `NP Gain Mod`
  String get np_gain_mod {
    return Intl.message('NP Gain Mod', name: 'np_gain_mod', desc: '', locale: localeName, args: []);
  }

  /// `NP Not Enough`
  String get np_not_enough {
    return Intl.message('NP Not Enough', name: 'np_not_enough', desc: '', locale: localeName, args: []);
  }

  /// `NP refund`
  String get np_refund {
    return Intl.message('NP refund', name: 'np_refund', desc: '', locale: localeName, args: []);
  }

  /// `Refund`
  String get np_refund_short {
    return Intl.message('Refund', name: 'np_refund_short', desc: '', locale: localeName, args: []);
  }

  /// `NP S.E.`
  String get np_se {
    return Intl.message('NP S.E.', name: 'np_se', desc: '', locale: localeName, args: []);
  }

  /// `NP`
  String get np_short {
    return Intl.message('NP', name: 'np_short', desc: '', locale: localeName, args: []);
  }

  /// `NP Special Damage Rate`
  String get np_sp_damage_rate {
    return Intl.message('NP Special Damage Rate', name: 'np_sp_damage_rate', desc: '', locale: localeName, args: []);
  }

  /// `Obtain`
  String get obtain {
    return Intl.message('Obtain', name: 'obtain', desc: '', locale: localeName, args: []);
  }

  /// `Time`
  String get obtain_time {
    return Intl.message('Time', name: 'obtain_time', desc: '', locale: localeName, args: []);
  }

  /// `OK`
  String get ok {
    return Intl.message('OK', name: 'ok', desc: '', locale: localeName, args: []);
  }

  /// `One-off Quest`
  String get one_off_quest {
    return Intl.message('One-off Quest', name: 'one_off_quest', desc: '', locale: localeName, args: []);
  }

  /// `Ongoing`
  String get ongoing {
    return Intl.message('Ongoing', name: 'ongoing', desc: '', locale: localeName, args: []);
  }

  /// `Only for Grand Battle`
  String get only_grand_battle_hint {
    return Intl.message(
      'Only for Grand Battle',
      name: 'only_grand_battle_hint',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Only show enemies from main story's free quest`
  String get only_show_main_story_enemy {
    return Intl.message(
      'Only show enemies from main story\'s free quest',
      name: 'only_show_main_story_enemy',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Only used for AoE NP`
  String get only_usuable_for_aoe_np {
    return Intl.message(
      'Only used for AoE NP',
      name: 'only_usuable_for_aoe_np',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Open`
  String get open {
    return Intl.message('Open', name: 'open', desc: '', locale: localeName, args: []);
  }

  /// `Condition`
  String get open_condition {
    return Intl.message('Condition', name: 'open_condition', desc: '', locale: localeName, args: []);
  }

  /// `Open in browser`
  String get open_in_browser {
    return Intl.message('Open in browser', name: 'open_in_browser', desc: '', locale: localeName, args: []);
  }

  /// `Please open with file manager`
  String get open_in_file_manager {
    return Intl.message(
      'Please open with file manager',
      name: 'open_in_file_manager',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Open Settings`
  String get open_settings {
    return Intl.message('Open Settings', name: 'open_settings', desc: '', locale: localeName, args: []);
  }

  /// `Opening Time`
  String get opening_time {
    return Intl.message('Opening Time', name: 'opening_time', desc: '', locale: localeName, args: []);
  }

  /// `Optional Event Passive`
  String get optional_event_passive {
    return Intl.message(
      'Optional Event Passive',
      name: 'optional_event_passive',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Options`
  String get options {
    return Intl.message('Options', name: 'options', desc: '', locale: localeName, args: []);
  }

  /// `Outdated`
  String get outdated {
    return Intl.message('Outdated', name: 'outdated', desc: '', locale: localeName, args: []);
  }

  /// `Override`
  String get override_ {
    return Intl.message('Override', name: 'override_', desc: '', locale: localeName, args: []);
  }

  /// `Overview`
  String get overview {
    return Intl.message('Overview', name: 'overview', desc: '', locale: localeName, args: []);
  }

  /// `Passive Skill`
  String get passive_skill {
    return Intl.message('Passive Skill', name: 'passive_skill', desc: '', locale: localeName, args: []);
  }

  /// `Passive`
  String get passive_skill_short {
    return Intl.message('Passive', name: 'passive_skill_short', desc: '', locale: localeName, args: []);
  }

  /// `Paste`
  String get paste {
    return Intl.message('Paste', name: 'paste', desc: '', locale: localeName, args: []);
  }

  /// `Choose one Quest Enemy, open popup menu, then copy it to clipboard.`
  String get paste_enemy_hint {
    return Intl.message(
      'Choose one Quest Enemy, open popup menu, then copy it to clipboard.',
      name: 'paste_enemy_hint',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Permanent`
  String get permanent {
    return Intl.message('Permanent', name: 'permanent', desc: '', locale: localeName, args: []);
  }

  /// `Personalized Ads`
  String get personalized_ads {
    return Intl.message('Personalized Ads', name: 'personalized_ads', desc: '', locale: localeName, args: []);
  }

  /// `Off: non-personalized ads only.`
  String get personalized_ads_desc {
    return Intl.message(
      'Off: non-personalized ads only.',
      name: 'personalized_ads_desc',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Pin to Top`
  String get pin_to_top {
    return Intl.message('Pin to Top', name: 'pin_to_top', desc: '', locale: localeName, args: []);
  }

  /// `Plan`
  String get plan {
    return Intl.message('Plan', name: 'plan', desc: '', locale: localeName, args: []);
  }

  /// `Only Unlocked Appends`
  String get plan_list_only_unlock_append {
    return Intl.message(
      'Only Unlocked Appends',
      name: 'plan_list_only_unlock_append',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Current`
  String get plan_list_set_all_current {
    return Intl.message('Current', name: 'plan_list_set_all_current', desc: '', locale: localeName, args: []);
  }

  /// `Target`
  String get plan_list_set_all_target {
    return Intl.message('Target', name: 'plan_list_set_all_target', desc: '', locale: localeName, args: []);
  }

  /// `Plan Objective`
  String get plan_objective {
    return Intl.message('Plan Objective', name: 'plan_objective', desc: '', locale: localeName, args: []);
  }

  /// `Plan`
  String get plan_title {
    return Intl.message('Plan', name: 'plan_title', desc: '', locale: localeName, args: []);
  }

  /// `Planning Quests`
  String get planning_free_quest_btn {
    return Intl.message('Planning Quests', name: 'planning_free_quest_btn', desc: '', locale: localeName, args: []);
  }

  /// `Player`
  String get player {
    return Intl.message('Player', name: 'player', desc: '', locale: localeName, args: []);
  }

  /// `Player Data`
  String get player_data {
    return Intl.message('Player Data', name: 'player_data', desc: '', locale: localeName, args: []);
  }

  /// `Player Only`
  String get player_only {
    return Intl.message('Player Only', name: 'player_only', desc: '', locale: localeName, args: []);
  }

  /// `Prefer April Fools' Day icon`
  String get prefer_april_fool_icon {
    return Intl.message(
      'Prefer April Fools\' Day icon',
      name: 'prefer_april_fool_icon',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Preferred Translation`
  String get preferred_translation {
    return Intl.message('Preferred Translation', name: 'preferred_translation', desc: '', locale: localeName, args: []);
  }

  /// `Used for game data description, not UI language. Not all game data is translated for all 5 official languages.`
  String get preferred_translation_footer {
    return Intl.message(
      'Used for game data description, not UI language. Not all game data is translated for all 5 official languages.',
      name: 'preferred_translation_footer',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Present Box`
  String get present_box {
    return Intl.message('Present Box', name: 'present_box', desc: '', locale: localeName, args: []);
  }

  /// `PREV`
  String get prev_page {
    return Intl.message('PREV', name: 'prev_page', desc: '', locale: localeName, args: []);
  }

  /// `Preview`
  String get preview {
    return Intl.message('Preview', name: 'preview', desc: '', locale: localeName, args: []);
  }

  /// `Previous`
  String get previous_card {
    return Intl.message('Previous', name: 'previous_card', desc: '', locale: localeName, args: []);
  }

  /// `Priority`
  String get priority {
    return Intl.message('Priority', name: 'priority', desc: '', locale: localeName, args: []);
  }

  /// `Tags should not be too long, otherwise it cannot be shown completely`
  String get priority_tagging_hint {
    return Intl.message(
      'Tags should not be too long, otherwise it cannot be shown completely',
      name: 'priority_tagging_hint',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Agree to the privacy policy to enable optional features`
  String get privacy_agree_desc {
    return Intl.message(
      'Agree to the privacy policy to enable optional features',
      name: 'privacy_agree_desc',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Privacy & Feedback`
  String get privacy_and_feedback {
    return Intl.message('Privacy & Feedback', name: 'privacy_and_feedback', desc: '', locale: localeName, args: []);
  }

  /// `Privacy & Data`
  String get privacy_center {
    return Intl.message('Privacy & Data', name: 'privacy_center', desc: '', locale: localeName, args: []);
  }

  /// `Contact Us`
  String get privacy_contact {
    return Intl.message('Contact Us', name: 'privacy_contact', desc: '', locale: localeName, args: []);
  }

  /// `We respond to privacy questions and complaints within 15 working days.`
  String get privacy_contact_desc {
    return Intl.message(
      'We respond to privacy questions and complaints within 15 working days.',
      name: 'privacy_contact_desc',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Data & Privacy`
  String get privacy_data_switches {
    return Intl.message('Data & Privacy', name: 'privacy_data_switches', desc: '', locale: localeName, args: []);
  }

  /// `Could not open settings. Please find Chaldea manually.`
  String get privacy_open_settings_failed {
    return Intl.message(
      'Could not open settings. Please find Chaldea manually.',
      name: 'privacy_open_settings_failed',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Advertising Identifiers & Tracking`
  String get privacy_permission_ad_identifiers {
    return Intl.message(
      'Advertising Identifiers & Tracking',
      name: 'privacy_permission_ad_identifiers',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Advertising capability; iOS tracking requires system authorization.`
  String get privacy_permission_ad_identifiers_desc {
    return Intl.message(
      'Advertising capability; iOS tracking requires system authorization.',
      name: 'privacy_permission_ad_identifiers_desc',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Files & Storage`
  String get privacy_permission_files {
    return Intl.message('Files & Storage', name: 'privacy_permission_files', desc: '', locale: localeName, args: []);
  }

  /// `Import, export and image saving on older Android versions.`
  String get privacy_permission_files_desc {
    return Intl.message(
      'Import, export and image saving on older Android versions.',
      name: 'privacy_permission_files_desc',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Internet & Network State`
  String get privacy_permission_network {
    return Intl.message(
      'Internet & Network State',
      name: 'privacy_permission_network',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Access data, images and online services.`
  String get privacy_permission_network_desc {
    return Intl.message(
      'Access data, images and online services.',
      name: 'privacy_permission_network_desc',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Notifications & Reminders`
  String get privacy_permission_notifications {
    return Intl.message(
      'Notifications & Reminders',
      name: 'privacy_permission_notifications',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Reminders are unavailable; related declarations remain.`
  String get privacy_permission_notifications_desc {
    return Intl.message(
      'Reminders are unavailable; related declarations remain.',
      name: 'privacy_permission_notifications_desc',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Other Declarations`
  String get privacy_permission_other {
    return Intl.message('Other Declarations', name: 'privacy_permission_other', desc: '', locale: localeName, args: []);
  }

  /// `A declaration does not imply authorization or use.`
  String get privacy_permission_other_desc {
    return Intl.message(
      'A declaration does not imply authorization or use.',
      name: 'privacy_permission_other_desc',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Phone State`
  String get privacy_permission_phone {
    return Intl.message('Phone State', name: 'privacy_permission_phone', desc: '', locale: localeName, args: []);
  }

  /// `Ad-related declaration; not required for basic features.`
  String get privacy_permission_phone_desc {
    return Intl.message(
      'Ad-related declaration; not required for basic features.',
      name: 'privacy_permission_phone_desc',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Permission Usage`
  String get privacy_permissions {
    return Intl.message('Permission Usage', name: 'privacy_permissions', desc: '', locale: localeName, args: []);
  }

  /// `Permissions & Third-Party Services`
  String get privacy_permissions_and_services {
    return Intl.message(
      'Permissions & Third-Party Services',
      name: 'privacy_permissions_and_services',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Refer to system settings for authorization status.`
  String get privacy_permissions_intro {
    return Intl.message(
      'Refer to system settings for authorization status.',
      name: 'privacy_permissions_intro',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `No complete permission audit data is available for this version.`
  String get privacy_permissions_unverified {
    return Intl.message(
      'No complete permission audit data is available for this version.',
      name: 'privacy_permissions_unverified',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Privacy Policy`
  String get privacy_policy {
    return Intl.message('Privacy Policy', name: 'privacy_policy', desc: '', locale: localeName, args: []);
  }

  /// `Agreed version`
  String get privacy_policy_version {
    return Intl.message('Agreed version', name: 'privacy_policy_version', desc: '', locale: localeName, args: []);
  }

  /// `Third-Party SDKs`
  String get privacy_sdk_list {
    return Intl.message('Third-Party SDKs', name: 'privacy_sdk_list', desc: '', locale: localeName, args: []);
  }

  /// `Your Rights`
  String get privacy_your_rights {
    return Intl.message('Your Rights', name: 'privacy_your_rights', desc: '', locale: localeName, args: []);
  }

  /// `probability`
  String get probability {
    return Intl.message('probability', name: 'probability', desc: '', locale: localeName, args: []);
  }

  /// `Expectation`
  String get probability_expectation {
    return Intl.message('Expectation', name: 'probability_expectation', desc: '', locale: localeName, args: []);
  }

  /// `Product Analytics`
  String get product_analytics {
    return Intl.message('Product Analytics', name: 'product_analytics', desc: '', locale: localeName, args: []);
  }

  /// `Anonymous usage statistics to improve features.`
  String get product_analytics_desc {
    return Intl.message(
      'Anonymous usage statistics to improve features.',
      name: 'product_analytics_desc',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Progress`
  String get progress {
    return Intl.message('Progress', name: 'progress', desc: '', locale: localeName, args: []);
  }

  /// `Project Homepage`
  String get project_homepage {
    return Intl.message('Project Homepage', name: 'project_homepage', desc: '', locale: localeName, args: []);
  }

  /// `Quest`
  String get quest {
    return Intl.message('Quest', name: 'quest', desc: '', locale: localeName, args: []);
  }

  /// `Section {n}`
  String quest_chapter_n(Object n) {
    return Intl.message('Section $n', name: 'quest_chapter_n', desc: '', locale: localeName, args: [n]);
  }

  /// `Conditions`
  String get quest_condition {
    return Intl.message('Conditions', name: 'quest_condition', desc: '', locale: localeName, args: []);
  }

  /// `There are almost identical quests with this quest. Please be careful to distinguish them`
  String get quest_content_same_warning {
    return Intl.message(
      'There are almost identical quests with this quest. Please be careful to distinguish them',
      name: 'quest_content_same_warning',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Invalid quest, only Free and Raid Quests supports team sharing`
  String get quest_disallow_laplace_share_hint {
    return Intl.message(
      'Invalid quest, only Free and Raid Quests supports team sharing',
      name: 'quest_disallow_laplace_share_hint',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `For event effects, both war and field trait(94000xxx) are required to be correctly set.\nOnly basic quest/enemy edit supported, special functions (multiple hp bar/shiftServant) are not supported. Customize JSON data for complex quest.`
  String get quest_edit_hint {
    return Intl.message(
      'For event effects, both war and field trait(94000xxx) are required to be correctly set.\nOnly basic quest/enemy edit supported, special functions (multiple hp bar/shiftServant) are not supported. Customize JSON data for complex quest.',
      name: 'quest_edit_hint',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `A summary for enemies in free quest from Main Story, any property may be overridden from server. Only for reference.\n*Special* Trait means only part of enemies have this trait.`
  String get quest_enemy_summary_hint {
    return Intl.message(
      'A summary for enemies in free quest from Main Story, any property may be overridden from server. Only for reference.\n*Special* Trait means only part of enemies have this trait.',
      name: 'quest_enemy_summary_hint',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Field Buffs`
  String get quest_field_buffs {
    return Intl.message('Field Buffs', name: 'quest_field_buffs', desc: '', locale: localeName, args: []);
  }

  /// `Fields`
  String get quest_fields {
    return Intl.message('Fields', name: 'quest_fields', desc: '', locale: localeName, args: []);
  }

  /// `Drops`
  String get quest_fixed_drop {
    return Intl.message('Drops', name: 'quest_fixed_drop', desc: '', locale: localeName, args: []);
  }

  /// `Drops`
  String get quest_fixed_drop_short {
    return Intl.message('Drops', name: 'quest_fixed_drop_short', desc: '', locale: localeName, args: []);
  }

  /// `Something went wrong or {region} doesn't have this quest's data`
  String quest_not_found_error(Object region) {
    return Intl.message(
      'Something went wrong or $region doesn\'t have this quest\'s data',
      name: 'quest_not_found_error',
      desc: '',
      locale: localeName,
      args: [region],
    );
  }

  /// `Preferred Region`
  String get quest_prefer_region {
    return Intl.message('Preferred Region', name: 'quest_prefer_region', desc: '', locale: localeName, args: []);
  }

  /// `If the related event of the quest has not started at chosen region, it will fallback to JP`
  String get quest_prefer_region_hint {
    return Intl.message(
      'If the related event of the quest has not started at chosen region, it will fallback to JP',
      name: 'quest_prefer_region_hint',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Only JP(after 2020/11) or NA(2020/12) may contain enemy data`
  String get quest_region_has_enemy_hint {
    return Intl.message(
      'Only JP(after 2020/11) or NA(2020/12) may contain enemy data',
      name: 'quest_region_has_enemy_hint',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Restrictions`
  String get quest_restriction {
    return Intl.message('Restrictions', name: 'quest_restriction', desc: '', locale: localeName, args: []);
  }

  /// `Quest Rewards`
  String get quest_reward {
    return Intl.message('Quest Rewards', name: 'quest_reward', desc: '', locale: localeName, args: []);
  }

  /// `Rewards`
  String get quest_reward_short {
    return Intl.message('Rewards', name: 'quest_reward_short', desc: '', locale: localeName, args: []);
  }

  /// `{runs} Runs`
  String quest_runs(Object runs) {
    return Intl.message('$runs Runs', name: 'quest_runs', desc: '', locale: localeName, args: [runs]);
  }

  /// `AP Cost Event Time`
  String get quest_timeline_sort_campaign_open {
    return Intl.message(
      'AP Cost Event Time',
      name: 'quest_timeline_sort_campaign_open',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Quest Open Time`
  String get quest_timeline_sort_quest_open {
    return Intl.message(
      'Quest Open Time',
      name: 'quest_timeline_sort_quest_open',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Version {index}/{total} ({enemy} enemies)`
  String quest_version(Object index, Object total, Object enemy) {
    return Intl.message(
      'Version $index/$total ($enemy enemies)',
      name: 'quest_version',
      desc: '',
      locale: localeName,
      args: [index, total, enemy],
    );
  }

  /// `Wave`
  String get quest_wave {
    return Intl.message('Wave', name: 'quest_wave', desc: '', locale: localeName, args: []);
  }

  /// `Quit`
  String get quit {
    return Intl.message('Quit', name: 'quit', desc: '', locale: localeName, args: []);
  }

  /// `Raid Quest`
  String get raid_quest {
    return Intl.message('Raid Quest', name: 'raid_quest', desc: '', locale: localeName, args: []);
  }

  /// `Random`
  String get random {
    return Intl.message('Random', name: 'random', desc: '', locale: localeName, args: []);
  }

  /// `Random Missions`
  String get random_mission {
    return Intl.message('Random Missions', name: 'random_mission', desc: '', locale: localeName, args: []);
  }

  /// `Rank Up`
  String get rankup_quest {
    return Intl.message('Rank Up', name: 'rankup_quest', desc: '', locale: localeName, args: []);
  }

  /// `Some quests' start time is not correct.\nIf show by AP campaign time, only JP time is used.`
  String get rankup_timeline_hint {
    return Intl.message(
      'Some quests\' start time is not correct.\nIf show by AP campaign time, only JP time is used.',
      name: 'rankup_timeline_hint',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Rare Enemy`
  String get rare_enemy {
    return Intl.message('Rare Enemy', name: 'rare_enemy', desc: '', locale: localeName, args: []);
  }

  /// `Rarity`
  String get rarity {
    return Intl.message('Rarity', name: 'rarity', desc: '', locale: localeName, args: []);
  }

  /// `Rate on App Store`
  String get rate_app_store {
    return Intl.message('Rate on App Store', name: 'rate_app_store', desc: '', locale: localeName, args: []);
  }

  /// `Rate on Google Play`
  String get rate_play_store {
    return Intl.message('Rate on Google Play', name: 'rate_play_store', desc: '', locale: localeName, args: []);
  }

  /// `Raw Gachas`
  String get raw_gacha_data {
    return Intl.message('Raw Gachas', name: 'raw_gacha_data', desc: '', locale: localeName, args: []);
  }

  /// `Raw Gacha Group`
  String get raw_gacha_group {
    return Intl.message('Raw Gacha Group', name: 'raw_gacha_group', desc: '', locale: localeName, args: []);
  }

  /// `Read this Device's info`
  String get read_device_info {
    return Intl.message('Read this Device\'s info', name: 'read_device_info', desc: '', locale: localeName, args: []);
  }

  /// `{unknown} unknown, {dup} dup, {valid}/{total} valid, {selected} selected`
  String recognizer_result_count(Object unknown, Object dup, Object valid, Object total, Object selected) {
    return Intl.message(
      '$unknown unknown, $dup dup, $valid/$total valid, $selected selected',
      name: 'recognizer_result_count',
      desc: '',
      locale: localeName,
      args: [unknown, dup, valid, total, selected],
    );
  }

  /// `Current View`
  String get recorder_screenshot_current_view {
    return Intl.message(
      'Current View',
      name: 'recorder_screenshot_current_view',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Full View`
  String get recorder_screenshot_full_view {
    return Intl.message('Full View', name: 'recorder_screenshot_full_view', desc: '', locale: localeName, args: []);
  }

  /// `Redownload`
  String get redownload {
    return Intl.message('Redownload', name: 'redownload', desc: '', locale: localeName, args: []);
  }

  /// `Refresh`
  String get refresh {
    return Intl.message('Refresh', name: 'refresh', desc: '', locale: localeName, args: []);
  }

  /// `CN`
  String get region_cn {
    return Intl.message('CN', name: 'region_cn', desc: '', locale: localeName, args: []);
  }

  /// `JP`
  String get region_jp {
    return Intl.message('JP', name: 'region_jp', desc: '', locale: localeName, args: []);
  }

  /// `KR`
  String get region_kr {
    return Intl.message('KR', name: 'region_kr', desc: '', locale: localeName, args: []);
  }

  /// `NA`
  String get region_na {
    return Intl.message('NA', name: 'region_na', desc: '', locale: localeName, args: []);
  }

  /// `{region} Notice`
  String region_notice(Object region) {
    return Intl.message('$region Notice', name: 'region_notice', desc: '', locale: localeName, args: [region]);
  }

  /// `TW`
  String get region_tw {
    return Intl.message('TW', name: 'region_tw', desc: '', locale: localeName, args: []);
  }

  /// `Related Traits`
  String get related_traits {
    return Intl.message('Related Traits', name: 'related_traits', desc: '', locale: localeName, args: []);
  }

  /// `Remove`
  String get remove {
    return Intl.message('Remove', name: 'remove', desc: '', locale: localeName, args: []);
  }

  /// `Remove duplicated`
  String get remove_duplicated_svt {
    return Intl.message('Remove duplicated', name: 'remove_duplicated_svt', desc: '', locale: localeName, args: []);
  }

  /// `Remove from blacklist`
  String get remove_from_blacklist {
    return Intl.message('Remove from blacklist', name: 'remove_from_blacklist', desc: '', locale: localeName, args: []);
  }

  /// `Remove Mission`
  String get remove_mission {
    return Intl.message('Remove Mission', name: 'remove_mission', desc: '', locale: localeName, args: []);
  }

  /// `Rename`
  String get rename {
    return Intl.message('Rename', name: 'rename', desc: '', locale: localeName, args: []);
  }

  /// `Report inappropriate ad`
  String get report_inappropriate_ad {
    return Intl.message(
      'Report inappropriate ad',
      name: 'report_inappropriate_ad',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Rerun`
  String get rerun_event {
    return Intl.message('Rerun', name: 'rerun_event', desc: '', locale: localeName, args: []);
  }

  /// `Reset`
  String get reset {
    return Intl.message('Reset', name: 'reset', desc: '', locale: localeName, args: []);
  }

  /// `Reset custom ascension icons`
  String get reset_custom_ascension_icon {
    return Intl.message(
      'Reset custom ascension icons',
      name: 'reset_custom_ascension_icon',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Reset Plan {n}(All)`
  String reset_plan_all(Object n) {
    return Intl.message('Reset Plan $n(All)', name: 'reset_plan_all', desc: '', locale: localeName, args: [n]);
  }

  /// `Reset Plan {n}(Shown)`
  String reset_plan_shown(Object n) {
    return Intl.message('Reset Plan $n(Shown)', name: 'reset_plan_shown', desc: '', locale: localeName, args: [n]);
  }

  /// `Reset Skill CD`
  String get reset_skill_cd {
    return Intl.message('Reset Skill CD', name: 'reset_skill_cd', desc: '', locale: localeName, args: []);
  }

  /// `Resettable Digged Num`
  String get resettable_digged_num {
    return Intl.message('Resettable Digged Num', name: 'resettable_digged_num', desc: '', locale: localeName, args: []);
  }

  /// `Resolution`
  String get resolution {
    return Intl.message('Resolution', name: 'resolution', desc: '', locale: localeName, args: []);
  }

  /// `Restart to take effect`
  String get restart_to_apply_changes {
    return Intl.message(
      'Restart to take effect',
      name: 'restart_to_apply_changes',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Restart to upgrade. If the update fails, please manually copy the source folder to destination`
  String get restart_to_upgrade_hint {
    return Intl.message(
      'Restart to upgrade. If the update fails, please manually copy the source folder to destination',
      name: 'restart_to_upgrade_hint',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Restore`
  String get restore {
    return Intl.message('Restore', name: 'restore', desc: '', locale: localeName, args: []);
  }

  /// `Results`
  String get results {
    return Intl.message('Results', name: 'results', desc: '', locale: localeName, args: []);
  }

  /// `SQ Plan`
  String get saint_quartz_plan {
    return Intl.message('SQ Plan', name: 'saint_quartz_plan', desc: '', locale: localeName, args: []);
  }

  /// `Keep Same Event Plan`
  String get same_event_plan {
    return Intl.message('Keep Same Event Plan', name: 'same_event_plan', desc: '', locale: localeName, args: []);
  }

  /// `Save`
  String get save {
    return Intl.message('Save', name: 'save', desc: '', locale: localeName, args: []);
  }

  /// `Save As`
  String get save_as {
    return Intl.message('Save As', name: 'save_as', desc: '', locale: localeName, args: []);
  }

  /// `Save Current Team`
  String get save_current_team {
    return Intl.message('Save Current Team', name: 'save_current_team', desc: '', locale: localeName, args: []);
  }

  /// `Save to Photos`
  String get save_to_photos {
    return Intl.message('Save to Photos', name: 'save_to_photos', desc: '', locale: localeName, args: []);
  }

  /// `Saved`
  String get saved {
    return Intl.message('Saved', name: 'saved', desc: '', locale: localeName, args: []);
  }

  /// `Screen Size`
  String get screen_size {
    return Intl.message('Screen Size', name: 'screen_size', desc: '', locale: localeName, args: []);
  }

  /// `Screenshots`
  String get screenshots {
    return Intl.message('Screenshots', name: 'screenshots', desc: '', locale: localeName, args: []);
  }

  /// `Choice`
  String get script_choice {
    return Intl.message('Choice', name: 'script_choice', desc: '', locale: localeName, args: []);
  }

  /// `Choice Branch End`
  String get script_choice_end {
    return Intl.message('Choice Branch End', name: 'script_choice_end', desc: '', locale: localeName, args: []);
  }

  /// `Story`
  String get script_story {
    return Intl.message('Story', name: 'script_story', desc: '', locale: localeName, args: []);
  }

  /// `Search`
  String get search {
    return Intl.message('Search', name: 'search', desc: '', locale: localeName, args: []);
  }

  /// `Basic`
  String get search_option_basic {
    return Intl.message('Basic', name: 'search_option_basic', desc: '', locale: localeName, args: []);
  }

  /// `Search Scopes`
  String get search_options {
    return Intl.message('Search Scopes', name: 'search_options', desc: '', locale: localeName, args: []);
  }

  /// `Select`
  String get select {
    return Intl.message('Select', name: 'select', desc: '', locale: localeName, args: []);
  }

  /// `Select CE`
  String get select_ce {
    return Intl.message('Select CE', name: 'select_ce', desc: '', locale: localeName, args: []);
  }

  /// `Select copy source`
  String get select_copy_plan_source {
    return Intl.message('Select copy source', name: 'select_copy_plan_source', desc: '', locale: localeName, args: []);
  }

  /// `Select Item`
  String get select_item_title {
    return Intl.message('Select Item', name: 'select_item_title', desc: '', locale: localeName, args: []);
  }

  /// `Select Language`
  String get select_lang {
    return Intl.message('Select Language', name: 'select_lang', desc: '', locale: localeName, args: []);
  }

  /// `Select Plan`
  String get select_plan {
    return Intl.message('Select Plan', name: 'select_plan', desc: '', locale: localeName, args: []);
  }

  /// `Select Servant`
  String get select_servant {
    return Intl.message('Select Servant', name: 'select_servant', desc: '', locale: localeName, args: []);
  }

  /// `Select Skill`
  String get select_skill {
    return Intl.message('Select Skill', name: 'select_skill', desc: '', locale: localeName, args: []);
  }

  /// `Select none to skip this effect`
  String get select_skip {
    return Intl.message('Select none to skip this effect', name: 'select_skip', desc: '', locale: localeName, args: []);
  }

  /// `Send email to`
  String get send_email_to {
    return Intl.message('Send email to', name: 'send_email_to', desc: '', locale: localeName, args: []);
  }

  /// `Sending`
  String get sending {
    return Intl.message('Sending', name: 'sending', desc: '', locale: localeName, args: []);
  }

  /// `Sending failed`
  String get sending_failed {
    return Intl.message('Sending failed', name: 'sending_failed', desc: '', locale: localeName, args: []);
  }

  /// `Sent`
  String get sent {
    return Intl.message('Sent', name: 'sent', desc: '', locale: localeName, args: []);
  }

  /// `Servant`
  String get servant {
    return Intl.message('Servant', name: 'servant', desc: '', locale: localeName, args: []);
  }

  /// `Servant Coin`
  String get servant_coin {
    return Intl.message('Servant Coin', name: 'servant_coin', desc: '', locale: localeName, args: []);
  }

  /// `Coin`
  String get servant_coin_short {
    return Intl.message('Coin', name: 'servant_coin_short', desc: '', locale: localeName, args: []);
  }

  /// `Servant Detail Page`
  String get servant_detail_page {
    return Intl.message('Servant Detail Page', name: 'servant_detail_page', desc: '', locale: localeName, args: []);
  }

  /// `Servant List Page`
  String get servant_list_page {
    return Intl.message('Servant List Page', name: 'servant_list_page', desc: '', locale: localeName, args: []);
  }

  /// `SET ALL`
  String get set_all {
    return Intl.message('SET ALL', name: 'set_all', desc: '', locale: localeName, args: []);
  }

  /// `Set Plan Name`
  String get set_plan_name {
    return Intl.message('Set Plan Name', name: 'set_plan_name', desc: '', locale: localeName, args: []);
  }

  /// `Always On Top`
  String get setting_always_on_top {
    return Intl.message('Always On Top', name: 'setting_always_on_top', desc: '', locale: localeName, args: []);
  }

  /// `Auto Rotate`
  String get setting_auto_rotate {
    return Intl.message('Auto Rotate', name: 'setting_auto_rotate', desc: '', locale: localeName, args: []);
  }

  /// `Auto Turn on PlanNotReach`
  String get setting_auto_turn_on_plan_not_reach {
    return Intl.message(
      'Auto Turn on PlanNotReach',
      name: 'setting_auto_turn_on_plan_not_reach',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Allow mouse to drag scrollables`
  String get setting_drag_by_mouse {
    return Intl.message(
      'Allow mouse to drag scrollables',
      name: 'setting_drag_by_mouse',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Home-Plan List Page`
  String get setting_home_plan_list_page {
    return Intl.message(
      'Home-Plan List Page',
      name: 'setting_home_plan_list_page',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Priority Tagging`
  String get setting_priority_tagging {
    return Intl.message('Priority Tagging', name: 'setting_priority_tagging', desc: '', locale: localeName, args: []);
  }

  /// `Servant Class Filter Style`
  String get setting_servant_class_filter_style {
    return Intl.message(
      'Servant Class Filter Style',
      name: 'setting_servant_class_filter_style',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Favorite Button Default`
  String get setting_setting_favorite_button_default {
    return Intl.message(
      'Favorite Button Default',
      name: 'setting_setting_favorite_button_default',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Show Account at Homepage`
  String get setting_show_account_at_homepage {
    return Intl.message(
      'Show Account at Homepage',
      name: 'setting_show_account_at_homepage',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Split Screen Ratio`
  String get setting_split_ratio {
    return Intl.message('Split Screen Ratio', name: 'setting_split_ratio', desc: '', locale: localeName, args: []);
  }

  /// `For wide screen`
  String get setting_split_ratio_hint {
    return Intl.message('For wide screen', name: 'setting_split_ratio_hint', desc: '', locale: localeName, args: []);
  }

  /// `Tabs Sorting`
  String get setting_tabs_sorting {
    return Intl.message('Tabs Sorting', name: 'setting_tabs_sorting', desc: '', locale: localeName, args: []);
  }

  /// `Data`
  String get settings_data {
    return Intl.message('Data', name: 'settings_data', desc: '', locale: localeName, args: []);
  }

  /// `Documents`
  String get settings_documents {
    return Intl.message('Documents', name: 'settings_documents', desc: '', locale: localeName, args: []);
  }

  /// `General`
  String get settings_general {
    return Intl.message('General', name: 'settings_general', desc: '', locale: localeName, args: []);
  }

  /// `Language`
  String get settings_language {
    return Intl.message('Language', name: 'settings_language', desc: '', locale: localeName, args: []);
  }

  /// `Settings`
  String get settings_tab_name {
    return Intl.message('Settings', name: 'settings_tab_name', desc: '', locale: localeName, args: []);
  }

  /// `Backup userdata before upgrading application, and move backups to safe locations outside app's document folder`
  String get settings_userdata_footer {
    return Intl.message(
      'Backup userdata before upgrading application, and move backups to safe locations outside app\'s document folder',
      name: 'settings_userdata_footer',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Share`
  String get share {
    return Intl.message('Share', name: 'share', desc: '', locale: localeName, args: []);
  }

  /// `Shops`
  String get shop {
    return Intl.message('Shops', name: 'shop', desc: '', locale: localeName, args: []);
  }

  /// `Free Condition`
  String get shop_free_condition {
    return Intl.message('Free Condition', name: 'shop_free_condition', desc: '', locale: localeName, args: []);
  }

  /// `Show`
  String get show {
    return Intl.message('Show', name: 'show', desc: '', locale: localeName, args: []);
  }

  /// `Show Carousel`
  String get show_carousel {
    return Intl.message('Show Carousel', name: 'show_carousel', desc: '', locale: localeName, args: []);
  }

  /// `Show Empty Event`
  String get show_empty_event {
    return Intl.message('Show Empty Event', name: 'show_empty_event', desc: '', locale: localeName, args: []);
  }

  /// `Show Frame Rate`
  String get show_frame_rate {
    return Intl.message('Show Frame Rate', name: 'show_frame_rate', desc: '', locale: localeName, args: []);
  }

  /// `Show Fullscreen`
  String get show_fullscreen {
    return Intl.message('Show Fullscreen', name: 'show_fullscreen', desc: '', locale: localeName, args: []);
  }

  /// `Show Less`
  String get show_less {
    return Intl.message('Show Less', name: 'show_less', desc: '', locale: localeName, args: []);
  }

  /// `Show Campaign Events`
  String get show_mc_campaign {
    return Intl.message('Show Campaign Events', name: 'show_mc_campaign', desc: '', locale: localeName, args: []);
  }

  /// `Show More`
  String get show_more {
    return Intl.message('Show More', name: 'show_more', desc: '', locale: localeName, args: []);
  }

  /// `Show original mission text`
  String get show_original_mission_text {
    return Intl.message(
      'Show original mission text',
      name: 'show_original_mission_text',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Show Outdated`
  String get show_outdated {
    return Intl.message('Show Outdated', name: 'show_outdated', desc: '', locale: localeName, args: []);
  }

  /// `Show in System Tray`
  String get show_system_tray {
    return Intl.message('Show in System Tray', name: 'show_system_tray', desc: '', locale: localeName, args: []);
  }

  /// `Silver`
  String get silver {
    return Intl.message('Silver', name: 'silver', desc: '', locale: localeName, args: []);
  }

  /// `Simulate Enemy Actions`
  String get simulate_enemy_actions {
    return Intl.message(
      'Simulate Enemy Actions',
      name: 'simulate_enemy_actions',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Simulate Simple AI`
  String get simulate_simple_ai {
    return Intl.message('Simulate Simple AI', name: 'simulate_simple_ai', desc: '', locale: localeName, args: []);
  }

  /// `Simulator`
  String get simulator {
    return Intl.message('Simulator', name: 'simulator', desc: '', locale: localeName, args: []);
  }

  /// `Skill`
  String get skill {
    return Intl.message('Skill', name: 'skill', desc: '', locale: localeName, args: []);
  }

  /// `Skill List`
  String get skill_list {
    return Intl.message('Skill List', name: 'skill_list', desc: '', locale: localeName, args: []);
  }

  /// `Skill Upgrade`
  String get skill_rankup {
    return Intl.message('Skill Upgrade', name: 'skill_rankup', desc: '', locale: localeName, args: []);
  }

  /// `Skill Up`
  String get skill_up {
    return Intl.message('Skill Up', name: 'skill_up', desc: '', locale: localeName, args: []);
  }

  /// `Skip`
  String get skip {
    return Intl.message('Skip', name: 'skip', desc: '', locale: localeName, args: []);
  }

  /// `Skip Current Turn`
  String get skip_current_turn {
    return Intl.message('Skip Current Turn', name: 'skip_current_turn', desc: '', locale: localeName, args: []);
  }

  /// `Battle Count`
  String get solution_battle_count {
    return Intl.message('Battle Count', name: 'solution_battle_count', desc: '', locale: localeName, args: []);
  }

  /// `Target Count`
  String get solution_target_count {
    return Intl.message('Target Count', name: 'solution_target_count', desc: '', locale: localeName, args: []);
  }

  /// `Total {battles} battles, {ap} AP`
  String solution_total_battles_ap(Object battles, Object ap) {
    return Intl.message(
      'Total $battles battles, $ap AP',
      name: 'solution_total_battles_ap',
      desc: '',
      locale: localeName,
      args: [battles, ap],
    );
  }

  /// `Sort`
  String get sort_order {
    return Intl.message('Sort', name: 'sort_order', desc: '', locale: localeName, args: []);
  }

  /// `Sound Effect`
  String get sound_effect {
    return Intl.message('Sound Effect', name: 'sound_effect', desc: '', locale: localeName, args: []);
  }

  /// `Hide Special Rewards`
  String get special_reward_hide {
    return Intl.message('Hide Special Rewards', name: 'special_reward_hide', desc: '', locale: localeName, args: []);
  }

  /// `Show Special Rewards`
  String get special_reward_show {
    return Intl.message('Show Special Rewards', name: 'special_reward_show', desc: '', locale: localeName, args: []);
  }

  /// `Spirit Origin Release Quest`
  String get spirit_origin_release_quest {
    return Intl.message(
      'Spirit Origin Release Quest',
      name: 'spirit_origin_release_quest',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Spoiler Setting`
  String get spoiler_setting {
    return Intl.message('Spoiler Setting', name: 'spoiler_setting', desc: '', locale: localeName, args: []);
  }

  /// `Sprites`
  String get sprites {
    return Intl.message('Sprites', name: 'sprites', desc: '', locale: localeName, args: []);
  }

  /// `Pack(s)`
  String get sq_buy_pack_unit {
    return Intl.message('Pack(s)', name: 'sq_buy_pack_unit', desc: '', locale: localeName, args: []);
  }

  /// `21 Fragments = 3 Quartzes`
  String get sq_fragment_convert {
    return Intl.message(
      '21 Fragments = 3 Quartzes',
      name: 'sq_fragment_convert',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `SQ`
  String get sq_short {
    return Intl.message('SQ', name: 'sq_short', desc: '', locale: localeName, args: []);
  }

  /// `Opening Movie`
  String get stage_opening_movie {
    return Intl.message('Opening Movie', name: 'stage_opening_movie', desc: '', locale: localeName, args: []);
  }

  /// `Start`
  String get start {
    return Intl.message('Start', name: 'start', desc: '', locale: localeName, args: []);
  }

  /// `Statistics`
  String get statistics_title {
    return Intl.message('Statistics', name: 'statistics_title', desc: '', locale: localeName, args: []);
  }

  /// `Story CE`
  String get story_ce {
    return Intl.message('Story CE', name: 'story_ce', desc: '', locale: localeName, args: []);
  }

  /// `Manually added, please give feedback if anything wrong`
  String get story_figure_manual_add_hint {
    return Intl.message(
      'Manually added, please give feedback if anything wrong',
      name: 'story_figure_manual_add_hint',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Strength Status`
  String get strength_status {
    return Intl.message('Strength Status', name: 'strength_status', desc: '', locale: localeName, args: []);
  }

  /// `Sub Attribute Advantage`
  String get sub_attribute_advantage {
    return Intl.message(
      'Sub Attribute Advantage',
      name: 'sub_attribute_advantage',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Success`
  String get success {
    return Intl.message('Success', name: 'success', desc: '', locale: localeName, args: []);
  }

  /// `Summon`
  String get summon {
    return Intl.message('Summon', name: 'summon', desc: '', locale: localeName, args: []);
  }

  /// `Summon`
  String get summon_banner {
    return Intl.message('Summon', name: 'summon_banner', desc: '', locale: localeName, args: []);
  }

  /// `Daily`
  String get summon_daily {
    return Intl.message('Daily', name: 'summon_daily', desc: '', locale: localeName, args: []);
  }

  /// `Expectation`
  String get summon_expectation_btn {
    return Intl.message('Expectation', name: 'summon_expectation_btn', desc: '', locale: localeName, args: []);
  }

  /// `Just for entertainment`
  String get summon_gacha_footer {
    return Intl.message('Just for entertainment', name: 'summon_gacha_footer', desc: '', locale: localeName, args: []);
  }

  /// `Results`
  String get summon_gacha_result {
    return Intl.message('Results', name: 'summon_gacha_result', desc: '', locale: localeName, args: []);
  }

  /// `JP summon data from Mooncell. Reference only for other regions.`
  String get summon_info_hint {
    return Intl.message(
      'JP summon data from Mooncell. Reference only for other regions.',
      name: 'summon_info_hint',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Pulls`
  String get summon_pull_unit {
    return Intl.message('Pulls', name: 'summon_pull_unit', desc: '', locale: localeName, args: []);
  }

  /// `Show Banner`
  String get summon_show_banner {
    return Intl.message('Show Banner', name: 'summon_show_banner', desc: '', locale: localeName, args: []);
  }

  /// `Ticket`
  String get summon_ticket_short {
    return Intl.message('Ticket', name: 'summon_ticket_short', desc: '', locale: localeName, args: []);
  }

  /// `SP.DMG`
  String get super_effective_damage {
    return Intl.message('SP.DMG', name: 'super_effective_damage', desc: '', locale: localeName, args: []);
  }

  /// `Support and Donation`
  String get support_chaldea {
    return Intl.message('Support and Donation', name: 'support_chaldea', desc: '', locale: localeName, args: []);
  }

  /// `Support Servant`
  String get support_servant {
    return Intl.message('Support Servant', name: 'support_servant', desc: '', locale: localeName, args: []);
  }

  /// `Forced`
  String get support_servant_forced {
    return Intl.message('Forced', name: 'support_servant_forced', desc: '', locale: localeName, args: []);
  }

  /// `Support`
  String get support_servant_short {
    return Intl.message('Support', name: 'support_servant_short', desc: '', locale: localeName, args: []);
  }

  /// `Ascension Icon`
  String get svt_ascension_icon {
    return Intl.message('Ascension Icon', name: 'svt_ascension_icon', desc: '', locale: localeName, args: []);
  }

  /// `Alignment`
  String get svt_attribute {
    return Intl.message('Alignment', name: 'svt_attribute', desc: '', locale: localeName, args: []);
  }

  /// `Info`
  String get svt_basic_info {
    return Intl.message('Info', name: 'svt_basic_info', desc: '', locale: localeName, args: []);
  }

  /// `Enemy's card deck may be incorrect, the hits distribution shall prevail.`
  String get svt_card_deck_incorrect {
    return Intl.message(
      'Enemy\'s card deck may be incorrect, the hits distribution shall prevail.',
      name: 'svt_card_deck_incorrect',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Class`
  String get svt_class {
    return Intl.message('Class', name: 'svt_class', desc: '', locale: localeName, args: []);
  }

  /// `Svt Class`
  String get svt_class_dist {
    return Intl.message('Svt Class', name: 'svt_class_dist', desc: '', locale: localeName, args: []);
  }

  /// `Auto`
  String get svt_class_filter_auto {
    return Intl.message('Auto', name: 'svt_class_filter_auto', desc: '', locale: localeName, args: []);
  }

  /// `Hidden`
  String get svt_class_filter_hide {
    return Intl.message('Hidden', name: 'svt_class_filter_hide', desc: '', locale: localeName, args: []);
  }

  /// `<Extra Class> Collapsed\nSingle Row`
  String get svt_class_filter_single_row {
    return Intl.message(
      '<Extra Class> Collapsed\nSingle Row',
      name: 'svt_class_filter_single_row',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `<Extra Class> Expanded\nSingle Row`
  String get svt_class_filter_single_row_expanded {
    return Intl.message(
      '<Extra Class> Expanded\nSingle Row',
      name: 'svt_class_filter_single_row_expanded',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `<Extra Class> in Second Row`
  String get svt_class_filter_two_row {
    return Intl.message(
      '<Extra Class> in Second Row',
      name: 'svt_class_filter_two_row',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Remember`
  String get svt_fav_btn_remember {
    return Intl.message('Remember', name: 'svt_fav_btn_remember', desc: '', locale: localeName, args: []);
  }

  /// `Show All`
  String get svt_fav_btn_show_all {
    return Intl.message('Show All', name: 'svt_fav_btn_show_all', desc: '', locale: localeName, args: []);
  }

  /// `Show Favorite`
  String get svt_fav_btn_show_favorite {
    return Intl.message('Show Favorite', name: 'svt_fav_btn_show_favorite', desc: '', locale: localeName, args: []);
  }

  /// `Not favorite`
  String get svt_not_planned {
    return Intl.message('Not favorite', name: 'svt_not_planned', desc: '', locale: localeName, args: []);
  }

  /// `Servants may be not released`
  String get svt_not_release_hint {
    return Intl.message(
      'Servants may be not released',
      name: 'svt_not_release_hint',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `1. Servant options are independent from Chaldea's plan data once imported, if need to resync planned options please use the Resync option from the dropdown menu in the top right corner\n2. Skill/NP strengthen status can be set manually via options below\n3. You can manually add custom effect/buff\n4. Svt/ce can be pinged to top in the popup menu from their detail pages`
  String get svt_option_edit_tips {
    return Intl.message(
      '1. Servant options are independent from Chaldea\'s plan data once imported, if need to resync planned options please use the Resync option from the dropdown menu in the top right corner\n2. Skill/NP strengthen status can be set manually via options below\n3. You can manually add custom effect/buff\n4. Svt/ce can be pinged to top in the popup menu from their detail pages',
      name: 'svt_option_edit_tips',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Resync Options`
  String get svt_option_resync {
    return Intl.message('Resync Options', name: 'svt_option_resync', desc: '', locale: localeName, args: []);
  }

  /// `Hidden`
  String get svt_plan_hidden {
    return Intl.message('Hidden', name: 'svt_plan_hidden', desc: '', locale: localeName, args: []);
  }

  /// `Profile`
  String get svt_profile {
    return Intl.message('Profile', name: 'svt_profile', desc: '', locale: localeName, args: []);
  }

  /// `Character Info`
  String get svt_profile_info {
    return Intl.message('Character Info', name: 'svt_profile_info', desc: '', locale: localeName, args: []);
  }

  /// `Profile {n}`
  String svt_profile_n(Object n) {
    return Intl.message('Profile $n', name: 'svt_profile_n', desc: '', locale: localeName, args: [n]);
  }

  /// `Related CEs`
  String get svt_related_ce {
    return Intl.message('Related CEs', name: 'svt_related_ce', desc: '', locale: localeName, args: []);
  }

  /// `Reset Plan`
  String get svt_reset_plan {
    return Intl.message('Reset Plan', name: 'svt_reset_plan', desc: '', locale: localeName, args: []);
  }

  /// `Second Archive`
  String get svt_second_archive {
    return Intl.message('Second Archive', name: 'svt_second_archive', desc: '', locale: localeName, args: []);
  }

  /// `(SkillMax) NPs/Owned/Total`
  String get svt_stat_own_total {
    return Intl.message(
      '(SkillMax) NPs/Owned/Total',
      name: 'svt_stat_own_total',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Sub Attribute`
  String get svt_sub_attribute {
    return Intl.message('Sub Attribute', name: 'svt_sub_attribute', desc: '', locale: localeName, args: []);
  }

  /// `Switch Slider/Dropdown`
  String get svt_switch_slider_dropdown {
    return Intl.message(
      'Switch Slider/Dropdown',
      name: 'svt_switch_slider_dropdown',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Switch Region`
  String get switch_region {
    return Intl.message('Switch Region', name: 'switch_region', desc: '', locale: localeName, args: []);
  }

  /// `Minimize window for close button`
  String get system_tray_close_hint {
    return Intl.message(
      'Minimize window for close button',
      name: 'system_tray_close_hint',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Target`
  String get target {
    return Intl.message('Target', name: 'target', desc: '', locale: localeName, args: []);
  }

  /// `NP Animation`
  String get td_animation {
    return Intl.message('NP Animation', name: 'td_animation', desc: '', locale: localeName, args: []);
  }

  /// `For the same NP id, different owners may have different card type and hit distributions.`
  String get td_base_hits_hint {
    return Intl.message(
      'For the same NP id, different owners may have different card type and hit distributions.',
      name: 'td_base_hits_hint',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `This Noble Phantasm is displayed as {color} card, but doesn't have [{trait}] trait.`
  String td_cardcolor_hint(Object color, Object trait) {
    return Intl.message(
      'This Noble Phantasm is displayed as $color card, but doesn\'t have [$trait] trait.',
      name: 'td_cardcolor_hint',
      desc: '',
      locale: localeName,
      args: [color, trait],
    );
  }

  /// `This is a Noble Phantasm, but doesn't have [{trait}] trait.`
  String td_cardnp_hint(Object trait) {
    return Intl.message(
      'This is a Noble Phantasm, but doesn\'t have [$trait] trait.',
      name: 'td_cardnp_hint',
      desc: '',
      locale: localeName,
      args: [trait],
    );
  }

  /// `NP Upgrade`
  String get td_rankup {
    return Intl.message('NP Upgrade', name: 'td_rankup', desc: '', locale: localeName, args: []);
  }

  /// `Simple Mode`
  String get td_solver_simple_mode {
    return Intl.message('Simple Mode', name: 'td_solver_simple_mode', desc: '', locale: localeName, args: []);
  }

  /// `Only calculates final ascension`
  String get td_solver_simple_mode_desc {
    return Intl.message(
      'Only calculates final ascension',
      name: 'td_solver_simple_mode_desc',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Team`
  String get team {
    return Intl.message('Team', name: 'team', desc: '', locale: localeName, args: []);
  }

  /// `Backup`
  String get team_backup_member {
    return Intl.message('Backup', name: 'team_backup_member', desc: '', locale: localeName, args: []);
  }

  /// `Block CE`
  String get team_block_ce {
    return Intl.message('Block CE', name: 'team_block_ce', desc: '', locale: localeName, args: []);
  }

  /// `Block Servant`
  String get team_block_servant {
    return Intl.message('Block Servant', name: 'team_block_servant', desc: '', locale: localeName, args: []);
  }

  /// `Team Bond`
  String get team_bond {
    return Intl.message('Team Bond', name: 'team_bond', desc: '', locale: localeName, args: []);
  }

  /// `Local Teams`
  String get team_local {
    return Intl.message('Local Teams', name: 'team_local', desc: '', locale: localeName, args: []);
  }

  /// `No Append Skill`
  String get team_no_append_skill {
    return Intl.message('No Append Skill', name: 'team_no_append_skill', desc: '', locale: localeName, args: []);
  }

  /// `No class score`
  String get team_no_class_board {
    return Intl.message('No class score', name: 'team_no_class_board', desc: '', locale: localeName, args: []);
  }

  /// `No Double Castoria`
  String get team_no_double_castoria {
    return Intl.message('No Double Castoria', name: 'team_no_double_castoria', desc: '', locale: localeName, args: []);
  }

  /// `No Double Koyan`
  String get team_no_double_koyan {
    return Intl.message('No Double Koyan', name: 'team_no_double_koyan', desc: '', locale: localeName, args: []);
  }

  /// `No Double Oberon`
  String get team_no_double_oberon {
    return Intl.message('No Double Oberon', name: 'team_no_double_oberon', desc: '', locale: localeName, args: []);
  }

  /// `No Grail/☆4 Fou`
  String get team_no_grail_fou {
    return Intl.message('No Grail/☆4 Fou', name: 'team_no_grail_fou', desc: '', locale: localeName, args: []);
  }

  /// `No Lv.100+`
  String get team_no_lv100 {
    return Intl.message('No Lv.100+', name: 'team_no_lv100', desc: '', locale: localeName, args: []);
  }

  /// `No Order Change`
  String get team_no_order_change {
    return Intl.message('No Order Change', name: 'team_no_order_change', desc: '', locale: localeName, args: []);
  }

  /// `No Same Svt`
  String get team_no_same_svt {
    return Intl.message('No Same Svt', name: 'team_no_same_svt', desc: '', locale: localeName, args: []);
  }

  /// `This quest may contain rare or additional enemies. If they appear randomly (appearance cannot be 100% guaranteed), please ensure that this team is suitable for all possible enemy versions.`
  String get team_rare_enemy_warning {
    return Intl.message(
      'This quest may contain rare or additional enemies. If they appear randomly (appearance cannot be 100% guaranteed), please ensure that this team is suitable for all possible enemy versions.',
      name: 'team_rare_enemy_warning',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `[With Details] Unreleased servant xxx/low success rate/cannot clear quest/etc.\nAsk admin to delete team rather to edit team.`
  String get team_report_reason_hint {
    return Intl.message(
      '[With Details] Unreleased servant xxx/low success rate/cannot clear quest/etc.\nAsk admin to delete team rather to edit team.',
      name: 'team_report_reason_hint',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Shared Teams`
  String get team_shared {
    return Intl.message('Shared Teams', name: 'team_shared', desc: '', locale: localeName, args: []);
  }

  /// `Frontline`
  String get team_starting_member {
    return Intl.message('Frontline', name: 'team_starting_member', desc: '', locale: localeName, args: []);
  }

  /// `Use Servant`
  String get team_use_servant {
    return Intl.message('Use Servant', name: 'team_use_servant', desc: '', locale: localeName, args: []);
  }

  /// `Test`
  String get test {
    return Intl.message('Test', name: 'test', desc: '', locale: localeName, args: []);
  }

  /// `Test Info Pad`
  String get test_info_pad {
    return Intl.message('Test Info Pad', name: 'test_info_pad', desc: '', locale: localeName, args: []);
  }

  /// `Time`
  String get time {
    return Intl.message('Time', name: 'time', desc: '', locale: localeName, args: []);
  }

  /// `Close`
  String get time_close {
    return Intl.message('Close', name: 'time_close', desc: '', locale: localeName, args: []);
  }

  /// `End`
  String get time_end {
    return Intl.message('End', name: 'time_end', desc: '', locale: localeName, args: []);
  }

  /// `Start`
  String get time_start {
    return Intl.message('Start', name: 'time_start', desc: '', locale: localeName, args: []);
  }

  /// `Tips`
  String get tips {
    return Intl.message('Tips', name: 'tips', desc: '', locale: localeName, args: []);
  }

  /// `Toggle Dark Mode`
  String get toggle_dark_mode {
    return Intl.message('Toggle Dark Mode', name: 'toggle_dark_mode', desc: '', locale: localeName, args: []);
  }

  /// `{count} NP5 ★5 servants, please descrease svt requirements as much as possible for sharing`
  String too_many_td5_svts_warning(Object count) {
    return Intl.message(
      '$count NP5 ★5 servants, please descrease svt requirements as much as possible for sharing',
      name: 'too_many_td5_svts_warning',
      desc: '',
      locale: localeName,
      args: [count],
    );
  }

  /// `Refresh slides`
  String get tooltip_refresh_sliders {
    return Intl.message('Refresh slides', name: 'tooltip_refresh_sliders', desc: '', locale: localeName, args: []);
  }

  /// `Total`
  String get total {
    return Intl.message('Total', name: 'total', desc: '', locale: localeName, args: []);
  }

  /// `Total AP`
  String get total_ap {
    return Intl.message('Total AP', name: 'total_ap', desc: '', locale: localeName, args: []);
  }

  /// `Total counts`
  String get total_counts {
    return Intl.message('Total counts', name: 'total_counts', desc: '', locale: localeName, args: []);
  }

  /// `Total NP`
  String get total_np {
    return Intl.message('Total NP', name: 'total_np', desc: '', locale: localeName, args: []);
  }

  /// `Trait`
  String get trait {
    return Intl.message('Trait', name: 'trait', desc: '', locale: localeName, args: []);
  }

  /// `Draw Cost`
  String get treasure_box_draw_cost {
    return Intl.message('Draw Cost', name: 'treasure_box_draw_cost', desc: '', locale: localeName, args: []);
  }

  /// `Extra Gifts per box`
  String get treasure_box_extra_gift {
    return Intl.message('Extra Gifts per box', name: 'treasure_box_extra_gift', desc: '', locale: localeName, args: []);
  }

  /// `Max Draws at once:`
  String get treasure_box_max_draw_once {
    return Intl.message(
      'Max Draws at once:',
      name: 'treasure_box_max_draw_once',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Trial Quest`
  String get trial_quest {
    return Intl.message('Trial Quest', name: 'trial_quest', desc: '', locale: localeName, args: []);
  }

  /// `Turn Remaining Limit`
  String get turn_remain_limit {
    return Intl.message('Turn Remaining Limit', name: 'turn_remain_limit', desc: '', locale: localeName, args: []);
  }

  /// `Considered Lose after turn countdown is over`
  String get turn_remain_limit_lose {
    return Intl.message(
      'Considered Lose after turn countdown is over',
      name: 'turn_remain_limit_lose',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Considered Win after turn countdown is over`
  String get turn_remain_limit_win {
    return Intl.message(
      'Considered Win after turn countdown is over',
      name: 'turn_remain_limit_win',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Usually for w-Koyan team`
  String get twice_skill_hint {
    return Intl.message('Usually for w-Koyan team', name: 'twice_skill_hint', desc: '', locale: localeName, args: []);
  }

  /// `Twice skills if Cool Down after 2 turns`
  String get twice_skill_if_cd2 {
    return Intl.message(
      'Twice skills if Cool Down after 2 turns',
      name: 'twice_skill_if_cd2',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `On Turn 3`
  String get twice_skill_on_turn_3 {
    return Intl.message('On Turn 3', name: 'twice_skill_on_turn_3', desc: '', locale: localeName, args: []);
  }

  /// `Whether the servant cast the second round of skills on T1 or T3`
  String get twice_skill_turn_3_hint {
    return Intl.message(
      'Whether the servant cast the second round of skills on T1 or T3',
      name: 'twice_skill_turn_3_hint',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Unknown`
  String get unknown {
    return Intl.message('Unknown', name: 'unknown', desc: '', locale: localeName, args: []);
  }

  /// `Unlock`
  String get unlock {
    return Intl.message('Unlock', name: 'unlock', desc: '', locale: localeName, args: []);
  }

  /// `Unlock Quest`
  String get unlock_quest {
    return Intl.message('Unlock Quest', name: 'unlock_quest', desc: '', locale: localeName, args: []);
  }

  /// `Update`
  String get update {
    return Intl.message('Update', name: 'update', desc: '', locale: localeName, args: []);
  }

  /// `Already the latest version`
  String get update_already_latest {
    return Intl.message(
      'Already the latest version',
      name: 'update_already_latest',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Please upgrade app`
  String get update_app_hint {
    return Intl.message('Please upgrade app', name: 'update_app_hint', desc: '', locale: localeName, args: []);
  }

  /// `Update on Startup`
  String get update_data_at_start {
    return Intl.message('Update on Startup', name: 'update_data_at_start', desc: '', locale: localeName, args: []);
  }

  /// `Load local data then background update, apply updates at next startup`
  String get update_data_at_start_off_hint {
    return Intl.message(
      'Load local data then background update, apply updates at next startup',
      name: 'update_data_at_start_off_hint',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `May take more time to startup`
  String get update_data_at_start_on_hint {
    return Intl.message(
      'May take more time to startup',
      name: 'update_data_at_start_on_hint',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Update Dataset`
  String get update_dataset {
    return Intl.message('Update Dataset', name: 'update_dataset', desc: '', locale: localeName, args: []);
  }

  /// `Update failed`
  String get update_msg_error {
    return Intl.message('Update failed', name: 'update_msg_error', desc: '', locale: localeName, args: []);
  }

  /// `No update available`
  String get update_msg_no_update {
    return Intl.message('No update available', name: 'update_msg_no_update', desc: '', locale: localeName, args: []);
  }

  /// `Update Time`
  String get update_time {
    return Intl.message('Update Time', name: 'update_time', desc: '', locale: localeName, args: []);
  }

  /// `Updated`
  String get updated {
    return Intl.message('Updated', name: 'updated', desc: '', locale: localeName, args: []);
  }

  /// `Upload`
  String get upload {
    return Intl.message('Upload', name: 'upload', desc: '', locale: localeName, args: []);
  }

  /// `Upload & Close`
  String get upload_and_close_app {
    return Intl.message('Upload & Close', name: 'upload_and_close_app', desc: '', locale: localeName, args: []);
  }

  /// `Upload data before closing the app?`
  String get upload_and_close_app_alert {
    return Intl.message(
      'Upload data before closing the app?',
      name: 'upload_and_close_app_alert',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Upload before closing`
  String get upload_before_close_app {
    return Intl.message(
      'Upload before closing',
      name: 'upload_before_close_app',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Current team is not eligible for upload:`
  String get upload_not_eligible_hint {
    return Intl.message(
      'Current team is not eligible for upload:',
      name: 'upload_not_eligible_hint',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Uploading too frequently, please wait {remain} seconds`
  String upload_paused(Object remain) {
    return Intl.message(
      'Uploading too frequently, please wait $remain seconds',
      name: 'upload_paused',
      desc: '',
      locale: localeName,
      args: [remain],
    );
  }

  /// `Upload current team?\n\nAttention: to service more players.\n- don't upload team which contains unreleased servants!\n- Please try to keep your team configuration as low as possible (unnecessary class score, grailed lv, append skill, NP Lv, unused backup servant).\n- Uploaded data may be deleted due to future updates, data incompatibility etc.`
  String get upload_team_confirmation {
    return Intl.message(
      'Upload current team?\n\nAttention: to service more players.\n- don\'t upload team which contains unreleased servants!\n- Please try to keep your team configuration as low as possible (unnecessary class score, grailed lv, append skill, NP Lv, unused backup servant).\n- Uploaded data may be deleted due to future updates, data incompatibility etc.',
      name: 'upload_team_confirmation',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Too many normal cards, please reduce unnecessary cards. If it's indeed critical-based team, check:`
  String get upload_team_critical_team_warning {
    return Intl.message(
      'Too many normal cards, please reduce unnecessary cards. If it\'s indeed critical-based team, check:',
      name: 'upload_team_critical_team_warning',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Usage`
  String get usage {
    return Intl.message('Usage', name: 'usage', desc: '', locale: localeName, args: []);
  }

  /// `Userdata`
  String get userdata {
    return Intl.message('Userdata', name: 'userdata', desc: '', locale: localeName, args: []);
  }

  /// `Download Backup`
  String get userdata_download_backup {
    return Intl.message('Download Backup', name: 'userdata_download_backup', desc: '', locale: localeName, args: []);
  }

  /// `Choose one backup`
  String get userdata_download_choose_backup {
    return Intl.message(
      'Choose one backup',
      name: 'userdata_download_choose_backup',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Userdata (Local)`
  String get userdata_local {
    return Intl.message('Userdata (Local)', name: 'userdata_local', desc: '', locale: localeName, args: []);
  }

  /// `TEMPORARY! Only account data, not include local settings, up to 3 backups within 1 week!`
  String get userdata_sync_hint {
    return Intl.message(
      'TEMPORARY! Only account data, not include local settings, up to 3 backups within 1 week!',
      name: 'userdata_sync_hint',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Data synchronization(Server)`
  String get userdata_sync_server {
    return Intl.message(
      'Data synchronization(Server)',
      name: 'userdata_sync_server',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Upload Backup`
  String get userdata_upload_backup {
    return Intl.message('Upload Backup', name: 'userdata_upload_backup', desc: '', locale: localeName, args: []);
  }

  /// `Valentine craft`
  String get valentine_craft {
    return Intl.message('Valentine craft', name: 'valentine_craft', desc: '', locale: localeName, args: []);
  }

  /// `Valentine Script`
  String get valentine_script {
    return Intl.message('Valentine Script', name: 'valentine_script', desc: '', locale: localeName, args: []);
  }

  /// `Invalid email address`
  String get validation_email_invalid {
    return Intl.message(
      'Invalid email address',
      name: 'validation_email_invalid',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `New username cannot be the same as the old username`
  String get validation_name_same_as_old {
    return Intl.message(
      'New username cannot be the same as the old username',
      name: 'validation_name_same_as_old',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Cannot contain whitespace`
  String get validation_no_whitespace {
    return Intl.message(
      'Cannot contain whitespace',
      name: 'validation_no_whitespace',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Password can only contain printable ASCII characters`
  String get validation_password_format {
    return Intl.message(
      'Password can only contain printable ASCII characters',
      name: 'validation_password_format',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Password must be 6-18 characters`
  String get validation_password_length {
    return Intl.message(
      'Password must be 6-18 characters',
      name: 'validation_password_length',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Password cannot be all digits`
  String get validation_password_not_all_digits {
    return Intl.message(
      'Password cannot be all digits',
      name: 'validation_password_not_all_digits',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `New password cannot be the same as the old password`
  String get validation_password_same_as_old {
    return Intl.message(
      'New password cannot be the same as the old password',
      name: 'validation_password_same_as_old',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Required`
  String get validation_required {
    return Intl.message('Required', name: 'validation_required', desc: '', locale: localeName, args: []);
  }

  /// `Too long`
  String get validation_too_long {
    return Intl.message('Too long', name: 'validation_too_long', desc: '', locale: localeName, args: []);
  }

  /// `Username cannot end with an underscore`
  String get validation_username_end_no_underscore {
    return Intl.message(
      'Username cannot end with an underscore',
      name: 'validation_username_end_no_underscore',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Username can only contain letters, digits, and underscores`
  String get validation_username_format {
    return Intl.message(
      'Username can only contain letters, digits, and underscores',
      name: 'validation_username_format',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Username must be 4-18 characters long`
  String get validation_username_length {
    return Intl.message(
      'Username must be 4-18 characters long',
      name: 'validation_username_length',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Username cannot be all digits`
  String get validation_username_not_all_digits {
    return Intl.message(
      'Username cannot be all digits',
      name: 'validation_username_not_all_digits',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `This username is reserved`
  String get validation_username_reserved {
    return Intl.message(
      'This username is reserved',
      name: 'validation_username_reserved',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Username must start with a letter`
  String get validation_username_start_letter {
    return Intl.message(
      'Username must start with a letter',
      name: 'validation_username_start_letter',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Version`
  String get version {
    return Intl.message('Version', name: 'version', desc: '', locale: localeName, args: []);
  }

  /// `Video`
  String get video {
    return Intl.message('Video', name: 'video', desc: '', locale: localeName, args: []);
  }

  /// `View Illustration`
  String get view_illustration {
    return Intl.message('View Illustration', name: 'view_illustration', desc: '', locale: localeName, args: []);
  }

  /// `Voice`
  String get voice {
    return Intl.message('Voice', name: 'voice', desc: '', locale: localeName, args: []);
  }

  /// `War`
  String get war {
    return Intl.message('War', name: 'war', desc: '', locale: localeName, args: []);
  }

  /// `Age`
  String get war_age {
    return Intl.message('Age', name: 'war_age', desc: '', locale: localeName, args: []);
  }

  /// `Banner`
  String get war_banner {
    return Intl.message('Banner', name: 'war_banner', desc: '', locale: localeName, args: []);
  }

  /// `Grail Front`
  String get war_board {
    return Intl.message('Grail Front', name: 'war_board', desc: '', locale: localeName, args: []);
  }

  /// `Map`
  String get war_map {
    return Intl.message('Map', name: 'war_map', desc: '', locale: localeName, args: []);
  }

  /// `Warning`
  String get warning {
    return Intl.message('Warning', name: 'warning', desc: '', locale: localeName, args: []);
  }

  /// `CN endpoint for China mainland\nWeb app is only recommended for PC users, Mobile website is laggy and may refresh unexpectedly.`
  String get web_domain_choice_hint {
    return Intl.message(
      'CN endpoint for China mainland\nWeb app is only recommended for PC users, Mobile website is laggy and may refresh unexpectedly.',
      name: 'web_domain_choice_hint',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Withdraw Consent`
  String get withdraw_consent {
    return Intl.message('Withdraw Consent', name: 'withdraw_consent', desc: '', locale: localeName, args: []);
  }

  /// `After withdrawing, Chaldea will stop processing data for non-essential features (advertising, crash diagnostics, product analytics). Everything else, including data updates and cloud backup, is unaffected. You can agree again anytime.`
  String get withdraw_consent_confirm {
    return Intl.message(
      'After withdrawing, Chaldea will stop processing data for non-essential features (advertising, crash diagnostics, product analytics). Everything else, including data updates and cloud backup, is unaffected. You can agree again anytime.',
      name: 'withdraw_consent_confirm',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Ads, crash diagnostics and product analytics stop; everything else keeps working.`
  String get withdraw_consent_desc {
    return Intl.message(
      'Ads, crash diagnostics and product analytics stop; everything else keeps working.',
      name: 'withdraw_consent_desc',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `{a} {b}`
  String words_separate(Object a, Object b) {
    return Intl.message('$a $b', name: 'words_separate', desc: '', locale: localeName, args: [a, b]);
  }

  /// `Cancel download and pick`
  String get xapk_cancel_and_pick {
    return Intl.message(
      'Cancel download and pick',
      name: 'xapk_cancel_and_pick',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `A download is in progress. Cancel it and pick a local file instead?`
  String get xapk_cancel_download_to_pick {
    return Intl.message(
      'A download is in progress. Cancel it and pick a local file instead?',
      name: 'xapk_cancel_download_to_pick',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Please confirm the install in the system dialog`
  String get xapk_confirming {
    return Intl.message(
      'Please confirm the install in the system dialog',
      name: 'xapk_confirming',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `The device installer refused the confirmation dialog. On MIUI, turn off "MIUI optimization" in Developer options and retry.`
  String get xapk_error_confirm_activity_missing {
    return Intl.message(
      'The device installer refused the confirmation dialog. On MIUI, turn off "MIUI optimization" in Developer options and retry.',
      name: 'xapk_error_confirm_activity_missing',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Archive failed the integrity check (CRC), please re-download`
  String get xapk_error_crc_failed {
    return Intl.message(
      'Archive failed the integrity check (CRC), please re-download',
      name: 'xapk_error_crc_failed',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `File not found`
  String get xapk_error_file_not_found {
    return Intl.message('File not found', name: 'xapk_error_file_not_found', desc: '', locale: localeName, args: []);
  }

  /// `A split APK listed in the manifest is missing from the archive`
  String get xapk_error_missing_split {
    return Intl.message(
      'A split APK listed in the manifest is missing from the archive',
      name: 'xapk_error_missing_split',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `No base APK found in the manifest`
  String get xapk_error_no_base_split {
    return Intl.message(
      'No base APK found in the manifest',
      name: 'xapk_error_no_base_split',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `manifest.json is missing or invalid`
  String get xapk_error_no_manifest {
    return Intl.message(
      'manifest.json is missing or invalid',
      name: 'xapk_error_no_manifest',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Not a valid XAPK archive`
  String get xapk_error_not_zip {
    return Intl.message('Not a valid XAPK archive', name: 'xapk_error_not_zip', desc: '', locale: localeName, args: []);
  }

  /// `This XAPK contains OBB expansion data, which is not supported yet. Please install it with an external installer app.`
  String get xapk_error_obb_unsupported {
    return Intl.message(
      'This XAPK contains OBB expansion data, which is not supported yet. Please install it with an external installer app.',
      name: 'xapk_error_obb_unsupported',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Archive size differs from the manifest — the file is corrupt, please re-download`
  String get xapk_error_size_mismatch {
    return Intl.message(
      'Archive size differs from the manifest — the file is corrupt, please re-download',
      name: 'xapk_error_size_mismatch',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Timed out waiting for the system installer`
  String get xapk_error_timeout {
    return Intl.message(
      'Timed out waiting for the system installer',
      name: 'xapk_error_timeout',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Install failed`
  String get xapk_install_failed {
    return Intl.message('Install failed', name: 'xapk_install_failed', desc: '', locale: localeName, args: []);
  }

  /// `Install finished`
  String get xapk_install_success {
    return Intl.message('Install finished', name: 'xapk_install_success', desc: '', locale: localeName, args: []);
  }

  /// `XAPK Install`
  String get xapk_install_title {
    return Intl.message('XAPK Install', name: 'xapk_install_title', desc: '', locale: localeName, args: []);
  }

  /// `Installing...`
  String get xapk_installing {
    return Intl.message('Installing...', name: 'xapk_installing', desc: '', locale: localeName, args: []);
  }

  /// `This build (e.g. from Google Play) does not declare the install-permission, so it cannot install APK/XAPK directly. Please use a third-party installer.`
  String get xapk_no_install_permission_hint {
    return Intl.message(
      'This build (e.g. from Google Play) does not declare the install-permission, so it cannot install APK/XAPK directly. Please use a third-party installer.',
      name: 'xapk_no_install_permission_hint',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Not every XAPK is supported (e.g. those containing OBB expansion data are not). If parsing or installation fails, please use a third-party installer — such as ApkPure App, APKCombo Installer, or MT Explorer — or the APK page's install helper.`
  String get xapk_not_supported_hint {
    return Intl.message(
      'Not every XAPK is supported (e.g. those containing OBB expansion data are not). If parsing or installation fails, please use a third-party installer — such as ApkPure App, APKCombo Installer, or MT Explorer — or the APK page\'s install helper.',
      name: 'xapk_not_supported_hint',
      desc: '',
      locale: localeName,
      args: [],
    );
  }

  /// `Package`
  String get xapk_package {
    return Intl.message('Package', name: 'xapk_package', desc: '', locale: localeName, args: []);
  }

  /// `Ready to install`
  String get xapk_parsed {
    return Intl.message('Ready to install', name: 'xapk_parsed', desc: '', locale: localeName, args: []);
  }

  /// `Parsing...`
  String get xapk_parsing {
    return Intl.message('Parsing...', name: 'xapk_parsing', desc: '', locale: localeName, args: []);
  }

  /// `Select XAPK/APK file`
  String get xapk_select_file {
    return Intl.message('Select XAPK/APK file', name: 'xapk_select_file', desc: '', locale: localeName, args: []);
  }

  /// `Total size`
  String get xapk_total_size {
    return Intl.message('Total size', name: 'xapk_total_size', desc: '', locale: localeName, args: []);
  }

  /// `Device compatibility`
  String get xapk_vendor_guidance_header {
    return Intl.message(
      'Device compatibility',
      name: 'xapk_vendor_guidance_header',
      desc: '',
      locale: localeName,
      args: [],
    );
  }
}

class AppLocalizationDelegate extends LocalizationsDelegate<S> {
  const AppLocalizationDelegate();

  List<Locale> get supportedLocales {
    return const <Locale>[
      Locale.fromSubtags(languageCode: 'en'),
      Locale.fromSubtags(languageCode: 'ar'),
      Locale.fromSubtags(languageCode: 'es'),
      Locale.fromSubtags(languageCode: 'ja'),
      Locale.fromSubtags(languageCode: 'ko'),
      Locale.fromSubtags(languageCode: 'ru'),
      Locale.fromSubtags(languageCode: 'zh'),
      Locale.fromSubtags(languageCode: 'zh', scriptCode: 'Hant'),
    ];
  }

  @override
  bool isSupported(Locale locale) => _isSupported(locale);
  @override
  Future<S> load(Locale locale) => S.load(locale);
  @override
  bool shouldReload(AppLocalizationDelegate old) => false;

  bool _isSupported(Locale locale) {
    for (var supportedLocale in supportedLocales) {
      if (supportedLocale.languageCode == locale.languageCode) {
        return true;
      }
    }
    return false;
  }
}
